# TaskPilot — Android chat assistant with a safe in-app browser

TaskPilot is a Kotlin + Jetpack Compose app: a chat assistant (text and voice) that
can read images, PDFs and text files, and can operate a **built-in WebView browser**
for you — open pages, read them, scroll, click and type — through a small, validated
set of tools. It asks before anything consequential (buying, deleting, sending,
signing in, submitting forms). The AI runs on **Gemini Flash through Firebase AI
Logic**, so no Gemini API key is ever shipped in the APK.

> **Build status of this delivery.** The source was written in an environment
> without the Android SDK or access to Google's Maven repository, so the APK was
> **not** built there. What *was* verified there: the security-policy code and its
> 33 unit tests (compiled and run with Kotlin 2.2.20), every browser automation
> script (run in headless Chromium against a test page: 18/18 checks), and all
> SDK signatures used (checked against Firebase AI Logic 18.1.0, AndroidX and AOSP
> sources). The included GitHub Actions workflow builds the APK in the cloud; the
> first run is the real compile check.

---

## Contents

1. [Features](#features)
2. [How it stays safe](#how-it-stays-safe)
3. [Project layout](#project-layout)
4. [Firebase setup (required)](#firebase-setup-required)
5. [Model configuration](#model-configuration)
5b. [Grok (optional, paid)](#grok-optional-paid)
6. [Build and install the APK](#build-and-install-the-apk)
7. [Supported attachments](#supported-attachments)
8. [Permissions](#permissions)
9. [Data stored and how to clear it](#data-stored-and-how-to-clear-it)
10. [Release builds](#release-builds)
11. [Limitations](#limitations)
12. [Troubleshooting](#troubleshooting)

---

## Features

- **Chat** with light Markdown, copy, and per-message read-aloud.
- **Voice input** with Android `SpeechRecognizer` (live partial text, optional
  auto-send). Falls back to the system speech dialog when no in-app recognizer is
  available or the microphone permission is declined.
- **Spoken replies** with Android `TextToSpeech` (toggle in the top bar; replies to
  voice messages are always spoken). Arabic replies switch to an Arabic voice when
  one is installed.
- **Attachments** through the system Photo Picker and document picker (no storage
  permission needed).
- **In-app browser** (WebView) that the assistant can drive with 8 tools:
  `open_url`, `web_search`, `read_page`, `click`, `type_text`, `select_option`,
  `scroll`, `go_back`. You can watch it in a split view, expand it to full screen,
  or hide it. You can also browse and sign in to sites yourself.
- **Confirmation dialog** before consequential actions, showing the site, the
  button/field and the text to be entered (passwords masked).
- **Settings & privacy** screen: voice options, "ask before every action" mode,
  search engine, history on/off, clear conversation / browser data / everything,
  model and App Check status, and the App Check debug token with a Copy button.

## How it stays safe

| Requirement | Implementation |
|---|---|
| No Grok/xAI key in the APK | Grok requests go to **your own Cloudflare Worker** (`backend/grok-proxy/worker.js`), which holds the xAI key as a secret and forwards a request only if it carries a valid **Firebase App Check** token for your project (signature, issuer, audience, expiry and optionally app id are checked). |
| No Gemini key in the APK | Requests go through **Firebase AI Logic** (`firebase-ai`), which holds the Gemini key server-side. `google-services.json` contains only Firebase identifiers, not a Gemini secret. |
| Only genuine app instances can call the API | **Firebase App Check**: debug provider in debug builds (`src/debug`), Play Integrity in release builds (`src/release`). Limited-use tokens are enabled (`useLimitedUseAppCheckTokens = true`). Turn on enforcement for AI Logic in the console. |
| Allowlisted browser actions only | `policy/ToolCallParser.kt` accepts exactly the 8 tool names and their argument names, checks types and lengths, requires element ids to match `e<digits>`, and validates URLs. Anything else is rejected and reported back to the model. |
| Model output never runs as JavaScript | `browser/BrowserScripts.kt` is the complete set of scripts the app injects. They are fixed templates; arguments are inserted only as inert, ASCII-escaped literals (`policy/JsLiteral.kt`). No `addJavascriptInterface` bridge exists. |
| Web content is untrusted | Page text and element labels are returned inside an `untrusted_page_content` object with a warning; the system prompt tells the model that only the user's chat messages are instructions. Element labels are truncated; password values are never read back. |
| Confirm consequential actions | `policy/ActionPolicy.kt` classifies each click/entry (English, French and Arabic labels; submit buttons; checkout/payment pages; password, card, email and phone fields; Enter in chat boxes; links carrying data to another site). The agent waits for your answer and re-checks that the target element is unchanged before acting. Optional strict mode confirms every active action. |
| Browser hardening | http(s) only (http is upgraded to https); `file:`, `content:`, `intent:`, `javascript:` and app links blocked; requests to this device / local network (incl. obfuscated IPs) blocked; no file access, geolocation, camera/mic, pop-ups, downloads or uploads; SSL errors never bypassed; Safe Browsing on; third-party cookies off. |
| Permissions only when needed | Only `INTERNET` at install. `RECORD_AUDIO` is requested the first time you tap the mic. Pickers need no permission. |

## Project layout

```
app/src/main/java/com/taskpilot/assistant/
├── MainActivity.kt, TaskPilotApp.kt, AppContainer.kt
├── ai/
│   ├── AgentEngine.kt              Provider interface (Gemini / Grok), shared limits
│   ├── BrowserToolRunner.kt        The single path from model tool calls to the browser (validation, confirmation)
│   ├── GeminiAgent.kt              Gemini engine via Firebase AI Logic
│   ├── GrokAgent.kt, GrokClient.kt Grok engine via your proxy (OpenAI-compatible format, App Check header)
│   ├── BrowserToolDeclarations.kt  Function declarations sent to Gemini
│   ├── AgentPrompt.kt              System instruction (instruction hierarchy, browsing rules)
│   ├── FirebaseSetup.kt            Firebase + App Check initialization
│   ├── ModelConfig.kt, ModelNames.kt  Default model + Remote Config override
│   ├── ToolArgs.kt, AgentErrors.kt
├── browser/
│   ├── BrowserScripts.kt           The only JavaScript ever injected (fixed templates)
│   ├── BrowserController.kt        WebView wrapper with suspend actions
│   ├── BrowserToolExecutor.kt      Runs validated actions, builds model responses
│   └── AgentWebView.kt             Locked-down WebView, clients, data clearing
├── policy/                         Pure Kotlin, unit-tested
│   ├── UrlPolicy.kt, BrowserAction.kt (ToolCallParser), ActionPolicy.kt, JsLiteral.kt, ActionDescriber.kt
├── data/                           Conversation/attachment storage, settings, file import
├── speech/                         SpeechRecognizer / TextToSpeech wrappers
└── ui/                             Compose screens and components
app/src/debug/…/AppCheckProviders.kt    Debug App Check provider + token reader
app/src/release/…/AppCheckProviders.kt  Play Integrity provider
app/src/test/…                          Security-policy unit tests
.github/workflows/build-apk.yml          Cloud build that produces the APK
backend/grok-proxy/worker.js             Cloudflare Worker that holds the xAI key (optional, for Grok)
```

## Firebase setup (required for Gemini cloud AI only)

Everything below works from a phone browser at <https://console.firebase.google.com>.

1. **Create a Firebase project** (Analytics not needed). The free Spark plan works
   with the Gemini Developer API's free tier.
2. **Add an Android app** with package name **`com.taskpilot.assistant`**
   (or change `taskpilot.applicationId` in `gradle.properties` to match yours).
3. **Download `google-services.json`** and put it at `app/google-services.json`
   (already done in this copy, for project `taskpilot-208ba`). It contains Firebase
   identifiers, not a Gemini secret, so it can live in a **private** repository.
   Alternatively delete it and paste its content into a GitHub secret named
   **`GOOGLE_SERVICES_JSON`** (the secret wins if both exist).
   Without either, the project still builds but the app shows "Setup needed".
4. **Enable AI Logic:** Firebase console → *AI Logic* → *Get started* → choose
   **Gemini Developer API**. Do **not** put the Gemini API key it creates into the app.
5. **Add the debug signing fingerprint** (needed to register App Check):
   Project settings → your Android app → *Add fingerprint* →
   `25:65:8D:6B:8E:AD:C2:20:EF:54:6B:B0:88:89:C5:1E:0C:79:22:76:0C:39:82:86:4A:B1:7E:0E:D3:81:E2:38`
   (SHA-256 of `app/debug.keystore`, the shared debug key in this repo).
6. **Register App Check:** *App Check* → *Apps* → your Android app → **Play Integrity**
   → Save.
7. **Register the debug token** (debug APKs): install the APK, open it, then
   *Settings → Assistant → App Check debug token → Copy*. In the console:
   *App Check → Apps → ⋮ (your app) → Manage debug tokens → Add debug token* and paste.
8. **Enforce App Check:** *App Check → APIs → Firebase AI Logic → Enforce*. From now
   on only your registered app instances can use your Gemini quota.
9. *(Optional)* **Remote Config:** add a parameter **`gemini_model`** (string) to switch
   models without rebuilding.

## Model configuration

- **Default:** `gemini-3.6-flash` — a stable (GA) Flash model on Firebase AI Logic,
  supported until at least July 2027, with function calling, image and PDF input.
  The app uses a **low thinking level** to keep tool-using turns fast and cheap.
- **Cheaper:** `gemini-3.5-flash-lite` (GA) for lighter use.
- **Change it** without rebuilding via Remote Config `gemini_model`, or at build
  time in `gradle.properties` (`taskpilot.geminiModel=...`). Only names matching
  `gemini-…` are accepted. Check the current list and retirement dates at
  <https://firebase.google.com/docs/ai-logic/models> before switching — Gemini 2.5
  models can be shut down any time after 16 October 2026.
- Cost controls built in: images are downscaled to 1536 px JPEG; only the latest
  page snapshot is kept in full in the conversation; attachments are dropped from
  history after two turns; at most 20 browser actions per turn.

### Making it faster (all free)

| What | How |
|---|---|
| Fewer Gemini calls | Built in: open/search/click/back/scroll return the new page content directly, so no extra `read_page` call is needed. |
| Faster pages | Settings → **Fast browsing** (on by default) skips images; the browser continues once a page is ~85% loaded. |
| Faster model | Firebase console → **Remote Config** → add `gemini_model` = `gemini-3.5-flash-lite` → Publish. Fastest and lightest; slightly weaker on long multi-step browsing. |
| Less thinking | Remote Config `thinking_level` = `minimal` (fastest) / `low` (default) / `medium` / `high`. If a model rejects a level, the app falls back to `low` automatically. |
| Connection | Wi-Fi or 4G helps most: every step sends the page text to Gemini and back. |

Remote Config changes apply the next time the app starts (fetched at most every 10 minutes).

## Grok (optional, paid)

TaskPilot can use **Grok (xAI)** instead of Gemini: *Settings → AI provider → Grok*.
Gemini stays the default and is free; **the xAI API is pay-per-use** (prepaid credits at
console.x.ai). `grok-4.7` is listed by xAI at $2 per million input tokens and $6 per
million output tokens, so a chat reply costs well under a cent and a multi-step
browsing task roughly $0.03–0.10. Set a spending limit in the xAI console.

The xAI key must never be in the app, so Grok goes through a tiny proxy you own: a
Cloudflare Worker (free plan: 100,000 requests/day). All steps work in a phone browser.

1. **xAI key:** console.x.ai → *API Keys* → create a key (it starts with `xai-`). Add
   credits and a spending limit. Never paste the key into a chat or the app.
2. **Create the Worker:** dash.cloudflare.com (free account) → *Workers & Pages* →
   *Create* → *Create Worker* → name it `taskpilot-grok` → *Deploy* → *Edit code* →
   replace everything with the contents of `backend/grok-proxy/worker.js` → *Deploy*.
3. **Worker settings:** *Settings → Variables and Secrets* → add:
   | Name | Type | Value |
   |---|---|---|
   | `XAI_API_KEY` | **Secret** | your `xai-…` key |
   | `FIREBASE_PROJECT_NUMBER` | Text | `150252300373` |
   | `ALLOWED_MODELS` | Text | `grok-4.7` (blocks other, pricier models) |
   | `FIREBASE_APP_IDS` | Text | `1:150252300373:android:0f0c8c19cee4ddd4d70cdc` |
   Then *Deploy* again.
4. **Check it:** open `https://taskpilot-grok.<your-subdomain>.workers.dev` in the
   browser; it should show `{"ok":true,"service":"taskpilot-grok-proxy"}`.
5. **Tell the app where it is:** Firebase console → *Remote Config* → add parameter
   `grok_proxy_url` = your Worker URL (optionally `grok_model`, default `grok-4.7`) →
   *Publish*. (Or set `taskpilot.grokProxyUrl` in `gradle.properties` and rebuild.)
6. **App Check is required:** the Worker only accepts genuine app requests, so register
   the app's debug token (Firebase setup steps 5–7) before using Grok.
7. In TaskPilot: *Settings → AI provider → Grok (xAI, paid)*. The top bar shows
   `Grok · grok-4.7`. Reopen the app if it was running when you published Remote Config.

Notes: Grok receives PDFs as images of their first 5 pages (rendered on the phone).
xAI lists the chat-completions endpoint used here as deprecated in favour of its
Responses API, with no shutdown date announced. Switching providers keeps the chat;
earlier attachments are not re-sent. Test the proxy locally with `node backend/grok-proxy/test.mjs`.

## Build and install the APK

### A. From your phone with GitHub Actions (no computer needed)

1. Put this project in a **private** GitHub repository (it includes a debug key and
   your Firebase config).
2. *(Only if you removed `app/google-services.json`)* add the `GOOGLE_SERVICES_JSON`
   secret (*Settings → Secrets and variables → Actions*).
3. Open *Actions → Build APK → Run workflow* (it also runs on every push to `main`).
4. When it finishes (~5–8 min), open the run and download **TaskPilot-debug-apk**.
5. Unzip it on the phone and open `app-debug.apk`; allow your browser/file manager to
   "install unknown apps" when asked. Later builds install as updates.

The workflow runs the security-policy unit tests, then `assembleDebug`. If a build
step fails, its log shows the exact compiler error.

### B. On a computer

Requirements: JDK 17+, Android SDK with platform 36 (Android Studio provides both).

```bash
./gradlew testDebugUnitTest assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Versions: Gradle 8.14.3, Android Gradle Plugin 8.13.2, Kotlin 2.2.20, Compose BOM
2025.10.01, Firebase BoM 35.1.0 (firebase-ai 18.1.0), compileSdk/targetSdk 36,
minSdk 26.

## Supported attachments

| Type | Formats | Limit | What is sent |
|---|---|---|---|
| Images | JPEG, PNG, WebP, HEIC/HEIF, GIF (first frame), BMP | 40 MB source | Resized to ≤1536 px, re-encoded as JPEG (EXIF/location stripped) |
| Documents | PDF | 15 MB | The PDF as-is |
| Text | TXT, Markdown, CSV, TSV, JSON, XML, HTML, LOG, YAML (any `text/*`) | 512 KB | UTF-8 text, marked as file data |

Up to 5 files per message and 18 MB of images/PDFs per message (Firebase's inline
request limit is 20 MB). Not supported: Office files (export to PDF), audio, video,
archives, SVG.

## Permissions

| Permission | When | Why |
|---|---|---|
| `INTERNET` | Install time | Gemini via Firebase, and the browser |
| `RECORD_AUDIO` | First tap on the mic | In-app speech recognition. If declined, the system speech dialog is used instead. |

The photo and document pickers grant access only to the files you choose. Websites
can never get camera, microphone or location access.

## Data stored and how to clear it

Stored only in the app's private storage, excluded from cloud backup and device
transfer:

- conversation transcript (`files/conversation.json`) and copies of attachments (`files/attachments/`)
- the browser's cookies, cache, history and site storage
- settings (SharedPreferences)

Sent off the device only when you chat: your messages, attachments of the current
conversation and the text of pages the assistant reads go to Google's Gemini API via
Firebase AI Logic. No analytics are included.

Clear it in *Settings → Privacy & data*: **Clear conversation**, **Clear browser
data**, or **Clear all data**. Turning off *Keep conversation history* deletes the
saved transcript and stops saving. Uninstalling removes everything.

## Release builds

1. Create a release keystore and add a `release` signing config (keep passwords in
   CI secrets, not in the repo).
2. Distribute through Google Play (an internal testing track is enough):
   Play Integrity only vouches for apps installed from Play.
3. In Firebase add the **Play app signing** SHA-256 (Play Console → App integrity),
   and link the Play Integrity API to the Firebase project.
4. `./gradlew assembleRelease` (R8 minification is enabled).

## Limitations

- The assistant reads the main document only: content inside iframes or closed
  shadow DOM is not visible, and some sites scroll inner panels instead of the page.
- Sites that block embedded browsers (e.g. some Google sign-in pages) or show
  CAPTCHAs need you to act in the browser panel yourself.
- Plain-http-only sites are blocked (the app allows HTTPS only).
- File uploads to and downloads from websites are not supported.
- Confirmation rules are heuristic and intentionally conservative; turn on
  *Ask before every browser action* for full control.

## Troubleshooting

| Message in chat | Fix |
|---|---|
| "Firebase isn't set up in this build" | Add `GOOGLE_SERVICES_JSON` / `app/google-services.json` and rebuild. |
| "Firebase AI Logic isn't enabled" | Console → AI Logic → Get started → Gemini Developer API. |
| "Firebase refused the request (App Check)" | Register the debug token from Settings (step 7), or check enforcement. |
| "Gemini is overloaded" / "Couldn't reach Gemini" | The app already retried 3 times (3 s, 8 s, 20 s). Send "continue" later; if overload is frequent, set Remote Config `gemini_model` to `gemini-3.5-flash-lite`. |
| "Grok isn't set up yet" | Set Remote Config `grok_proxy_url` to your Worker URL (Grok steps 2–5). |
| "Your Grok proxy rejected the app (App Check)" | Register the app's debug token in Firebase App Check. |
| "Your xAI account has no API credits" | Add credits at console.x.ai, or switch back to Gemini. |
| "The model … isn't available" | Set Remote Config `gemini_model` to a current Flash model. |
| Build: "No matching client found for package name" | The package in `google-services.json` must equal `taskpilot.applicationId`. |
| APK won't install over the old one | The old one was signed with a different key: uninstall it once. |


## NEW: Offline AI (no per-request quota)

TaskPilot v1.2.0 can use an entirely **on-device** language model via Google's
LiteRT-LM Android runtime (version 0.18.0). This is the only AI mode in the app
without service request quotas or API fees. It does *not* mean unlimited RAM,
CPU, battery, context length, storage, or internet access. Models are not bundled
into the APK so the build stays small.

**On the phone:**

1. Download a small `.litertlm` text model to the phone. Start at
   https://huggingface.co/litert-community/Qwen3-0.6B and select a compatible
   **CPU** model such as `Qwen3-0.6B.litertlm` (~586 MB; check model card for
   updated artifact compatibility). Do not select a `.gguf`, `.task`, or `.tflite`.
2. TaskPilot → **Settings → Offline AI → Import .litertlm model**.
3. After import, TaskPilot automatically selects **Offline (no quota)**. Text
   conversations and plain-text attachments can run with no cloud API calls.
4. Switch back to Gemini in Settings when you need image/PDF understanding or
   AI-controlled browser actions. Those functions remain subject to their
   provider's online quota/rate limits. The offline model does **not** currently
   perform automated browser actions; the in-app browser remains manually usable.

Small models make mistakes. Performance on entry-level Android phones may be
slow or memory-limited; even a 586 MB model can use 2–3 GB of RAM during
inference. Choose a smaller quantization if needed, or try on another phone.
Voice input may use the device's online recognition service. Android TTS depends
on the installed voice engine. Models are stored privately in app storage and
will be deleted when the app is uninstalled.

Official docs: https://developers.google.com/edge/litert-lm/android

### GitHub cloud build without a computer

1. Create a **private** GitHub repository named `TaskPilot`.
2. Upload the **contents** of this source folder to the repository root, with
   `.github/workflows/build-apk.yml` preserved. Do not upload the ZIP as a lone
   file in the repository; GitHub cannot build an Android project from a ZIP
   that has not been extracted.
3. **Actions → Build APK → Run workflow** (or push to `main` to trigger it).
4. Open the completed workflow run → **Artifacts → TaskPilot-debug-apk**.
   Download the ZIP artifact and unzip it on Android to obtain `app-debug.apk`.
5. Open the APK on the phone and allow installation from that browser/files app.

This is a **debug** APK for personal testing, not a Play Store release.
Cloud CI time and artifact retention are subject to GitHub's plan limits.
