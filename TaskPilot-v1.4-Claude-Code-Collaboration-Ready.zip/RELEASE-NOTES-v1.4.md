# TaskPilot Free 1.4 — Report-driven fix

## Original issue
The report for `make website` shows the task was classified as BROWSE and ended with a DuckDuckGo listing summary; it did not create an artifact.

## Implemented
- Explicit creation intent is intercepted before cloud/offline model selection and before browser search.
- Responsive, accessible HTML/CSS template created completely on-device without a model, API key, or network.
- Subject extraction: `make website for Warak Laf` becomes a correctly escaped `warak-laf.html` file with that subject as its title.
- Save file in app-private storage and verify its contents; render in existing browser panel.
- Open Android Save As picker to export an HTML file to the user's chosen location; verify exported bytes with SHA-256.
- Support `export website` to repeat export without recreating.
- Report errors explicitly and distinguish file creation, local export and online publishing.
- Avoid misleading automatic web search for website creation; refuse unsupported untrusted file and browser access.
- Remove pre-existing Firebase `google-services.json` from distributed source. Browser and website creation work without any server.

## Known boundaries
- Template builder uses deterministic content blocks, not autonomous page generation or web hosting.
- The `.html` page can open offline after it has been saved; no domain or public hosting is configured.
- Full generative chat still requires separately supplied compatible local model or configured external provider.
- The provided APK builder must run on Google Colab or a computer with Android SDK; no APK has been compiled in this workspace.
