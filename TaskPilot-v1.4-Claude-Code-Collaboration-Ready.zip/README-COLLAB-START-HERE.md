# TaskPilot v1.4 — ChatGPT + Claude Code collaboration

This package contains the complete TaskPilot v1.4 Android source plus:
- `CLAUDE.md`: shared development rules for Claude Code.
- `.github/workflows/claude.yml`: optional on-demand Claude Action (OFF by default).
- The existing `.github/workflows/build-apk.yml`: builds a test APK on main/PR/manual runs.

## First-time setup (phone is enough)
1. Sign in to GitHub as **mssy1999-commits** and create a **PRIVATE** repository named `TaskPilot`.
   New repo: https://github.com/new
2. Extract this ZIP. Upload **the files and folders inside** (including hidden `.github/`)
   into the repository root, not the ZIP file itself. If uploading from the GitHub mobile
   browser is difficult, use desktop-site view or a cloud editor to push the files.
3. In ChatGPT: **Settings > Plugins > GitHub > Manage repositories**. Grant the ChatGPT
   GitHub app access to this private TaskPilot repository. It may take several minutes to appear.
4. In Claude Code: https://claude.ai/code . Sign in with an eligible Claude account,
   connect GitHub, and grant the Claude GitHub app access to this repository.
5. Open TaskPilot in Claude Code and ask it to review the source and fix compilation issues
   without removing features; have it create a pull request rather than merging automatically.
6. In GitHub, open **Actions > Build APK > Run workflow** if you want a test APK immediately.
   When successful, open the workflow run's **Artifacts** and download `TaskPilot-debug-apk`.
   An Android SDK build is NOT claimed to be tested in this package.

## Optional GitHub comment-triggered Claude automation (uses paid authentication)
The Claude GitHub Action in `.github/workflows/claude.yml` is intentionally OFF by default.
To enable it, install https://github.com/apps/claude for this repository; then:
- GitHub repository **Settings > Secrets and variables > Actions > Secrets**:
  create `ANTHROPIC_API_KEY` from your separately provisioned Anthropic API account.
- **Variables**: create `ENABLE_CLAUDE_ACTION` with value `true`.
- On an issue or pull request, comment `@claude Please review this build failure and propose a fix`.
- Only GitHub actor `mssy1999-commits` can trigger the provided action.
- Monitor consumption and spend limits in Anthropic Console; keep the repository PRIVATE.
Never paste an API key into source code, a chat message, or an issue.

You **do not need** the optional paid GitHub Action to use Claude Code on the web with
an eligible Claude subscription. Claude Code web/cloud can create pull requests without
locally installing a CLI. GitHub Actions APK building has its own GitHub usage limits.

## ChatGPT collaboration model
- Claude creates a **pull request**, and does not merge it.
- Ask ChatGPT: "Review the latest TaskPilot pull request on GitHub, verify the APK build,
  and tell me what to change." ChatGPT can inspect the repository and PR when the GitHub
  connection has repository access. It does not have a direct live Claude-to-ChatGPT chat link.
- Merge after reviewing test status and the actual changes.

Useful references:
- https://support.claude.com/en/articles/12618689-use-claude-code-in-the-cloud
- https://github.com/anthropics/claude-code-action/blob/main/docs/setup.md
- https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt
