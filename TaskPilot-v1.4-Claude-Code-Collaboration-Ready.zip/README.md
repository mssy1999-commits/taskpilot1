# TaskPilot FREE — Android AI Assistant v1.4.0


**Rebuilt from the existing Kotlin/Jetpack Compose TaskPilot source, preserving the chat interface, voice input/output, attachments, private history, and confirmation-protected WebView.**

## Zero-cost options

1. **No backend at all — website creation plus free browser commands from first install.** The default mode is *Offline*. Type `make website` or `make website for Warak Laf` to create a responsive HTML template, preview it inside the app, and export it via Android Save As. `export website` lets you save the most recent template again. The actual generated file is checked before completion is reported. This is not AI content generation or online hosting. Commands `/open`, `/search`, `/read`, `/click`, `/type`, `/submit`, `/scroll`, `/select`, and `/back` work without an AI account or downloaded model, and run through the existing browser allowlist and confirmation policy. They are deterministic slash commands, NOT autonomous natural-language AI. Type `/help` in chat for examples.
2. **Offline conversational AI — no per-request fee.** In Settings, import a separately obtained CPU-compatible `.litertlm` model. Only text and text-file inputs are supported in local AI mode. A model can consume substantial disk, RAM, and CPU, and some phones will not support it. Model weights are not redistributed in this APK/source.
3. **Free-tier cloud AI — Gemini 3.5 Flash-Lite via Firebase AI Logic.** Switch Settings → AI provider to Gemini and configure your Firebase Spark project with `app/google-services.json`, Firebase AI Logic and App Check per existing README. This enables natural language chat, images/PDFs, and **AI-planned** browser actions. Usage is subject to provider availability and limits; it is not an unlimited free service. No custom backend URL is required for Firebase AI Logic. `google-services.json` is an app configuration file, not an API key.

The older optional Grok support remains in source but requires **paid xAI API** access and is **not part of the zero-cost workflow**. You never need to configure or use it.

## Build an installable APK for free (Android phone, no PC)

**Simplest:** Open the supplied `TaskPilot-v1.4-One-Click-APK-Build.ipynb` in **Google Colab** → Runtime → Run all. The notebook embeds the complete source ZIP, installs the Android SDK, compiles a debug APK, and presents a download. Free Colab availability and internet access are required. **This is not a precompiled APK; the cloud run is the real compiler verification.** If compilation fails, the notebook will show and download the Gradle log.

**Alternative:** Extract the ZIP's contents into a GitHub repository; run the included `.github/workflows/build-apk.yml` GitHub Actions workflow. GitHub Free has included Actions minutes for private repositories, and standard runners are free for public repositories within GitHub's policies. Do not upload only the ZIP file into the repository.

**Debug APK caveat:** This is a testing build, not Play Store production signing; no private API key should ever be embedded. For security, `google-services.json` was removed from this distribution. Free website creation and offline browser commands require no Firebase project, backend URL or key.

## Security
- Browser actions are parsed and restricted by the original `BrowserToolRunner` and `ToolCallParser`; no arbitrary model JavaScript is executed.
- Purchases, submissions, messages, passwords, personal fields and other consequential browser steps require explicit in-app confirmation.
- Local model data stays in private app storage, although websites opened in WebView can of course exchange data over the network.

## Build tooling
AGP 8.13.2 / Kotlin 2.4.10 / Gradle 8.14.3 / Java 17 / Android SDK 36 / LiteRT-LM 0.18.0. Kotlin upgraded to 2.4.x for LiteRT-LM 0.18.0 dependency metadata compatibility. Build not validated against Android SDK in this environment.

## Project details
See `README-ORIGINAL.md` for the original full specification, Firebase configuration, optional Grok proxy, data privacy and other details. The free-first changes supersede older defaults and costs described there.

## Report-driven fix (28 October 2026)
A prior TaskPilot run interpreted `make website` as web search, browsed a DuckDuckGo directory, and marked the result `COMPLETED_UNVERIFIED`. This release routes explicit website-creation instructions to an on-device HTML builder before any AI engine or search step. It creates an actual, validated HTML file in private app storage, opens an in-app preview, asks where to export it, and verifies the saved file byte-for-byte. Reports distinguish **created**, **saved**, **export verified**, and **not published**. There is no autonomous deployment or internet search for this command.

Examples: `make website`, `create a website for my restaurant`, `build a landing page for Warak Laf`, `export website`.

Only site templates, not general AI-generated websites, are supported without a separately installed on-device model. Browser tasks still require internet connectivity.
