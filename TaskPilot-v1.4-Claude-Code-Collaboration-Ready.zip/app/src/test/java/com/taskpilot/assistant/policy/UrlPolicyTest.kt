package com.taskpilot.assistant.policy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlPolicyTest {

    private fun allowed(raw: String): UrlPolicy.Result.Allowed {
        val r = UrlPolicy.validateNavigation(raw)
        assertTrue("Expected $raw to be allowed but got $r", r is UrlPolicy.Result.Allowed)
        return r as UrlPolicy.Result.Allowed
    }

    private fun rejected(raw: String) {
        val r = UrlPolicy.validateNavigation(raw)
        assertTrue("Expected $raw to be rejected but got $r", r is UrlPolicy.Result.Rejected)
    }

    @Test
    fun acceptsHttpsAndUpgradesHttp() {
        assertEquals("https://example.com/a?b=1", allowed("https://example.com/a?b=1").url)
        assertEquals("https://example.com/", allowed("http://example.com/").url)
        assertEquals("example.com", allowed("HTTP://Example.COM").host)
    }

    @Test
    fun addsSchemeToBareDomains() {
        assertEquals("https://example.com/path", allowed("example.com/path").url)
        assertEquals("https://example.com:8443/x", allowed("example.com:8443/x").url)
    }

    @Test
    fun rejectsDangerousSchemes() {
        rejected("javascript:alert(1)")
        rejected("JaVaScRiPt:alert(1)")
        rejected("file:///sdcard/secret.txt")
        rejected("content://com.android.contacts/contacts")
        rejected("intent://scan/#Intent;scheme=zxing;end")
        rejected("data:text/html,<script>alert(1)</script>")
        rejected("mailto:someone@example.com")
        rejected("ftp://example.com/file")
    }

    @Test
    fun rejectsLocalNetworkAndObfuscatedHosts() {
        rejected("http://localhost:8080")
        rejected("http://127.0.0.1/")
        rejected("http://10.0.0.5/")
        rejected("http://192.168.1.1/admin")
        rejected("http://172.20.3.4/")
        rejected("http://169.254.169.254/latest/meta-data")
        rejected("http://[::1]/")
        rejected("http://2130706433/")
        rejected("http://0x7f.1/")
        rejected("http://0177.0.0.1/")
        rejected("http://router.local/")
        rejected("https://printer.lan/")
    }

    @Test
    fun rejectsCredentialsWhitespaceAndOverlongUrls() {
        rejected("https://user:pass@example.com/")
        rejected("https://exa mple.com/")
        rejected("https://example.com/\nfoo")
        rejected("https://example.com/" + "a".repeat(UrlPolicy.MAX_URL_LENGTH))
        rejected("")
    }

    @Test
    fun allowsPublicIpsAndInternationalNames() {
        assertEquals("8.8.8.8", allowed("https://8.8.8.8/").host)
        assertEquals("xn--bcher-kva.de", allowed("https://bücher.de/").host)
        assertTrue(allowed("https://ar.wikipedia.org/wiki/لبنان").url.startsWith("https://ar.wikipedia.org/wiki/"))
    }

    @Test
    fun encodesCharactersJavaUriRejects() {
        assertEquals("https://example.com/a%7Cb", allowed("https://example.com/a|b").url)
    }

    @Test
    fun localHostDetectionDoesNotBlockNormalDomains() {
        assertFalse(UrlPolicy.isLocalNetworkHost("cafe.de"))
        assertFalse(UrlPolicy.isLocalNetworkHost("www.example.com"))
        assertFalse(UrlPolicy.isLocalNetworkHost("1.1.1.1"))
        assertTrue(UrlPolicy.isLocalNetworkHost("100.64.0.1"))
    }

    @Test
    fun sameSiteHeuristic() {
        assertTrue(UrlPolicy.isSameSite("www.example.com", "shop.example.com"))
        assertFalse(UrlPolicy.isSameSite("example.com", "evil.com"))
        assertFalse(UrlPolicy.isSameSite("a.co.uk", "b.co.uk"))
        assertTrue(UrlPolicy.isSameSite("www.bbc.co.uk", "news.bbc.co.uk"))
        assertFalse(UrlPolicy.isSameSite(null, "example.com"))
    }

    @Test
    fun searchUrlsAreEncoded() {
        assertEquals(
            "https://duckduckgo.com/html/?q=rolling+papers+%26+filters",
            UrlPolicy.SearchEngine.DUCKDUCKGO.searchUrl("rolling papers & filters"),
        )
    }

    @Test
    fun carriesData() {
        assertTrue(UrlPolicy.carriesData("https://x.com/?q=1"))
        assertTrue(UrlPolicy.carriesData("https://x.com/#token"))
        assertFalse(UrlPolicy.carriesData("https://x.com/path"))
    }
}
