package com.taskpilot.assistant.ai

import org.junit.Assert.*
import org.junit.Test

class OfflineBrowserCommandsTest {
    @Test fun helpAndUnknownAreSafe() {
        assertTrue(OfflineBrowserCommands.parse("/help") is OfflineCommandResult.Message)
        assertTrue(OfflineBrowserCommands.parse("/danger") is OfflineCommandResult.Message)
        assertTrue(OfflineBrowserCommands.parse("open https://example.com") is OfflineCommandResult.NotACommand)
    }
    @Test fun openSearchAndRead() {
        val open = OfflineBrowserCommands.parse("/open https://example.com") as OfflineCommandResult.Action
        assertEquals("open_url", open.call.tool)
        assertEquals("https://example.com", open.call.args["url"])
        val search = OfflineBrowserCommands.parse("/search android keyboard") as OfflineCommandResult.Action
        assertEquals("web_search", search.call.tool)
        assertEquals("android keyboard", search.call.args["query"])
        val read = OfflineBrowserCommands.parse("/read") as OfflineCommandResult.Action
        assertEquals("read_page", read.call.tool)
    }
    @Test fun typedTextNeverSubmitsUnlessExplicit() {
        val a = OfflineBrowserCommands.parse("/type e12 hello world") as OfflineCommandResult.Action
        assertEquals(false, a.call.args["submit"])
        val b = OfflineBrowserCommands.parse("/submit e12 hello world") as OfflineCommandResult.Action
        assertEquals(true, b.call.args["submit"])
        assertTrue(OfflineBrowserCommands.parse("/type bad hello") is OfflineCommandResult.Message)
    }
    @Test fun unknownScrollAndClickRejectWithoutAction() {
        assertTrue(OfflineBrowserCommands.parse("/scroll sideways") is OfflineCommandResult.Message)
        assertTrue(OfflineBrowserCommands.parse("/click e999999") is OfflineCommandResult.Message)
        assertTrue(OfflineBrowserCommands.parse("/click e1 and do other things") is OfflineCommandResult.Message)
    }
}
