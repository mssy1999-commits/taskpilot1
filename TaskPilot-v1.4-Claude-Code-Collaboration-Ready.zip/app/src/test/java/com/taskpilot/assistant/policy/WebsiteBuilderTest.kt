package com.taskpilot.assistant.policy

import com.taskpilot.assistant.ai.WebsiteBuilder
import org.junit.Assert.*
import org.junit.Test

class WebsiteBuilderTest {
    @Test fun createsWebsiteFromOriginalFailureCase() {
        assertTrue(WebsiteBuilder.recognizes("make website"))
        val site = WebsiteBuilder.build("make website")
        assertTrue(site.html.startsWith("<!DOCTYPE html>"))
        assertTrue(site.html.contains("name=\"viewport\""))
        assertTrue(site.html.contains("href=\"#contact\""))
        assertEquals("my-website.html", site.fileName)
    }

    @Test fun preservesProvidedSubjectButEscapesMarkup() {
        val site = WebsiteBuilder.build("Create a website for Warak Laf <Co>")
        assertTrue(site.html.contains("Warak Laf &lt;Co&gt;"))
        assertFalse(site.html.contains("<Co>"))
        assertEquals("warak-laf-co.html", site.fileName)
    }

    @Test fun neverMisroutesSearchOrExplanations() {
        assertFalse(WebsiteBuilder.recognizes("find websites in London"))
        assertFalse(WebsiteBuilder.recognizes("how to make a website"))
        assertFalse(WebsiteBuilder.recognizes("don't build a website"))
        assertFalse(WebsiteBuilder.recognizes("search for website design examples"))
        assertTrue(WebsiteBuilder.recognizes("Please build me a landing page for my business"))
    }
}
