package com.taskpilot.assistant.policy

import com.taskpilot.assistant.ai.ModelNames
import com.taskpilot.assistant.data.AttachmentKind
import com.taskpilot.assistant.data.AttachmentTypes
import com.taskpilot.assistant.speech.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MiscPureLogicTest {

    @Test
    fun attachmentClassification() {
        assertEquals(AttachmentKind.IMAGE, AttachmentTypes.classify("image/jpeg", "a.jpg"))
        assertEquals(AttachmentKind.IMAGE, AttachmentTypes.classify("image/heic", null))
        assertEquals(AttachmentKind.PDF, AttachmentTypes.classify("application/pdf", "x"))
        assertEquals(AttachmentKind.TEXT, AttachmentTypes.classify("text/csv", "prices.csv"))
        assertEquals(AttachmentKind.TEXT, AttachmentTypes.classify("application/octet-stream", "notes.md"))
        assertEquals(AttachmentKind.TEXT, AttachmentTypes.classify(null, "data.json"))
        assertNull(AttachmentTypes.classify("image/svg+xml", "logo.svg"))
        assertNull(AttachmentTypes.classify("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "a.docx"))
        assertNull(AttachmentTypes.classify("video/mp4", "clip.mp4"))
        assertNull(AttachmentTypes.classify("application/octet-stream", "tool.apk"))
    }

    @Test
    fun speechCleaning() {
        val md = "## Result\n**Price:** `12 USD` — see [the shop](https://shop.example.com/x).\n- item one\n- item two\nMore at https://www.example.com/a/b"
        val spoken = SpeechText.clean(md)
        assertFalse(spoken.contains("**") || spoken.contains("#") || spoken.contains("`") || spoken.contains("https://"))
        assertTrue(spoken.contains("Price: 12 USD"))
        assertTrue(spoken.contains("the shop"))
        assertTrue(spoken.contains("a link to example.com"))
        assertTrue(SpeechText.isMostlyArabic("مرحبا كيف حالك"))
        assertFalse(SpeechText.isMostlyArabic("Hello there"))
    }

    @Test
    fun speechChunking() {
        val text = (1..50).joinToString(" ") { "Sentence number $it is here." }
        val chunks = SpeechText.chunk(text, 200)
        assertTrue(chunks.all { it.length <= 200 })
        assertEquals(text.replace(" ", ""), chunks.joinToString("").replace(" ", ""))
    }

    @Test
    fun modelNameValidation() {
        assertTrue(ModelNames.isValid("gemini-3.6-flash"))
        assertTrue(ModelNames.isValid("gemini-3.5-flash-lite"))
        assertFalse(ModelNames.isValid("gpt-4"))
        assertFalse(ModelNames.isValid("gemini-3.6-flash; drop"))
        assertFalse(ModelNames.isValid(""))
        assertTrue(ModelNames.usesThinkingBudget("gemini-2.5-flash"))
        assertFalse(ModelNames.usesThinkingBudget("gemini-3.6-flash"))
    }

    @Test
    fun describesActions() {
        assertEquals("Opening example.com", ActionDescriber.describe(BrowserAction.OpenUrl("https://example.com/", "example.com")))
        assertEquals(
            "Clicking “Add to cart”",
            ActionDescriber.describe(BrowserAction.Click("e1"), ElementInfo(id = "e1", tag = "button", label = "Add to cart")),
        )
    }
}
