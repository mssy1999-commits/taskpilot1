package com.taskpilot.assistant.policy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolCallParserTest {

    private fun ok(name: String, args: Map<String, Any?>): BrowserAction {
        val r = ToolCallParser.parse(name, args)
        assertTrue("Expected OK for $name $args, got $r", r is ParseResult.Ok)
        return (r as ParseResult.Ok).action
    }

    private fun rejected(name: String, args: Map<String, Any?>): String {
        val r = ToolCallParser.parse(name, args)
        assertTrue("Expected rejection for $name $args, got $r", r is ParseResult.Rejected)
        return (r as ParseResult.Rejected).reason
    }

    @Test
    fun parsesEveryAllowedTool() {
        assertEquals(BrowserAction.OpenUrl("https://example.com/", "example.com"), ok("open_url", mapOf("url" to "example.com/")))
        assertEquals(BrowserAction.WebSearch("weather beirut"), ok("web_search", mapOf("query" to " weather beirut ")))
        assertEquals(BrowserAction.ReadPage(6000), ok("read_page", emptyMap()))
        assertEquals(BrowserAction.ReadPage(20000), ok("read_page", mapOf("max_chars" to 999999.0)))
        assertEquals(BrowserAction.ReadPage(500), ok("read_page", mapOf("max_chars" to 3L)))
        assertEquals(BrowserAction.Click("e12"), ok("click", mapOf("element_id" to "E12")))
        assertEquals(
            BrowserAction.TypeText("e3", "hello\nworld", true),
            ok("type_text", mapOf("element_id" to "e3", "text" to "hello\nworld", "submit" to "true")),
        )
        assertEquals(BrowserAction.SelectOption("e4", "Lebanon"), ok("select_option", mapOf("element_id" to "e4", "option" to "Lebanon")))
        assertEquals(BrowserAction.Scroll(ScrollDirection.BOTTOM), ok("scroll", mapOf("direction" to "Bottom")))
        assertEquals(BrowserAction.GoBack, ok("go_back", emptyMap()))
    }

    @Test
    fun rejectsUnknownToolsAndArguments() {
        rejected("run_javascript", mapOf("code" to "alert(1)"))
        rejected("evaluate", emptyMap())
        rejected("click", mapOf("element_id" to "e1", "selector" to "#buy"))
        rejected("open_url", mapOf("url" to "https://a.com", "script" to "x"))
    }

    @Test
    fun rejectsSelectorsOrScriptsAsElementIds() {
        rejected("click", mapOf("element_id" to "#buy-button"))
        rejected("click", mapOf("element_id" to "e1\"]);alert(1);//"))
        rejected("click", mapOf("element_id" to "e123456"))
        rejected("click", mapOf("element_id" to 12))
        rejected("click", emptyMap())
    }

    @Test
    fun rejectsBadValues() {
        rejected("open_url", mapOf("url" to "javascript:alert(document.cookie)"))
        rejected("scroll", mapOf("direction" to "sideways"))
        rejected("type_text", mapOf("element_id" to "e1", "text" to "x".repeat(ToolCallParser.MAX_TEXT_LENGTH + 1)))
        rejected("type_text", mapOf("element_id" to "e1", "text" to "a\u0000b"))
        rejected("type_text", mapOf("element_id" to "e1", "text" to "ok", "submit" to "maybe"))
        rejected("web_search", mapOf("query" to "   "))
        rejected("read_page", mapOf("max_chars" to "lots"))
    }

    @Test
    fun allowsEmptyTextToClearAField() {
        assertEquals(BrowserAction.TypeText("e1", "", false), ok("type_text", mapOf("element_id" to "e1", "text" to "")))
    }
}
