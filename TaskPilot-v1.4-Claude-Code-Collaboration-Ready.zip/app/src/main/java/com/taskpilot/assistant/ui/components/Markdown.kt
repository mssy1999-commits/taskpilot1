package com.taskpilot.assistant.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle

/**
 * Small Markdown subset for chat replies: headings, bullets, **bold**, *italic*,
 * `code`, fenced code blocks and [links](https://...). Links open in the app's
 * own browser through [onLinkClick] (never in another app).
 */
fun renderMarkdown(
    text: String,
    linkColor: Color,
    codeBackground: Color,
    onLinkClick: (String) -> Unit,
): AnnotatedString = buildAnnotatedString {
    val lines = text.lines()
    var inCode = false
    lines.forEachIndexed { index, raw ->
        val isLast = index == lines.lastIndex
        if (raw.trimStart().startsWith("```")) {
            inCode = !inCode
            return@forEachIndexed
        }
        if (inCode) {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBackground)) { append(raw) }
            if (!isLast) append('\n')
            return@forEachIndexed
        }
        val heading = HEADING.find(raw)
        val bullet = BULLET.find(raw)
        when {
            heading != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                appendInline(raw.substring(heading.range.last + 1), linkColor, codeBackground, onLinkClick)
            }
            bullet != null -> {
                append("  •  ")
                appendInline(raw.substring(bullet.range.last + 1), linkColor, codeBackground, onLinkClick)
            }
            else -> appendInline(raw, linkColor, codeBackground, onLinkClick)
        }
        if (!isLast) append('\n')
    }
}

private val HEADING = Regex("^\\s{0,3}#{1,6}\\s+")
private val BULLET = Regex("^\\s*[-*+]\\s+")
private val INLINE = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`|\\[([^\\]]+)]\\((https?://[^)\\s]+)\\)|(?<![*\\w])\\*(?!\\s)([^*]+?)\\*(?![*\\w])|(https?://[^\\s)]+)")

private fun AnnotatedString.Builder.appendInline(
    s: String,
    linkColor: Color,
    codeBackground: Color,
    onLinkClick: (String) -> Unit,
) {
    var last = 0
    for (m in INLINE.findAll(s)) {
        append(s.substring(last, m.range.first))
        val g = m.groupValues
        when {
            g[1].isNotEmpty() -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(g[1]) }
            g[2].isNotEmpty() -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBackground)) { append(g[2]) }
            g[3].isNotEmpty() -> appendLink(g[3], g[4], linkColor, onLinkClick)
            g[5].isNotEmpty() -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(g[5]) }
            g[6].isNotEmpty() -> appendLink(g[6], g[6], linkColor, onLinkClick)
            else -> append(m.value)
        }
        last = m.range.last + 1
    }
    append(s.substring(last))
}

private fun AnnotatedString.Builder.appendLink(label: String, url: String, color: Color, onLinkClick: (String) -> Unit) {
    val link = LinkAnnotation.Url(
        url = url,
        styles = TextLinkStyles(style = SpanStyle(color = color, textDecoration = TextDecoration.Underline)),
        linkInteractionListener = { onLinkClick(url) },
    )
    withLink(link) { append(label) }
}
