package com.taskpilot.assistant.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.taskpilot.assistant.policy.ConfirmationRequest
import com.taskpilot.assistant.policy.RiskKind

/** Shown before any consequential browser action. Dismissing counts as "don't allow". */
@Composable
fun ConfirmActionDialog(request: ConfirmationRequest, onAnswer: (Boolean) -> Unit) {
    val colors = MaterialTheme.colorScheme
    val severe = request.risk == RiskKind.PURCHASE || request.risk == RiskKind.DELETE || request.risk == RiskKind.SENSITIVE_INPUT
    AlertDialog(
        onDismissRequest = { onAnswer(false) },
        properties = DialogProperties(dismissOnClickOutside = false),
        icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = if (severe) colors.error else colors.secondary) },
        title = { Text(request.title) },
        text = {
            Column {
                Text(request.summary, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.size(12.dp))
                request.details.forEach { (label, value) ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(label, style = MaterialTheme.typography.labelLarge, color = colors.onSurfaceVariant, modifier = Modifier.width(96.dp))
                        Text(value, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.size(12.dp))
                Text(
                    "Only allow this if you asked for it. Text on web pages can try to trick assistants.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onAnswer(true) },
                colors = if (severe) ButtonDefaults.buttonColors(containerColor = colors.error, contentColor = colors.onError) else ButtonDefaults.buttonColors(),
            ) { Text("Allow") }
        },
        dismissButton = { TextButton(onClick = { onAnswer(false) }) { Text("Don't allow") } },
    )
}
