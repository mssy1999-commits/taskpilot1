package com.taskpilot.assistant.ai

/**
 * Deterministic, zero-cost offline browser commands. This code does NOT execute
 * model output and runs no scripts itself; all calls go through BrowserToolRunner,
 * which validates parameters and requires approval before consequential actions.
 */
data class OfflineCommand(val tool: String, val args: Map<String, Any?>)

sealed interface OfflineCommandResult {
    data class Action(val call: OfflineCommand) : OfflineCommandResult
    data class Message(val text: String) : OfflineCommandResult
    data object NotACommand : OfflineCommandResult
}

object OfflineBrowserCommands {
    const val HELP = """Free on-device tools (no API key, no AI model):
make website for my business — create/preview/export a responsive HTML template
export website — save the last generated site as an HTML file

Browser commands:
/open https://example.com — open a URL
/search your topic — web search
/read — read the current page and show element IDs
/click e12 — click an element from /read
/type e12 text to enter — enter text (does not submit)
/submit e12 text to enter — enter text and submit (approval may be required)
/select e12 option text — choose an option
/scroll down — up, down, top, bottom
/back — back to previous page
/help — this guide

Website content and actions are restricted to the built-in browser. Sensitive actions ask for your approval. For conversational local AI, import a compatible .litertlm model from Settings; for autonomous planning select Gemini (free tier, with limits)."""

    /** Slash commands only: no ambiguous free-form text can trigger browser actions. */
    fun parse(input: String): OfflineCommandResult {
        val text = input.trim()
        if (!text.startsWith('/')) return OfflineCommandResult.NotACommand
        val name = text.substringBefore(' ').lowercase()
        val rest = text.substringAfter(' ', "").trim()
        fun action(tool: String, vararg pairs: Pair<String, Any?>) =
            OfflineCommandResult.Action(OfflineCommand(tool, mapOf(*pairs)))
        fun usage(info: String) = OfflineCommandResult.Message("Usage: $info\n\nType /help for all commands.")
        fun elementAndText(command: String, parameter: String): OfflineCommandResult {
            val el = rest.substringBefore(' ').trim().lowercase()
            val content = rest.substringAfter(' ', "").trim()
            return if (!Regex("e[0-9]{1,5}").matches(el) || content.isBlank()) {
                usage("/$command e12 $parameter")
            } else {
                when (command) {
                    "type", "submit" -> action("type_text", "element_id" to el, "text" to content, "submit" to (command == "submit"))
                    "select" -> action("select_option", "element_id" to el, "option" to content)
                    else -> OfflineCommandResult.Message("Unknown command")
                }
            }
        }
        return when (name) {
            "/help" -> OfflineCommandResult.Message(HELP)
            "/open" -> if (rest.isBlank()) usage("/open https://example.com") else action("open_url", "url" to rest)
            "/search" -> if (rest.isBlank()) usage("/search your topic") else action("web_search", "query" to rest)
            "/read" -> action("read_page")
            "/back" -> action("go_back")
            "/scroll" -> if (rest.lowercase() in setOf("down", "up", "top", "bottom")) action("scroll", "direction" to rest.lowercase()) else usage("/scroll down")
            "/click" -> if (Regex("e[0-9]{1,5}").matches(rest.lowercase())) action("click", "element_id" to rest.lowercase()) else usage("/click e12")
            "/type" -> elementAndText("type", "text to enter")
            "/submit" -> elementAndText("submit", "text to submit")
            "/select" -> elementAndText("select", "option text")
            else -> OfflineCommandResult.Message("Unknown offline command. Type /help for the available commands.")
        }
    }
}
