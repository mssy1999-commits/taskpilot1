package com.taskpilot.assistant.browser

import com.taskpilot.assistant.policy.JsLiteral
import com.taskpilot.assistant.policy.ScrollDirection

/**
 * The complete set of JavaScript the app ever runs in the WebView.
 *
 * Every script is a fixed, app-authored template. Arguments (element ids already
 * validated as e<digits>, text, numbers) are inserted only as inert literals via
 * [JsLiteral]. Model output is never evaluated as code. Each script returns a
 * JSON string so results are parsed as data.
 */
internal object BrowserScripts {

    private const val ATTR = "data-tp-id"

    /** Shared helpers, inlined into every script. Contains no '$' (Kotlin templates). */
    private val PRELUDE = """
var ATTR = '$ATTR';
function tpClean(s, n) {
  s = String(s || '').replace(/\s+/g, ' ').replace(/"/g, "'").trim();
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}
function tpFind(id) {
  var all = document.querySelectorAll('[' + ATTR + ']');
  for (var i = 0; i < all.length; i++) { if (all[i].getAttribute(ATTR) === id) return all[i]; }
  return null;
}
function tpLabel(el) {
  var t = el.getAttribute('aria-label') || '';
  if (!t && el.labels && el.labels.length) t = el.labels[0].innerText;
  if (!t && el.getAttribute('aria-labelledby')) {
    var ref = document.getElementById(el.getAttribute('aria-labelledby'));
    if (ref) t = ref.innerText;
  }
  if (!t && el.tagName !== 'SELECT') t = el.innerText || '';
  if (!t && el.tagName === 'INPUT' && /^(submit|button|reset)$/i.test(el.type)) t = el.value;
  if (!t) t = el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('alt') || '';
  if (!t && el.querySelector) { var img = el.querySelector('img[alt]'); if (img) t = img.getAttribute('alt'); }
  if (!t) t = el.getAttribute('name') || '';
  return tpClean(t, 100);
}
function tpVisible(el) {
  var r = el.getBoundingClientRect();
  if (r.width < 1 || r.height < 1) return false;
  var st = window.getComputedStyle(el);
  return !(st.visibility === 'hidden' || st.display === 'none' || st.opacity === '0');
}
"""

    private fun wrap(body: String): String =
        "(function(){try{$PRELUDE\n$body\n}catch(err){return JSON.stringify({ok:false,error:String(err)});}})()"

    // ---- read_page --------------------------------------------------------

    private const val SNAPSHOT_BODY = """
var maxChars = __MAX_CHARS__;
var old = document.querySelectorAll('[' + ATTR + ']');
for (var i = 0; i < old.length; i++) old[i].removeAttribute(ATTR);
var vh = window.innerHeight || document.documentElement.clientHeight || 0;
var sel = 'a[href],button,input:not([type=hidden]),textarea,select,summary,[role=button],[role=link],' +
  '[role=checkbox],[role=radio],[role=tab],[role=menuitem],[role=option],[role=switch],[role=textbox],' +
  '[role=combobox],[role=searchbox],[contenteditable=""],[contenteditable=true]';
var nodes = document.querySelectorAll(sel);
var inView = [], outView = [];
for (var j = 0; j < nodes.length; j++) {
  var n = nodes[j];
  if (!tpVisible(n)) continue;
  var rr = n.getBoundingClientRect();
  if (rr.bottom > 0 && rr.top < vh) inView.push(n); else outView.push(n);
}
var picked = inView.concat(outView).slice(0, 90);
var lines = [];
for (var k = 0; k < picked.length; k++) {
  var e = picked[k];
  var id = 'e' + (k + 1);
  e.setAttribute(ATTR, id);
  var tag = e.tagName.toLowerCase();
  var role = e.getAttribute('role') || '';
  var type = (e.getAttribute('type') || '').toLowerCase();
  var ac = e.getAttribute('autocomplete') || '';
  var kind = tag === 'a' ? 'link' : (tag === 'input' ? 'input[' + (type || 'text') + ']' :
    (role ? role : (e.isContentEditable && tag !== 'textarea' ? 'editable' : tag)));
  var line = id + ' ' + kind + ' "' + tpLabel(e) + '"';
  if (tag === 'a' && e.href) line += ' -> ' + tpClean(e.href, 90);
  var secret = type === 'password' || /cc-/.test(ac);
  if ((tag === 'input' || tag === 'textarea') && !secret) {
    if (type === 'checkbox' || type === 'radio') line += e.checked ? ' [checked]' : ' [unchecked]';
    else if (e.value) line += ' value="' + tpClean(e.value, 60) + '"';
  }
  if (secret && e.value) line += ' [filled]';
  if (tag === 'select') {
    var o = e.options[e.selectedIndex];
    line += ' selected="' + tpClean(o ? o.text : '', 40) + '" (' + e.options.length + ' options)';
  }
  if (e.disabled) line += ' [disabled]';
  if (k >= inView.length) line += ' [offscreen]';
  lines.push(line);
}
var body = document.body ? (document.body.innerText || '') : '';
body = body.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
var total = Math.max(document.documentElement.scrollHeight - vh, 1);
return JSON.stringify({
  ok: true, url: location.href, title: document.title,
  text: body.slice(0, maxChars), textTruncated: body.length > maxChars, textLength: body.length,
  elements: lines, moreElements: (inView.length + outView.length) > picked.length,
  scrollPercent: Math.round(Math.min(window.scrollY / total, 1) * 100)
});
"""

    fun snapshot(maxChars: Int): String = wrap(SNAPSHOT_BODY.replace("__MAX_CHARS__", JsLiteral.int(maxChars)))

    // ---- element inspection (input to the confirmation policy) --------------

    private const val INSPECT_BODY = """
var el = tpFind(__ID__);
if (!el) return JSON.stringify({ found: false });
var tag = el.tagName.toLowerCase();
var type = (el.getAttribute('type') || (tag === 'button' ? 'submit' : '')).toLowerCase();
var form = el.form || (el.closest ? el.closest('form') : null);
var isSubmit = (tag === 'button' && type === 'submit' && !!form) || (tag === 'input' && (type === 'submit' || type === 'image'));
function searchy(s) { return /(^|[^a-z])(search|query|find|recherche|chercher|بحث)([^a-z]|$)/i.test(String(s || '')); }
var nm = (el.getAttribute('name') || '').toLowerCase();
var isSearch = type === 'search' || el.getAttribute('role') === 'searchbox' ||
  ['q', 'query', 'search', 's', 'k', 'keyword', 'keywords', 'search_query', 'term', 'text'].indexOf(nm) >= 0 && searchy(el.getAttribute('aria-label') + ' ' + el.getAttribute('placeholder') + ' ' + nm) ||
  searchy(el.getAttribute('aria-label')) || searchy(el.getAttribute('placeholder')) ||
  !!(el.closest && el.closest('[role=search]'));
var method = '', action = '';
if (form) {
  method = (form.getAttribute('method') || 'get').toLowerCase();
  action = form.getAttribute('action') || '';
  if (form.getAttribute('role') === 'search' || form.querySelector('input[type=search]') || searchy(action) || searchy(form.id) || searchy(form.className)) isSearch = true;
  if (method !== 'get') isSearch = false;
}
return JSON.stringify({
  found: true, tag: tag, type: type, role: el.getAttribute('role') || '', label: tpLabel(el),
  href: tag === 'a' ? (el.href || '') : '', name: el.getAttribute('name') || '',
  autocomplete: el.getAttribute('autocomplete') || '', isSubmit: isSubmit, inForm: !!form,
  formMethod: method, formAction: tpClean(action, 200), isSearch: isSearch,
  editable: !!el.isContentEditable, disabled: !!el.disabled
});
"""

    fun inspect(elementId: String): String = wrap(INSPECT_BODY.replace("__ID__", JsLiteral.string(elementId)))

    // ---- click --------------------------------------------------------------

    private const val CLICK_BODY = """
var el = tpFind(__ID__);
if (!el) return JSON.stringify({ ok: false, error: 'not_found' });
el.scrollIntoView({ block: 'center', inline: 'center' });
var r = el.getBoundingClientRect();
var opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
try { el.dispatchEvent(new PointerEvent('pointerdown', opts)); } catch (x) {}
el.dispatchEvent(new MouseEvent('mousedown', opts));
try { el.dispatchEvent(new PointerEvent('pointerup', opts)); } catch (x) {}
el.dispatchEvent(new MouseEvent('mouseup', opts));
if (el.focus) el.focus();
el.click();
return JSON.stringify({ ok: true });
"""

    fun click(elementId: String): String = wrap(CLICK_BODY.replace("__ID__", JsLiteral.string(elementId)))

    // ---- type_text ------------------------------------------------------------

    private const val TYPE_BODY = """
var el = tpFind(__ID__);
var text = __TEXT__;
var submit = __SUBMIT__;
if (!el) return JSON.stringify({ ok: false, error: 'not_found' });
el.scrollIntoView({ block: 'center' });
if (el.focus) el.focus();
var tag = el.tagName;
if (tag === 'INPUT' || tag === 'TEXTAREA') {
  var proto = tag === 'INPUT' ? window.HTMLInputElement.prototype : window.HTMLTextAreaElement.prototype;
  var desc = Object.getOwnPropertyDescriptor(proto, 'value');
  if (desc && desc.set) desc.set.call(el, text); else el.value = text;
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
} else if (el.isContentEditable) {
  var range = document.createRange();
  range.selectNodeContents(el);
  var s = window.getSelection(); s.removeAllRanges(); s.addRange(range);
  var done = false;
  try { done = document.execCommand('insertText', false, text); } catch (x) {}
  if (!done) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); }
} else {
  return JSON.stringify({ ok: false, error: 'not_editable' });
}
var submitted = false;
if (submit) {
  function kev(t) {
    var ev = new KeyboardEvent(t, { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true });
    try {
      Object.defineProperty(ev, 'keyCode', { get: function () { return 13; } });
      Object.defineProperty(ev, 'which', { get: function () { return 13; } });
    } catch (x) {}
    return ev;
  }
  var notCancelled = el.dispatchEvent(kev('keydown'));
  el.dispatchEvent(kev('keypress'));
  el.dispatchEvent(kev('keyup'));
  if (notCancelled && el.form) {
    if (el.form.requestSubmit) el.form.requestSubmit(); else el.form.submit();
    submitted = true;
  }
}
var secret = (el.getAttribute('type') || '').toLowerCase() === 'password';
var shown = secret ? '' : String(el.value !== undefined ? el.value : el.textContent || '');
return JSON.stringify({ ok: true, submitted: submitted, value: tpClean(shown, 80) });
"""

    fun type(elementId: String, text: String, submit: Boolean): String = wrap(
        TYPE_BODY
            .replace("__ID__", JsLiteral.string(elementId))
            .replace("__TEXT__", JsLiteral.string(text))
            .replace("__SUBMIT__", JsLiteral.bool(submit))
    )

    // ---- select_option ----------------------------------------------------------

    private const val SELECT_BODY = """
var el = tpFind(__ID__);
var want = String(__OPTION__).trim().toLowerCase();
if (!el) return JSON.stringify({ ok: false, error: 'not_found' });
if (el.tagName !== 'SELECT') return JSON.stringify({ ok: false, error: 'not_a_select_element' });
var idx = -1;
for (var i = 0; i < el.options.length; i++) {
  var o = el.options[i];
  if (o.text.trim().toLowerCase() === want || String(o.value).toLowerCase() === want) { idx = i; break; }
}
if (idx < 0) {
  for (var j = 0; j < el.options.length; j++) {
    if (el.options[j].text.toLowerCase().indexOf(want) >= 0) { idx = j; break; }
  }
}
if (idx < 0) {
  var names = [];
  for (var k = 0; k < Math.min(el.options.length, 40); k++) names.push(tpClean(el.options[k].text, 40));
  return JSON.stringify({ ok: false, error: 'option_not_found', options: names });
}
el.selectedIndex = idx;
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
return JSON.stringify({ ok: true, selected: tpClean(el.options[idx].text, 60) });
"""

    fun select(elementId: String, option: String): String = wrap(
        SELECT_BODY
            .replace("__ID__", JsLiteral.string(elementId))
            .replace("__OPTION__", JsLiteral.string(option))
    )

    // ---- scroll -------------------------------------------------------------------

    private const val SCROLL_BODY = """
var dir = __DIR__;
var vh = window.innerHeight || 600;
var root = document.scrollingElement || document.documentElement;
if (dir === 'down') window.scrollBy(0, vh * 0.8);
else if (dir === 'up') window.scrollBy(0, -vh * 0.8);
else if (dir === 'top') window.scrollTo(0, 0);
else window.scrollTo(0, root.scrollHeight);
var total = Math.max(root.scrollHeight - vh, 1);
return JSON.stringify({ ok: true, scrollPercent: Math.round(Math.min(window.scrollY / total, 1) * 100) });
"""

    fun scroll(direction: ScrollDirection): String =
        wrap(SCROLL_BODY.replace("__DIR__", JsLiteral.string(direction.wire)))
}
