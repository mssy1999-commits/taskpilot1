package com.taskpilot.assistant.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.annotation.MainThread
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface VoiceState {
    data object Idle : VoiceState
    data class Listening(val partial: String = "", val level: Float = 0f) : VoiceState
    data class Error(val message: String) : VoiceState
}

/**
 * In-app voice input with Android's [SpeechRecognizer]. Requires the RECORD_AUDIO
 * permission, which the UI requests only when the user taps the microphone. If no
 * recognition service is available, the UI falls back to the system speech dialog
 * ([RecognizerIntent]), which needs no permission in this app.
 */
class SpeechInputController(context: Context) {

    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    private var onFinal: ((String) -> Unit)? = null

    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    val isAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(appContext)

    @MainThread
    fun start(languageTag: String, onResult: (String) -> Unit) {
        cancel()
        onFinal = onResult
        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = r
        r.setRecognitionListener(listener)
        _state.value = VoiceState.Listening()
        r.startListening(recognizerIntent(languageTag))
    }

    /** Stops listening and delivers what was heard so far. */
    @MainThread
    fun stop() {
        recognizer?.stopListening()
    }

    @MainThread
    fun cancel() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        onFinal = null
        if (_state.value is VoiceState.Listening) _state.value = VoiceState.Idle
    }

    fun clearError() {
        if (_state.value is VoiceState.Error) _state.value = VoiceState.Idle
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) {
            val s = _state.value
            if (s is VoiceState.Listening) _state.value = s.copy(level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        }
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            val s = _state.value
            if (text.isNotBlank() && s is VoiceState.Listening) _state.value = s.copy(partial = text)
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            val callback = onFinal
            release()
            _state.value = VoiceState.Idle
            if (text.isNotBlank()) callback?.invoke(text)
        }

        override fun onError(error: Int) {
            val partial = (_state.value as? VoiceState.Listening)?.partial.orEmpty()
            val callback = onFinal
            release()
            if (partial.isNotBlank() && (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH)) {
                _state.value = VoiceState.Idle
                callback?.invoke(partial)
                return
            }
            _state.value = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> VoiceState.Error("I didn't catch that. Try again.")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> VoiceState.Error("Microphone permission is needed for voice input.")
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> VoiceState.Error("Voice input needs a network connection.")
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> VoiceState.Error("The speech service is busy. Try again.")
                SpeechRecognizer.ERROR_AUDIO -> VoiceState.Error("Couldn't record audio.")
                SpeechRecognizer.ERROR_CLIENT -> VoiceState.Idle
                12, 13 -> VoiceState.Error("That voice language isn't supported on this device. Change it in Settings.")
                else -> VoiceState.Error("Voice input failed (code $error).")
            }
        }
    }

    private fun release() {
        recognizer?.destroy()
        recognizer = null
        onFinal = null
    }

    companion object {
        fun recognizerIntent(languageTag: String): Intent =
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                if (languageTag.isNotBlank()) putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            }
    }
}
