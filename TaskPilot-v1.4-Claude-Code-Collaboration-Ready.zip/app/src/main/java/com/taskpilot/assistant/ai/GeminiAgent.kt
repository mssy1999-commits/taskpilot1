package com.taskpilot.assistant.ai

import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Candidate
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.FinishReason
import com.google.firebase.ai.type.FunctionCallPart
import com.google.firebase.ai.type.FunctionCallingConfig
import com.google.firebase.ai.type.FunctionResponsePart
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.Part
import com.google.firebase.ai.type.RequestOptions
import com.google.firebase.ai.type.TextPart
import com.google.firebase.ai.type.ThinkingLevel
import com.google.firebase.ai.type.Tool
import com.google.firebase.ai.type.ToolConfig
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.thinkingConfig
import com.taskpilot.assistant.browser.BrowserToolExecutor
import com.taskpilot.assistant.data.AppSettings
import com.taskpilot.assistant.data.Attachment
import com.taskpilot.assistant.data.AttachmentKind
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.data.ChatMessage
import com.taskpilot.assistant.data.Role
import com.taskpilot.assistant.data.ToolStep
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.delay

/**
 * Gemini engine (via Firebase AI Logic, free tier available): send the conversation,
 * run any browser function calls through [BrowserToolRunner], feed results back,
 * repeat until Gemini answers in text.
 *
 * History is managed here (rather than with Chat) so old page snapshots and
 * attachments can be compacted to keep requests small, fast and cheap.
 */
class GeminiAgent(
    private val runner: BrowserToolRunner,
    private val repository: AttachmentRepository,
) : AssistantEngine {

    override val provider: AiProvider get() = AiProvider.GEMINI

    private val history = mutableListOf<Content>()
    private var model: GenerativeModel? = null

    private var currentModelName: String = ModelConfig.defaultModel
    override val modelName: String get() = currentModelName

    /** "minimal", "low", "medium" or "high" (ignored by Gemini 2.x, which uses a budget). */
    var thinkingLevel: String = ModelConfig.DEFAULT_THINKING
        private set

    override val modelDetail: String get() = "thinking $thinkingLevel"

    override suspend fun ensureReady() {
        ensureModel()
    }

    /** Creates the model on first use (model name and thinking level via Remote Config). */
    private suspend fun ensureModel(): GenerativeModel {
        model?.let { return it }
        if (!FirebaseSetup.isConfigured) throw FirebaseNotConfiguredException()
        val choice = ModelConfig.resolve()
        currentModelName = choice.name
        thinkingLevel = choice.thinkingLevel
        return createModel(choice).also { model = it }
    }

    private fun createModel(choice: ModelChoice): GenerativeModel {
        val thinking = if (ModelNames.usesThinkingBudget(choice.name)) {
            thinkingConfig { thinkingBudget = 1024 }
        } else {
            val level = when (choice.thinkingLevel) {
                "minimal" -> ThinkingLevel.MINIMAL
                "medium" -> ThinkingLevel.MEDIUM
                "high" -> ThinkingLevel.HIGH
                else -> ThinkingLevel.LOW
            }
            thinkingConfig { thinkingLevel = level } // less thinking = faster replies
        }
        val config = generationConfig {
            maxOutputTokens = 8192
            thinkingConfig = thinking
        }
        // useLimitedUseAppCheckTokens: prepares for App Check replay protection.
        val ai = Firebase.ai(backend = GenerativeBackend.googleAI(), useLimitedUseAppCheckTokens = true)
        return ai.generativeModel(
            currentModelName = choice.name,
            generationConfig = config,
            tools = listOf(Tool.functionDeclarations(BrowserToolDeclarations.all)),
            toolConfig = ToolConfig(FunctionCallingConfig.auto()),
            systemInstruction = content { text(AgentPrompt.system()) },
            requestOptions = RequestOptions(timeoutInMillis = 120_000L),
        )
    }

    /**
     * Calls Gemini, automatically retrying transient failures (overload, rate limit,
     * timeout, dropped connection) with growing waits. Repeating a model call is safe:
     * it has no side effects, and browser actions are never repeated here.
     * If the model rejects the configured thinking level, it falls back to "low".
     */
    private suspend fun generateWithRetry(listener: AgentListener): GenerateContentResponse {
        var attempt = 0
        var current = ensureModel()
        while (true) {
            try {
                val response = current.generateContent(history.toList())
                if (attempt > 0) listener.onStatus(null)
                return response
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (thinkingLevel != ModelConfig.DEFAULT_THINKING && "thinking" in e.message.orEmpty().lowercase()) {
                    thinkingLevel = ModelConfig.DEFAULT_THINKING
                    current = createModel(ModelChoice(modelName, thinkingLevel)).also { model = it }
                    continue
                }
                if (attempt >= AgentLimits.RETRY_DELAYS_MS.size || !AgentErrors.isTransient(e)) {
                    listener.onStatus(null)
                    throw e
                }
                val wait = AgentLimits.RETRY_DELAYS_MS[attempt]
                attempt++
                listener.onStatus(AgentLimits.retryStatus("Gemini", wait, attempt))
                delay(wait)
            }
        }
    }

    override fun clearHistory() = history.clear()

    override fun restore(messages: List<ChatMessage>) {
        history.clear()
        val relevant = messages.filter { it.role != Role.NOTE && !it.isError }.takeLast(AgentLimits.MAX_RESTORED_MESSAGES)
        for (m in relevant) {
            val role = if (m.role == Role.USER) "user" else "model"
            val text = if (m.role == Role.USER) AgentLimits.describeForHistory(m) else m.text
            if (text.isBlank()) continue
            appendMerged(Content(role, listOf(TextPart(text))))
        }
        while (history.isNotEmpty() && history.first().role != "user") history.removeAt(0)
    }

    /** Appends, merging with the previous entry if it has the same role (keeps turns alternating). */
    private fun appendMerged(c: Content) {
        val last = history.lastOrNull()
        if (last != null && last.role == c.role && c.parts.none { it is FunctionResponsePart } &&
            last.parts.none { it is FunctionResponsePart || it is FunctionCallPart }
        ) {
            history[history.lastIndex] = Content(last.role, last.parts + c.parts)
        } else {
            history += c
        }
    }

    private suspend fun buildUserContent(text: String, attachments: List<Attachment>): Content {
        val parts = mutableListOf<Part>()
        for (a in attachments) {
            when (a.kind) {
                AttachmentKind.IMAGE, AttachmentKind.PDF -> parts += InlineDataPart(repository.readBytes(a), a.mimeType)
                AttachmentKind.TEXT -> parts += TextPart(AgentLimits.attachedTextBlock(a.displayName, repository.readText(a)))
            }
        }
        if (attachments.isNotEmpty()) {
            parts += TextPart("Attached files: " + attachments.joinToString { "${it.displayName} (${it.kind.name.lowercase()})" })
        }
        parts += TextPart(text.ifBlank { "Please look at the attached file(s)." })
        return Content("user", parts)
    }

    override suspend fun runTurn(
        text: String,
        attachments: List<Attachment>,
        settings: AppSettings,
        listener: AgentListener,
    ): TurnResult {
        ensureModel()
        val userContent = buildUserContent(text, attachments)
        compactOldTurns()
        // Keep user/model turns alternating (e.g. after a reply that was never saved).
        if (history.lastOrNull()?.role == "user") {
            history += Content("model", listOf(TextPart(AgentLimits.NO_REPLY_MESSAGE)))
        }
        val checkpoint = history.size
        val steps = mutableListOf<ToolStep>()
        val budget = TurnBudget()
        try {
            history += userContent
            while (true) {
                budget.rounds++
                compactSnapshots()
                val response = generateWithRetry(listener)
                val candidate = response.candidates.firstOrNull()
                    ?: throw AgentException(blockedMessage(response))
                history += candidate.content

                val calls = response.functionCalls
                if (calls.isEmpty()) {
                    val reply = response.text?.trim().orEmpty()
                    return TurnResult(reply.ifEmpty { emptyReplyMessage(candidate) }, steps.toList())
                }

                val payloads = runner.runBatch(
                    calls.map { ProposedCall(it.name, ToolArgs.toPlain(it.args)) },
                    budget, settings, listener, steps,
                )
                history += Content("user", calls.zip(payloads) { call, payload -> FunctionResponsePart(call.name, payload, call.id) })

                if (budget.roundsExceeded) {
                    history += Content("model", listOf(TextPart(AgentLimits.STOPPED_MESSAGE)))
                    return TurnResult(AgentLimits.STOPPED_MESSAGE, steps.toList())
                }
            }
        } catch (e: Throwable) {
            // Never leave unanswered function calls in history: roll back this turn
            // and keep a short text record instead.
            while (history.size > checkpoint) history.removeAt(history.lastIndex)
            if (text.isNotBlank()) {
                appendMerged(Content("user", listOf(TextPart(text))))
                history += Content("model", listOf(TextPart(AgentLimits.INTERRUPTED_MESSAGE)))
            }
            throw e
        }
    }

    // ---- history compaction ------------------------------------------------------

    /** Keeps only the most recent page snapshot in full; older ones are summarized. */
    private fun compactSnapshots() {
        val indices = history.indices.filter { i ->
            history[i].parts.any { it is FunctionResponsePart && it.response.containsKey(BrowserToolExecutor.UNTRUSTED_KEY) }
        }
        if (indices.size <= 1) return
        for (i in indices.dropLast(1)) {
            val c = history[i]
            history[i] = Content(c.role, c.parts.map { p ->
                if (p is FunctionResponsePart && p.response.containsKey(BrowserToolExecutor.UNTRUSTED_KEY)) {
                    FunctionResponsePart(p.name, runner.compactedSnapshot(p.response), p.id)
                } else {
                    p
                }
            })
        }
    }

    /** Drops attachments from older turns and trims very long histories. */
    private fun compactOldTurns() {
        compactSnapshots()
        val withAttachments = history.indices.filter { i ->
            history[i].role == "user" && history[i].parts.any { it.isAttachmentPart() }
        }
        for (i in withAttachments.dropLast(AgentLimits.KEEP_ATTACHMENT_TURNS)) {
            val c = history[i]
            history[i] = Content(c.role, c.parts.map { p ->
                if (p.isAttachmentPart()) TextPart("[An attachment from earlier in the conversation is no longer included.]") else p
            })
        }
        if (history.size > MAX_HISTORY_CONTENTS) {
            val start = (history.size - MAX_HISTORY_CONTENTS until history.size).firstOrNull { i ->
                val c = history[i]
                c.role == "user" && c.parts.any { it is TextPart } && c.parts.none { it is FunctionResponsePart }
            }
            if (start != null) repeat(start) { history.removeAt(0) }
        }
    }

    private fun Part.isAttachmentPart(): Boolean =
        this is InlineDataPart || this is ImagePart || (this is TextPart && text.startsWith(AgentLimits.ATTACHED_TEXT_MARKER))

    private fun blockedMessage(response: GenerateContentResponse): String {
        val reason = response.promptFeedback?.blockReason?.name
        return if (reason != null) "Gemini blocked this request ($reason)." else "Gemini returned no answer. Please try again."
    }

    private fun emptyReplyMessage(candidate: Candidate): String = when (candidate.finishReason) {
        FinishReason.SAFETY -> "Gemini withheld the reply because of its safety filters."
        FinishReason.MAX_TOKENS -> "The reply was too long and got cut off. Try asking for a shorter answer."
        else -> "I don't have anything to add."
    }

    private companion object {
        const val MAX_HISTORY_CONTENTS = 80
    }
}
