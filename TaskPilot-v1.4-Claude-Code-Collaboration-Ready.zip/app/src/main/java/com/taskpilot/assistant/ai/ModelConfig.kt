package com.taskpilot.assistant.ai

import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.taskpilot.assistant.BuildConfig
import kotlinx.coroutines.withTimeoutOrNull

/** Model name plus thinking level ("minimal", "low", "medium" or "high"). */
data class ModelChoice(val name: String, val thinkingLevel: String)

/** Where the app sends Grok requests (your proxy) and which Grok model to use. */
data class GrokConfig(val proxyUrl: String, val model: String)

/**
 * Chooses the Gemini model. Defaults come from gradle.properties. Two Firebase
 * Remote Config parameters change them without rebuilding the APK (free on Spark):
 *  - [REMOTE_MODEL]  e.g. "gemini-3.5-flash-lite" for the fastest, lightest model
 *  - [REMOTE_THINKING] "minimal" | "low" | "medium" | "high" (less thinking = faster)
 * Changes reach the app on its next start (fetched at most every 10 minutes).
 */
object ModelConfig {
    const val REMOTE_MODEL = "gemini_model"
    const val REMOTE_THINKING = "thinking_level"
    /** Kept for older references in messages and docs. */
    const val REMOTE_KEY = REMOTE_MODEL
    const val DEFAULT_THINKING = "low"
    private const val TAG = "ModelConfig"

    val THINKING_LEVELS = listOf("minimal", "low", "medium", "high")

    val defaultModel: String =
        BuildConfig.DEFAULT_GEMINI_MODEL.takeIf { ModelNames.isValid(it) } ?: "gemini-3.5-flash-lite"

    val defaultChoice: ModelChoice get() = ModelChoice(defaultModel, DEFAULT_THINKING)

    // ---- Grok (xAI) via your own proxy --------------------------------------------

    const val REMOTE_GROK_URL = "grok_proxy_url"
    const val REMOTE_GROK_MODEL = "grok_model"

    val defaultGrokModel: String = BuildConfig.DEFAULT_GROK_MODEL.ifBlank { "grok-4.7" }

    private val GROK_MODEL = Regex("^grok-[a-z0-9][a-z0-9.\\-]{0,62}$")

    fun isValidGrokModel(name: String): Boolean = GROK_MODEL.matches(name)

    /**
     * Proxy URL and model for Grok. The URL is your Cloudflare Worker (see
     * backend/grok-proxy); it is not a secret. The xAI key lives only in the Worker.
     */
    suspend fun resolveGrok(): GrokConfig {
        val buildUrl = BuildConfig.GROK_PROXY_URL.trim()
        if (!FirebaseSetup.isConfigured) return GrokConfig(buildUrl, defaultGrokModel)
        return try {
            val rc = FirebaseRemoteConfig.getInstance()
            rc.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(600L).build()
            ).awaitResult()
            rc.setDefaultsAsync(
                mapOf<String, Any>(
                    REMOTE_MODEL to defaultModel,
                    REMOTE_THINKING to DEFAULT_THINKING,
                    REMOTE_GROK_URL to buildUrl,
                    REMOTE_GROK_MODEL to defaultGrokModel,
                )
            ).awaitResult()
            withTimeoutOrNull(5_000L) { rc.fetchAndActivate().awaitResult() }
            val url = rc.getString(REMOTE_GROK_URL).trim().ifBlank { buildUrl }
            val model = rc.getString(REMOTE_GROK_MODEL).trim().takeIf { isValidGrokModel(it) } ?: defaultGrokModel
            GrokConfig(url, model)
        } catch (e: Exception) {
            Log.w(TAG, "Remote Config unavailable; using Grok defaults", e)
            GrokConfig(buildUrl, defaultGrokModel)
        }
    }

    suspend fun resolve(): ModelChoice {
        if (!FirebaseSetup.isConfigured) return defaultChoice
        return try {
            val rc = FirebaseRemoteConfig.getInstance()
            rc.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(600L).build()
            ).awaitResult()
            rc.setDefaultsAsync(
                mapOf<String, Any>(REMOTE_MODEL to defaultModel, REMOTE_THINKING to DEFAULT_THINKING)
            ).awaitResult()
            withTimeoutOrNull(5_000L) { rc.fetchAndActivate().awaitResult() }
            val model = rc.getString(REMOTE_MODEL).trim().takeIf { ModelNames.isValid(it) } ?: defaultModel
            val thinking = rc.getString(REMOTE_THINKING).trim().lowercase().takeIf { it in THINKING_LEVELS } ?: DEFAULT_THINKING
            ModelChoice(model, thinking)
        } catch (e: Exception) {
            Log.w(TAG, "Remote Config unavailable; using defaults", e)
            defaultChoice
        }
    }
}
