package com.taskpilot.assistant.policy

/**
 * Encodes data as JavaScript literals for the app's fixed browser scripts.
 *
 * The only way model- or page-derived values enter a script is through these
 * functions, which produce inert literals (never code). Strings are emitted as
 * pure-ASCII double-quoted literals: every character outside printable ASCII,
 * plus quotes, backslashes and angle brackets, is \u-escaped.
 */
object JsLiteral {

    fun string(value: String): String {
        val sb = StringBuilder(value.length + 16)
        sb.append('"')
        for (ch in value) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '<', '>', '\'', '`', '&' -> appendUnicodeEscape(sb, ch)
                else -> if (ch.code < 0x20 || ch.code >= 0x7F) appendUnicodeEscape(sb, ch) else sb.append(ch)
            }
        }
        sb.append('"')
        return sb.toString()
    }

    fun int(value: Int): String = value.toString()

    fun bool(value: Boolean): String = if (value) "true" else "false"

    private fun appendUnicodeEscape(sb: StringBuilder, ch: Char) {
        sb.append("\\u")
        val hex = ch.code.toString(16).uppercase()
        repeat(4 - hex.length) { sb.append('0') }
        sb.append(hex)
    }
}
