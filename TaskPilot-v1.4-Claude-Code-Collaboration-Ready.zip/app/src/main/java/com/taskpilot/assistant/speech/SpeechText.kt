package com.taskpilot.assistant.speech

/** Turns a Markdown-ish assistant reply into text that sounds natural when spoken. */
object SpeechText {
    private val CODE_BLOCK = Regex("```[\\s\\S]*?```")
    private val INLINE_CODE = Regex("`([^`]*)`")
    private val MD_LINK = Regex("\\[([^\\]]+)]\\((?:[^)\\s]+)\\)")
    private val BARE_URL = Regex("https?://([^/\\s)]+)[^\\s)]*")
    private val HEADING = Regex("(?m)^\\s{0,3}#{1,6}\\s*")
    private val QUOTE = Regex("(?m)^\\s*>\\s?")
    private val BULLET = Regex("(?m)^\\s*[-*+•]\\s+")
    private val EMPHASIS = Regex("(\\*\\*|__|\\*|_|~~)(?=\\S)(.+?)(?<=\\S)\\1")
    private val TABLE_PIPES = Regex("\\s*\\|\\s*")
    private val TABLE_RULE = Regex("(?m)^[\\s|:-]{3,}$")
    private val MULTI_SPACE = Regex("[ \\t]{2,}")
    private val MULTI_NEWLINE = Regex("\\n{2,}")

    fun clean(markdown: String): String {
        var t = markdown
        t = CODE_BLOCK.replace(t, " (code omitted) ")
        t = MD_LINK.replace(t) { it.groupValues[1] }
        t = BARE_URL.replace(t) { "a link to " + it.groupValues[1].removePrefix("www.") }
        t = INLINE_CODE.replace(t) { it.groupValues[1] }
        t = HEADING.replace(t, "")
        t = QUOTE.replace(t, "")
        t = BULLET.replace(t, "")
        t = TABLE_RULE.replace(t, "")
        t = EMPHASIS.replace(t) { it.groupValues[2] }
        t = TABLE_PIPES.replace(t, ", ")
        t = MULTI_SPACE.replace(t, " ")
        t = MULTI_NEWLINE.replace(t, "\n")
        return t.lines().joinToString("\n") { it.trim().trim(',').trim() }.trim()
    }

    /** True if the text is mostly written in Arabic script. */
    fun isMostlyArabic(text: String): Boolean {
        var arabic = 0
        var latin = 0
        for (c in text) {
            when {
                c in '؀'..'ۿ' || c in 'ݐ'..'ݿ' -> arabic++
                c in 'a'..'z' || c in 'A'..'Z' -> latin++
            }
        }
        return arabic > 0 && arabic >= latin
    }

    /** Splits long text into chunks no longer than [max] characters at sentence breaks. */
    fun chunk(text: String, max: Int): List<String> {
        if (text.length <= max) return listOf(text)
        val out = mutableListOf<String>()
        var rest = text
        while (rest.length > max) {
            val window = rest.substring(0, max)
            val cut = maxOf(window.lastIndexOf(". "), window.lastIndexOf('\n'), window.lastIndexOf("؟ "), window.lastIndexOf("? "))
                .takeIf { it > max / 3 }?.plus(1) ?: window.lastIndexOf(' ').takeIf { it > 0 } ?: max
            out += rest.substring(0, cut).trim()
            rest = rest.substring(cut).trimStart()
        }
        if (rest.isNotBlank()) out += rest.trim()
        return out.filter { it.isNotEmpty() }
    }
}
