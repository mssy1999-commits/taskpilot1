package com.taskpilot.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.taskpilot.assistant.R
import com.taskpilot.assistant.browser.AgentWebView
import com.taskpilot.assistant.browser.BrowserController
import com.taskpilot.assistant.browser.BrowserWebViewFactory
import com.taskpilot.assistant.ui.BrowserMode

/**
 * The in-app browser. It stays composed (and laid out at full size behind the chat
 * when hidden) so the page keeps a real viewport for automation.
 */
@Composable
fun BrowserPanel(
    controller: BrowserController,
    mode: BrowserMode,
    onModeChange: (BrowserMode) -> Unit,
    onError: (String) -> Unit,
    modifier: Modifier = Modifier,
    blockImages: Boolean = false,
) {
    val state by controller.state.collectAsStateWithLifecycle()
    val generation by controller.rendererGeneration.collectAsStateWithLifecycle()

    Column(modifier.background(MaterialTheme.colorScheme.surface)) {
        if (mode != BrowserMode.HIDDEN) {
            BrowserToolbar(
                url = state.url,
                isLoading = state.isLoading,
                canGoBack = state.canGoBack,
                mode = mode,
                onBack = controller::userBack,
                onReloadOrStop = { if (state.isLoading) controller.userStop() else controller.userReload() },
                onNavigate = { input -> controller.userNavigate(input)?.let(onError) },
                onModeChange = onModeChange,
            )
        }
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            if (state.isLoading && mode != BrowserMode.HIDDEN) {
                LinearProgressIndicator(progress = { state.progress / 100f }, modifier = Modifier.fillMaxSize())
            }
        }
        key(generation) {
            val context = LocalContext.current
            val webView = remember { BrowserWebViewFactory.create(context, controller) }
            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(webView, lifecycleOwner) {
                controller.attach(webView)
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_RESUME -> webView.onResume()
                        Lifecycle.Event.ON_PAUSE -> webView.onPause()
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                    controller.detach(webView)
                    destroyQuietly(webView)
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    factory = { webView },
                    modifier = Modifier.fillMaxSize(),
                    update = { view ->
                        view.userInputEnabled = mode != BrowserMode.HIDDEN
                        // Skipping images makes pages load much faster on slow mobile data.
                        if (view.settings.blockNetworkImage != blockImages) view.settings.blockNetworkImage = blockImages
                    },
                )
                if (state.url.isBlank() && mode != BrowserMode.HIDDEN) {
                    Box(
                        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "The assistant's browser.\nAsk it to look something up, or type an address above.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp),
                        )
                    }
                }
            }
        }
    }
}

private fun destroyQuietly(view: AgentWebView) {
    try {
        view.stopLoading()
        (view.parent as? android.view.ViewGroup)?.removeView(view)
        view.destroy()
    } catch (_: Exception) {
        // Already destroyed after a renderer crash.
    }
}

@Composable
private fun BrowserToolbar(
    url: String,
    isLoading: Boolean,
    canGoBack: Boolean,
    mode: BrowserMode,
    onBack: () -> Unit,
    onReloadOrStop: () -> Unit,
    onNavigate: (String) -> Unit,
    onModeChange: (BrowserMode) -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack, enabled = canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            AddressField(url = url, onNavigate = onNavigate, modifier = Modifier.weight(1f))
            IconButton(onClick = onReloadOrStop) {
                if (isLoading) {
                    Icon(Icons.Default.Close, contentDescription = "Stop loading")
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = "Reload")
                }
            }
            IconButton(onClick = { onModeChange(if (mode == BrowserMode.FULL) BrowserMode.SPLIT else BrowserMode.FULL) }) {
                Icon(
                    painterResource(if (mode == BrowserMode.FULL) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen),
                    contentDescription = if (mode == BrowserMode.FULL) "Show chat" else "Expand browser",
                )
            }
            IconButton(onClick = { onModeChange(BrowserMode.HIDDEN) }) {
                Icon(Icons.Default.Close, contentDescription = "Hide browser")
            }
        }
    }
}

@Composable
private fun AddressField(url: String, onNavigate: (String) -> Unit, modifier: Modifier = Modifier) {
    var editing by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    LaunchedEffect(url, editing) { if (!editing) text = url }

    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .background(MaterialTheme.colorScheme.surfaceContainerHighest, shape)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (url.startsWith("https://") && !editing) {
            Icon(
                Icons.Default.Lock,
                contentDescription = "Secure connection",
                modifier = Modifier.size(14.dp).padding(end = 2.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        BasicTextField(
            value = if (editing) text else displayHost(url),
            onValueChange = { text = it },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go, autoCorrectEnabled = false),
            keyboardActions = KeyboardActions(onGo = {
                if (text.isNotBlank()) onNavigate(text.trim())
                focusManager.clearFocus()
            }),
            modifier = Modifier
                .weight(1f)
                .padding(start = 4.dp)
                .onFocusChanged { f ->
                    if (f.isFocused && !editing) text = url
                    editing = f.isFocused
                },
        )
    }
}

private fun displayHost(url: String): String =
    url.removePrefix("https://").removePrefix("http://").removePrefix("www.").ifBlank { "Enter an address" }
        .let { if (it.length > 60) it.take(59) + "…" else it }
