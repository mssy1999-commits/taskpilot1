package com.taskpilot.assistant.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.taskpilot.assistant.TaskPilotApp
import com.taskpilot.assistant.ai.AgentErrors
import com.taskpilot.assistant.ai.AgentListener
import com.taskpilot.assistant.ai.AiProvider
import com.taskpilot.assistant.ai.AppCheckProviders
import com.taskpilot.assistant.ai.AssistantEngine
import com.taskpilot.assistant.ai.BrowserToolRunner
import com.taskpilot.assistant.ai.FirebaseSetup
import com.taskpilot.assistant.ai.GeminiAgent
import com.taskpilot.assistant.ai.GrokAgent
import com.taskpilot.assistant.ai.LocalAgent
import com.taskpilot.assistant.ai.OfflineModelStore
import com.taskpilot.assistant.ai.WebsiteBuilder
import com.taskpilot.assistant.ai.WebsiteFiles
import com.taskpilot.assistant.ai.TurnResult
import com.taskpilot.assistant.browser.BrowserController
import com.taskpilot.assistant.browser.BrowserToolExecutor
import com.taskpilot.assistant.data.AppSettings
import com.taskpilot.assistant.data.Attachment
import com.taskpilot.assistant.data.AttachmentKind
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.data.AttachmentTypes
import com.taskpilot.assistant.data.ChatMessage
import com.taskpilot.assistant.data.Role
import com.taskpilot.assistant.data.ToolStep
import com.taskpilot.assistant.policy.ConfirmationRequest
import com.taskpilot.assistant.speech.SpeechInputController
import com.taskpilot.assistant.speech.SpeechOutputController
import com.taskpilot.assistant.speech.VoiceState
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class BrowserMode { HIDDEN, SPLIT, FULL }

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val draft: String = "",
    val pendingAttachments: List<Attachment> = emptyList(),
    val importingCount: Int = 0,
    val isRunning: Boolean = false,
    val liveSteps: List<ToolStep> = emptyList(),
    /** Transient status while working, e.g. an automatic retry. */
    val status: String? = null,
    val browserMode: BrowserMode = BrowserMode.HIDDEN,
    val confirmation: ConfirmationRequest? = null,
    val firebaseConfigured: Boolean = false,
    val provider: AiProvider = AiProvider.GEMINI,
    val modelName: String = "",
    /** E.g. "thinking low" for Gemini. */
    val modelDetail: String = "",
    val loaded: Boolean = false,
    /** A one-shot request to open Android Save As for a generated, verified site. */
    val websiteExportName: String? = null,
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as TaskPilotApp).container
    private val settingsStore = container.settingsStore
    private val store = container.conversationStore
    val attachmentRepository: AttachmentRepository = container.attachmentRepository

    val browser = BrowserController()
    private val runner = BrowserToolRunner(browser, BrowserToolExecutor(browser))
    private val offlineModelStore = OfflineModelStore(application)
    private val websiteFiles = WebsiteFiles(application)
    private val localAgent = LocalAgent(offlineModelStore, container.attachmentRepository, runner)
    private val engines: Map<AiProvider, AssistantEngine> = mapOf(
        AiProvider.GEMINI to GeminiAgent(runner, container.attachmentRepository),
        AiProvider.GROK to GrokAgent(runner, container.attachmentRepository),
        AiProvider.LOCAL to localAgent,
    )

    /** The engine for the provider selected in Settings. */
    private val engine: AssistantEngine get() = engines.getValue(settingsStore.current.aiProvider)

    private val speechIn = SpeechInputController(application)
    private val speechOut = SpeechOutputController(application)

    private val _ui = MutableStateFlow(
        ChatUiState(
            firebaseConfigured = FirebaseSetup.isConfigured,
            provider = settingsStore.current.aiProvider,
            modelName = engines.getValue(settingsStore.current.aiProvider).modelName,
        )
    )
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsStore.settings
    val voiceState: StateFlow<VoiceState> = speechIn.state
    val speakingMessageId: StateFlow<String?> = speechOut.speakingMessageId
    val speaking: StateFlow<Boolean> = speechOut.speaking

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 16)
    /** One-off messages for a snackbar. */
    val events: SharedFlow<String> = _events.asSharedFlow()

    private var runJob: Job? = null
    private var confirmationDeferred: CompletableDeferred<Boolean>? = null
    private var browserShownThisTurn = false
    private var turnStartedByVoice = false

    init {
        viewModelScope.launch {
            val saved = if (settingsStore.current.saveHistory) store.load() else emptyList()
            engine.restore(saved)
            _ui.update { it.copy(messages = saved, loaded = true) }
            store.deleteAttachmentsExcept(saved.flatMap { m -> m.attachments.map { it.fileName } }.toSet())
        }
        prepareEngine()
        viewModelScope.launch { browser.notices.collect { notify(it) } }
    }

    /** Resolves the selected engine's configuration so the UI can show its model. */
    private fun prepareEngine() {
        val current = engine
        _ui.update { it.copy(provider = current.provider, modelName = current.modelName, modelDetail = current.modelDetail) }
        if (!FirebaseSetup.isConfigured && current.provider != AiProvider.LOCAL) return
        viewModelScope.launch {
            try {
                current.ensureReady()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Reported when the user sends a message.
            }
            if (engine === current) {
                _ui.update { it.copy(provider = current.provider, modelName = current.modelName, modelDetail = current.modelDetail) }
            }
        }
    }

    // ---- composing ------------------------------------------------------------------

    fun onDraftChange(text: String) = _ui.update { it.copy(draft = text) }

    fun usePrompt(text: String) = _ui.update { it.copy(draft = text) }

    fun addAttachments(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val state = _ui.value
        val room = AttachmentTypes.MAX_ATTACHMENTS_PER_MESSAGE - state.pendingAttachments.size - state.importingCount
        if (room <= 0) {
            notify("You can attach up to ${AttachmentTypes.MAX_ATTACHMENTS_PER_MESSAGE} files per message.")
            return
        }
        val accepted = uris.take(room)
        if (uris.size > room) notify("Only the first $room file(s) were added (limit ${AttachmentTypes.MAX_ATTACHMENTS_PER_MESSAGE}).")
        _ui.update { it.copy(importingCount = it.importingCount + accepted.size) }
        viewModelScope.launch {
            for (uri in accepted) {
                try {
                    when (val r = attachmentRepository.import(uri)) {
                        is AttachmentRepository.ImportResult.Success -> {
                            val a = r.attachment
                            val inlineTotal = _ui.value.pendingAttachments.filter { it.kind != AttachmentKind.TEXT }.sumOf { it.sizeBytes } +
                                (if (a.kind != AttachmentKind.TEXT) a.sizeBytes else 0L)
                            if (inlineTotal > AttachmentTypes.MAX_INLINE_BYTES_PER_MESSAGE) {
                                attachmentRepository.delete(a)
                                notify("Images and PDFs in one message can't exceed ${AttachmentTypes.formatSize(AttachmentTypes.MAX_INLINE_BYTES_PER_MESSAGE)} in total.")
                            } else {
                                _ui.update { it.copy(pendingAttachments = it.pendingAttachments + a) }
                            }
                        }
                        is AttachmentRepository.ImportResult.Failure -> notify(r.message)
                    }
                } finally {
                    _ui.update { it.copy(importingCount = (it.importingCount - 1).coerceAtLeast(0)) }
                }
            }
        }
    }

    fun removePendingAttachment(attachment: Attachment) {
        _ui.update { it.copy(pendingAttachments = it.pendingAttachments - attachment) }
        viewModelScope.launch { attachmentRepository.delete(attachment) }
    }

    // ---- sending ----------------------------------------------------------------------

    fun send() {
        val state = _ui.value
        if (state.isRunning) return
        val text = state.draft.trim()
        val attachments = state.pendingAttachments
        if (text.isEmpty() && attachments.isEmpty()) return
        if (state.importingCount > 0) {
            notify("Please wait until the attachments finish loading.")
            return
        }
        val byVoice = turnStartedByVoice
        turnStartedByVoice = false
        speechOut.stop()

        val userMessage = ChatMessage(newId(), Role.USER, text, attachments = attachments, createdAt = System.currentTimeMillis())
        _ui.update {
            it.copy(
                messages = it.messages + userMessage,
                draft = "",
                pendingAttachments = emptyList(),
                isRunning = true,
                liveSteps = emptyList(),
            )
        }
        persist()
        browserShownThisTurn = false

        val activeEngine = engine
        runJob = viewModelScope.launch {
            try {
                val result = when {
                    attachments.isEmpty() && WebsiteBuilder.recognizes(text) -> {
                        agentListener.onStatus("Creating and verifying website on this phone…")
                        val site = WebsiteBuilder.build(text)
                        val saved = websiteFiles.create(site)
                        val preview = browser.previewGeneratedHtml(site.html)
                        _ui.update {
                            it.copy(
                                websiteExportName = site.fileName,
                                browserMode = if (preview) BrowserMode.SPLIT else it.browserMode,
                            )
                        }
                        TurnResult(
                            "Created and VERIFIED a responsive HTML website template for ${site.title}. " +
                                "Saved locally (${saved.length()} bytes). " +
                                (if (preview) "Preview opened in the browser pane. " else "Preview not available; browser still loading. ") +
                                "Choose a location in Android's Save As window to export ${site.fileName}. " +
                                "This is a template, not an automatically published website. " +
                                "Edit its placeholder content before sharing.",
                            emptyList(),
                        )
                    }
                    attachments.isEmpty() && text.matches(Regex("""(?i)^/?(?:export|save|download)\s+(?:the\s+)?(?:last\s+)?(?:website|site)(?:\s+file)?$""")) -> {
                        val saved = websiteFiles.latest()
                        if (saved != null) {
                            _ui.update { it.copy(websiteExportName = saved.name) }
                            TurnResult("Opening Android Save As to export ${saved.name}.", emptyList())
                        } else {
                            TurnResult("No website created yet. Try: make website for my business", emptyList())
                        }
                    }
                    else -> activeEngine.runTurn(text, attachments, settingsStore.current, agentListener)
                }
                val reply = ChatMessage(newId(), Role.ASSISTANT, result.text, steps = result.steps, createdAt = System.currentTimeMillis())
                _ui.update {
                    it.copy(
                        messages = it.messages + reply,
                        provider = activeEngine.provider,
                        modelName = activeEngine.modelName,
                        modelDetail = activeEngine.modelDetail,
                    )
                }
                if (settingsStore.current.speakReplies || byVoice) speechOut.speak(result.text, reply.id)
            } catch (e: CancellationException) {
                addNote("Stopped.", isError = false)
                throw e
            } catch (e: Exception) {
                addNote(AgentErrors.userMessage(e, activeEngine.modelName), isError = true)
            } finally {
                confirmationDeferred?.cancel()
                confirmationDeferred = null
                _ui.update { it.copy(isRunning = false, liveSteps = emptyList(), status = null, confirmation = null) }
                persist()
            }
        }
    }

    /** Mark the one-shot export intent as consumed before Android opens its picker. */
    fun websiteExportPickerOpening() {
        _ui.update { it.copy(websiteExportName = null) }
    }

    fun websiteExportCanceled() {
        notify("Website remains saved in TaskPilot. Type 'export website' to save it later.")
    }

    fun exportWebsite(uri: Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val bytes = websiteFiles.export(uri)
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    addNote("Export VERIFIED: $bytes bytes saved to the selected document. This website has not been published online.", isError = false)
                    persist()
                }
            } catch (e: Exception) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    addNote("Website export could not be verified: ${e.message ?: "Unknown error"}. The original remains saved inside TaskPilot.", isError = true)
                    persist()
                }
            }
        }
    }

    fun stop() {
        confirmationDeferred?.cancel()
        runJob?.cancel()
        speechOut.stop()
    }

    private fun addNote(text: String, isError: Boolean) {
        val steps = _ui.value.liveSteps
        val note = ChatMessage(newId(), Role.NOTE, text, steps = steps, isError = isError, createdAt = System.currentTimeMillis())
        _ui.update { it.copy(messages = it.messages + note) }
    }

    private val agentListener = object : AgentListener {
        override fun onStepsChanged(steps: List<ToolStep>) {
            _ui.update { it.copy(liveSteps = steps) }
        }

        override fun onStatus(message: String?) {
            _ui.update { it.copy(status = message) }
        }

        override fun onBrowserActivity() {
            if (!browserShownThisTurn && _ui.value.browserMode == BrowserMode.HIDDEN) {
                _ui.update { it.copy(browserMode = BrowserMode.SPLIT) }
            }
            browserShownThisTurn = true
        }

        override suspend fun confirm(request: ConfirmationRequest): Boolean {
            val deferred = CompletableDeferred<Boolean>()
            confirmationDeferred = deferred
            speechOut.stop()
            _ui.update {
                it.copy(
                    confirmation = request,
                    browserMode = if (it.browserMode == BrowserMode.HIDDEN) BrowserMode.SPLIT else it.browserMode,
                )
            }
            return try {
                deferred.await()
            } finally {
                if (confirmationDeferred === deferred) confirmationDeferred = null
                _ui.update { it.copy(confirmation = null) }
            }
        }
    }

    fun answerConfirmation(approved: Boolean) {
        confirmationDeferred?.complete(approved)
    }

    // ---- browser ------------------------------------------------------------------------

    fun setBrowserMode(mode: BrowserMode) = _ui.update { it.copy(browserMode = mode) }

    /** Opens a link (e.g. tapped in a reply) in the in-app browser after validation. */
    fun openInBrowser(url: String) {
        val error = browser.userNavigate(url)
        if (error != null) notify(error) else _ui.update {
            it.copy(browserMode = if (it.browserMode == BrowserMode.HIDDEN) BrowserMode.SPLIT else it.browserMode)
        }
    }

    // ---- voice ------------------------------------------------------------------------------

    val speechRecognitionAvailable: Boolean get() = speechIn.isAvailable

    fun startVoice() {
        speechOut.stop()
        speechIn.start(settingsStore.current.voiceLanguage) { text -> onVoiceText(text) }
    }

    fun stopVoice() = speechIn.stop()

    fun cancelVoice() = speechIn.cancel()

    fun clearVoiceError() = speechIn.clearError()

    /** Final text from in-app recognition or the system speech dialog. */
    fun onVoiceText(text: String) {
        val merged = listOf(_ui.value.draft.trim(), text.trim()).filter { it.isNotEmpty() }.joinToString(" ")
        _ui.update { it.copy(draft = merged) }
        if (settingsStore.current.autoSendVoice && !_ui.value.isRunning) {
            turnStartedByVoice = true
            send()
        }
    }

    fun speak(message: ChatMessage) = speechOut.speak(message.text, message.id)

    fun stopSpeaking() = speechOut.stop()

    // ---- settings & data ---------------------------------------------------------------------

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val before = settingsStore.current
        settingsStore.update(transform)
        val after = settingsStore.current
        if (before.saveHistory != after.saveHistory) {
            viewModelScope.launch {
                if (after.saveHistory) store.save(_ui.value.messages) else store.deleteTranscript()
            }
        }
        if (!after.speakReplies && before.speakReplies) speechOut.stop()
        if (before.aiProvider != after.aiProvider) {
            // The newly selected engine continues from the saved conversation (text only).
            engines.getValue(after.aiProvider).restore(_ui.value.messages)
            prepareEngine()
        }
    }

    fun clearConversation() {
        if (_ui.value.isRunning) stop()
        engines.values.forEach { it.clearHistory() }
        speechOut.stop()
        val keep = _ui.value.pendingAttachments.map { it.fileName }.toSet()
        _ui.update { it.copy(messages = emptyList()) }
        viewModelScope.launch {
            store.deleteTranscript()
            store.deleteAttachmentsExcept(keep)
            notify("Conversation cleared.")
        }
    }

    fun clearBrowserData() {
        browser.clearBrowsingData()
        notify("Browser cookies, history, cache and site data cleared.")
    }

    /** Conversation, attachments, browser data and settings. */
    fun clearAllData() {
        if (_ui.value.isRunning) stop()
        engines.values.forEach { it.clearHistory() }
        speechOut.stop()
        browser.clearBrowsingData()
        settingsStore.clear()
        prepareEngine()
        _ui.update { it.copy(messages = emptyList(), pendingAttachments = emptyList(), draft = "") }
        viewModelScope.launch {
            store.deleteTranscript()
            store.deleteAttachmentsExcept(emptySet())
            notify("All app data on this device was cleared.")
        }
    }

    suspend fun storageBytes(): Long = store.storageBytes()

    fun appCheckDebugToken(): String? = AppCheckProviders.readDebugToken(getApplication())

    fun offlineModelStatus(): String = if (offlineModelStore.isInstalled) {
        "Installed · ${offlineModelStore.modelSizeBytes / (1024 * 1024)} MB · saved privately on this phone"
    } else "Not installed · select a .litertlm model downloaded to your phone"

    fun importOfflineModel(uri: Uri) {
        if (_ui.value.isRunning) { notify("Stop the current task before switching models."); return }
        viewModelScope.launch {
            _ui.update { it.copy(status = "Importing offline AI model…") }
            try {
                val size = offlineModelStore.import(uri)
                localAgent.close() // release the old model before it is loaded again
                settingsStore.update { it.copy(aiProvider = AiProvider.LOCAL) }
                localAgent.restore(_ui.value.messages)
                prepareEngine()
                notify("Offline model imported (${size / (1024 * 1024)} MB). Offline AI is now selected.")
            } catch (e: Exception) {
                notify("Model import failed: ${e.message ?: "Could not read this file"}")
            } finally {
                _ui.update { it.copy(status = null) }
            }
        }
    }

    // ---- helpers ---------------------------------------------------------------------------

    private fun persist() {
        if (!settingsStore.current.saveHistory) return
        val snapshot = _ui.value.messages
        viewModelScope.launch { store.save(snapshot) }
    }

    private fun notify(message: String) {
        _events.tryEmit(message)
    }

    private fun newId(): String = UUID.randomUUID().toString()

    override fun onCleared() {
        speechIn.cancel()
        speechOut.shutdown()
        localAgent.close()
        super.onCleared()
    }
}
