package com.taskpilot.assistant.policy

/**
 * The complete, closed set of browser tools the model may call. Anything that is
 * not one of these (or that has invalid arguments) is rejected before it reaches
 * the WebView. Each action is executed by a fixed, app-authored script; the model
 * never supplies JavaScript.
 */
object BrowserTools {
    const val OPEN_URL = "open_url"
    const val WEB_SEARCH = "web_search"
    const val READ_PAGE = "read_page"
    const val CLICK = "click"
    const val TYPE_TEXT = "type_text"
    const val SELECT_OPTION = "select_option"
    const val SCROLL = "scroll"
    const val GO_BACK = "go_back"

    /** Allowed argument names per tool. */
    val ARGUMENTS: Map<String, Set<String>> = mapOf(
        OPEN_URL to setOf("url"),
        WEB_SEARCH to setOf("query"),
        READ_PAGE to setOf("max_chars"),
        CLICK to setOf("element_id"),
        TYPE_TEXT to setOf("element_id", "text", "submit"),
        SELECT_OPTION to setOf("element_id", "option"),
        SCROLL to setOf("direction"),
        GO_BACK to setOf("reason"),
    )

    val ALL: Set<String> = ARGUMENTS.keys
}

enum class ScrollDirection(val wire: String) {
    DOWN("down"), UP("up"), TOP("top"), BOTTOM("bottom");

    companion object {
        fun fromWire(value: String): ScrollDirection? =
            entries.firstOrNull { it.wire == value.trim().lowercase() }
    }
}

/** A validated, typed browser action. Construct only through [ToolCallParser]. */
sealed interface BrowserAction {
    val tool: String

    /** Actions that only observe the page. */
    val isPassive: Boolean get() = false

    data class OpenUrl(val url: String, val host: String) : BrowserAction {
        override val tool get() = BrowserTools.OPEN_URL
    }

    data class WebSearch(val query: String) : BrowserAction {
        override val tool get() = BrowserTools.WEB_SEARCH
    }

    data class ReadPage(val maxChars: Int) : BrowserAction {
        override val tool get() = BrowserTools.READ_PAGE
        override val isPassive get() = true
    }

    data class Click(val elementId: String) : BrowserAction {
        override val tool get() = BrowserTools.CLICK
    }

    data class TypeText(val elementId: String, val text: String, val submit: Boolean) : BrowserAction {
        override val tool get() = BrowserTools.TYPE_TEXT
    }

    data class SelectOption(val elementId: String, val option: String) : BrowserAction {
        override val tool get() = BrowserTools.SELECT_OPTION
    }

    data class Scroll(val direction: ScrollDirection) : BrowserAction {
        override val tool get() = BrowserTools.SCROLL
        override val isPassive get() = true
    }

    data object GoBack : BrowserAction {
        override val tool get() = BrowserTools.GO_BACK
    }

    /** Element the action targets, if any. */
    val targetElementId: String?
        get() = when (this) {
            is Click -> elementId
            is TypeText -> elementId
            is SelectOption -> elementId
            else -> null
        }
}

sealed interface ParseResult {
    data class Ok(val action: BrowserAction) : ParseResult
    data class Rejected(val reason: String) : ParseResult
}

/**
 * Converts a model-proposed function call into a [BrowserAction], enforcing the
 * tool allowlist, argument allowlist, types and size limits.
 *
 * Argument values are expected as plain Kotlin values (String, Boolean, Number or
 * null) already converted from JSON.
 */
object ToolCallParser {
    private val ELEMENT_ID = Regex("^e[0-9]{1,5}$")

    const val MAX_TEXT_LENGTH = 2000
    const val MAX_QUERY_LENGTH = 400
    const val MAX_OPTION_LENGTH = 300
    const val DEFAULT_READ_CHARS = 6000
    const val MIN_READ_CHARS = 500
    const val MAX_READ_CHARS = 20000

    fun parse(name: String, args: Map<String, Any?>): ParseResult {
        val allowed = BrowserTools.ARGUMENTS[name]
            ?: return ParseResult.Rejected(
                "Unknown tool \"${name.take(40)}\". Allowed tools: ${BrowserTools.ALL.joinToString()}."
            )
        val unexpected = args.keys - allowed
        if (unexpected.isNotEmpty()) {
            return ParseResult.Rejected(
                "Unexpected argument(s) for $name: ${unexpected.joinToString { it.take(30) }}."
            )
        }
        return try {
            ParseResult.Ok(build(name, args))
        } catch (e: InvalidArgument) {
            ParseResult.Rejected(e.message ?: "Invalid arguments for $name.")
        }
    }

    private fun build(name: String, args: Map<String, Any?>): BrowserAction = when (name) {
        BrowserTools.OPEN_URL -> {
            val raw = requireString(args, "url", UrlPolicy.MAX_URL_LENGTH)
            when (val r = UrlPolicy.validateNavigation(raw)) {
                is UrlPolicy.Result.Allowed -> BrowserAction.OpenUrl(r.url, r.host)
                is UrlPolicy.Result.Rejected -> throw InvalidArgument(r.reason)
            }
        }
        BrowserTools.WEB_SEARCH -> BrowserAction.WebSearch(requireString(args, "query", MAX_QUERY_LENGTH))
        BrowserTools.READ_PAGE -> {
            val n = optionalInt(args, "max_chars") ?: DEFAULT_READ_CHARS
            BrowserAction.ReadPage(n.coerceIn(MIN_READ_CHARS, MAX_READ_CHARS))
        }
        BrowserTools.CLICK -> BrowserAction.Click(requireElementId(args))
        BrowserTools.TYPE_TEXT -> BrowserAction.TypeText(
            elementId = requireElementId(args),
            text = requireString(args, "text", MAX_TEXT_LENGTH, allowEmpty = true, allowNewlines = true),
            submit = optionalBoolean(args, "submit") ?: false,
        )
        BrowserTools.SELECT_OPTION -> BrowserAction.SelectOption(
            elementId = requireElementId(args),
            option = requireString(args, "option", MAX_OPTION_LENGTH),
        )
        BrowserTools.SCROLL -> {
            val raw = requireString(args, "direction", 10)
            BrowserAction.Scroll(
                ScrollDirection.fromWire(raw)
                    ?: throw InvalidArgument("direction must be one of: down, up, top, bottom.")
            )
        }
        BrowserTools.GO_BACK -> BrowserAction.GoBack
        else -> throw InvalidArgument("Unknown tool.")
    }

    private class InvalidArgument(message: String) : Exception(message)

    private fun requireElementId(args: Map<String, Any?>): String {
        val id = requireString(args, "element_id", 8).lowercase()
        if (!ELEMENT_ID.matches(id)) {
            throw InvalidArgument(
                "element_id must look like \"e12\" (an id from the latest read_page result)."
            )
        }
        return id
    }

    private fun requireString(
        args: Map<String, Any?>,
        key: String,
        maxLength: Int,
        allowEmpty: Boolean = false,
        allowNewlines: Boolean = false,
    ): String {
        val value = args[key] ?: throw InvalidArgument("Missing required argument \"$key\".")
        if (value !is String) throw InvalidArgument("Argument \"$key\" must be a string.")
        val text = if (allowNewlines) value else value.trim()
        if (!allowEmpty && text.isBlank()) throw InvalidArgument("Argument \"$key\" must not be empty.")
        if (text.length > maxLength) {
            throw InvalidArgument("Argument \"$key\" is too long (max $maxLength characters).")
        }
        val badChar = text.firstOrNull { c ->
            (c.code < 0x20 && !(allowNewlines && (c == '\n' || c == '\t' || c == '\r'))) || c.code == 0x7F
        }
        if (badChar != null) throw InvalidArgument("Argument \"$key\" contains control characters.")
        return text
    }

    private fun optionalInt(args: Map<String, Any?>, key: String): Int? = when (val v = args[key]) {
        null -> null
        is Number -> {
            val d = v.toDouble()
            if (!d.isFinite()) throw InvalidArgument("Argument \"$key\" must be a number.")
            d.coerceIn(-1_000_000_000.0, 1_000_000_000.0).toInt()
        }
        is String -> v.trim().toIntOrNull() ?: throw InvalidArgument("Argument \"$key\" must be a number.")
        else -> throw InvalidArgument("Argument \"$key\" must be a number.")
    }

    private fun optionalBoolean(args: Map<String, Any?>, key: String): Boolean? = when (val v = args[key]) {
        null -> null
        is Boolean -> v
        is String -> when (v.trim().lowercase()) {
            "true" -> true
            "false" -> false
            else -> throw InvalidArgument("Argument \"$key\" must be true or false.")
        }
        else -> throw InvalidArgument("Argument \"$key\" must be true or false.")
    }
}
