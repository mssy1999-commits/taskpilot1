package com.taskpilot.assistant.ai

import android.util.Base64
import com.taskpilot.assistant.browser.BrowserToolExecutor
import com.taskpilot.assistant.data.AppSettings
import com.taskpilot.assistant.data.Attachment
import com.taskpilot.assistant.data.AttachmentKind
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.data.ChatMessage
import com.taskpilot.assistant.data.PdfPages
import com.taskpilot.assistant.data.Role
import com.taskpilot.assistant.data.ToolStep
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

/**
 * Grok engine (xAI, paid): the same chat + browser-tool loop as [GeminiAgent], using
 * the OpenAI-compatible chat completions format through your own proxy.
 */
class GrokAgent(
    private val runner: BrowserToolRunner,
    private val repository: AttachmentRepository,
    private val client: GrokClient = GrokClient(),
) : AssistantEngine {

    override val provider: AiProvider get() = AiProvider.GROK

    private var config: GrokConfig? = null
    private val history = mutableListOf<JsonObject>()
    private val json = Json { ignoreUnknownKeys = true }

    override val modelName: String get() = config?.model ?: ModelConfig.defaultGrokModel
    override val modelDetail: String get() = "xAI via your proxy"

    override suspend fun ensureReady() {
        if (config != null) return
        val resolved = ModelConfig.resolveGrok()
        if (resolved.proxyUrl.isBlank()) throw GrokNotConfiguredException()
        GrokClient.endpointFor(resolved.proxyUrl) // throws if the URL is unusable
        config = resolved
    }

    override fun clearHistory() = history.clear()

    override fun restore(messages: List<ChatMessage>) {
        history.clear()
        val relevant = messages.filter { it.role != Role.NOTE && !it.isError }.takeLast(AgentLimits.MAX_RESTORED_MESSAGES)
        for (m in relevant) {
            val text = if (m.role == Role.USER) AgentLimits.describeForHistory(m) else m.text
            if (text.isBlank()) continue
            appendMerged(textMessage(if (m.role == Role.USER) "user" else "assistant", text))
        }
        while (history.isNotEmpty() && history.first().role() != "user") history.removeAt(0)
    }

    override suspend fun runTurn(
        text: String,
        attachments: List<Attachment>,
        settings: AppSettings,
        listener: AgentListener,
    ): TurnResult {
        ensureReady()
        val cfg = config ?: throw GrokNotConfiguredException()
        val userMessage = buildUserMessage(text, attachments)
        compactOldTurns()
        if (history.lastOrNull()?.role() == "user") history += textMessage("assistant", AgentLimits.NO_REPLY_MESSAGE)
        val checkpoint = history.size
        val steps = mutableListOf<ToolStep>()
        val budget = TurnBudget()
        try {
            history += userMessage
            while (true) {
                budget.rounds++
                compactSnapshots()
                val response = completeWithRetry(cfg, listener)
                val choice = (response["choices"] as? JsonArray)?.firstOrNull() as? JsonObject
                    ?: throw AgentException("Grok returned no answer. Please try again.")
                val message = choice["message"] as? JsonObject
                    ?: throw AgentException("Grok returned no answer. Please try again.")
                val toolCalls = (message["tool_calls"] as? JsonArray)?.mapNotNull { it as? JsonObject }.orEmpty()
                val content = contentText(message["content"])
                val callIds = toolCalls.mapIndexed { i, tc -> (tc["id"] as? JsonPrimitive)?.content ?: "call_${budget.rounds}_$i" }
                history += assistantMessage(content, toolCalls, callIds)

                if (toolCalls.isEmpty()) {
                    return TurnResult(content.trim().ifEmpty { emptyReply(choice) }, steps.toList())
                }

                val proposed = toolCalls.map { tc ->
                    val fn = tc["function"] as? JsonObject
                    ProposedCall((fn?.get("name") as? JsonPrimitive)?.content.orEmpty(), parseArgs(fn?.get("arguments")))
                }
                val payloads = runner.runBatch(proposed, budget, settings, listener, steps)
                callIds.zip(payloads).forEach { (id, payload) ->
                    history += buildJsonObject {
                        put("role", "tool")
                        put("tool_call_id", id)
                        put("content", payload.toString())
                    }
                }

                if (budget.roundsExceeded) {
                    history += textMessage("assistant", AgentLimits.STOPPED_MESSAGE)
                    return TurnResult(AgentLimits.STOPPED_MESSAGE, steps.toList())
                }
            }
        } catch (e: Throwable) {
            // Roll back so history never ends with unanswered tool calls.
            while (history.size > checkpoint) history.removeAt(history.lastIndex)
            if (text.isNotBlank()) {
                appendMerged(textMessage("user", text))
                history += textMessage("assistant", AgentLimits.INTERRUPTED_MESSAGE)
            }
            throw e
        }
    }

    private suspend fun completeWithRetry(cfg: GrokConfig, listener: AgentListener): JsonObject {
        val messages = ArrayList<JsonElement>(history.size + 1)
        messages += textMessage("system", AgentPrompt.system())
        messages += history
        // "model" stays the first key: the proxy can then check it cheaply.
        val body = buildJsonObject {
            put("model", cfg.model)
            put("messages", JsonArray(messages))
            put("tools", BrowserToolDeclarations.openAiTools)
            put("tool_choice", "auto")
            put("stream", false)
        }
        var attempt = 0
        while (true) {
            try {
                val response = client.chatCompletion(cfg.proxyUrl, body)
                if (attempt > 0) listener.onStatus(null)
                return response
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (attempt >= AgentLimits.RETRY_DELAYS_MS.size || !AgentErrors.isTransient(e)) {
                    listener.onStatus(null)
                    throw e
                }
                val wait = AgentLimits.RETRY_DELAYS_MS[attempt]
                attempt++
                listener.onStatus(AgentLimits.retryStatus("Grok", wait, attempt))
                delay(wait)
            }
        }
    }

    // ---- message building ------------------------------------------------------------

    private suspend fun buildUserMessage(text: String, attachments: List<Attachment>): JsonObject {
        val parts = mutableListOf<JsonObject>()
        val notes = mutableListOf<String>()
        for (a in attachments) {
            when (a.kind) {
                AttachmentKind.IMAGE -> parts += imagePart(repository.readBytes(a))
                AttachmentKind.PDF -> {
                    try {
                        val pages = PdfPages.render(repository.fileOf(a))
                        pages.jpegPages.forEach { parts += imagePart(it) }
                        notes += "${a.displayName} (PDF shown as images of pages 1-${pages.jpegPages.size} of ${pages.totalPages})"
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        notes += "${a.displayName} (PDF could not be opened on the device)"
                    }
                }
                AttachmentKind.TEXT -> parts += textPart(AgentLimits.attachedTextBlock(a.displayName, repository.readText(a)))
            }
        }
        if (attachments.isNotEmpty()) {
            val described = attachments.filter { it.kind != AttachmentKind.PDF }
                .map { "${it.displayName} (${it.kind.name.lowercase()})" } + notes
            parts += textPart("Attached files: " + described.joinToString())
        }
        parts += textPart(text.ifBlank { "Please look at the attached file(s)." })
        return buildJsonObject {
            put("role", "user")
            put("content", JsonArray(parts))
        }
    }

    private fun imagePart(jpeg: ByteArray): JsonObject = buildJsonObject {
        put("type", "image_url")
        put("image_url", buildJsonObject {
            put("url", "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP))
            put("detail", "high")
        })
    }

    private fun textPart(text: String): JsonObject = buildJsonObject {
        put("type", "text")
        put("text", text)
    }

    private fun textMessage(role: String, text: String): JsonObject = buildJsonObject {
        put("role", role)
        put("content", text)
    }

    private fun assistantMessage(content: String, toolCalls: List<JsonObject>, ids: List<String>): JsonObject = buildJsonObject {
        put("role", "assistant")
        if (content.isNotEmpty() || toolCalls.isEmpty()) put("content", content)
        if (toolCalls.isNotEmpty()) {
            put("tool_calls", JsonArray(toolCalls.mapIndexed { i, tc ->
                val fn = tc["function"] as? JsonObject
                val args = fn?.get("arguments")
                buildJsonObject {
                    put("id", ids[i])
                    put("type", "function")
                    put("function", buildJsonObject {
                        put("name", (fn?.get("name") as? JsonPrimitive)?.content.orEmpty())
                        put("arguments", if (args is JsonPrimitive) args.content else (args ?: JsonObject(emptyMap())).toString())
                    })
                }
            }))
        }
    }

    /** Model arguments arrive as a JSON string; null means they weren't valid JSON. */
    private fun parseArgs(raw: JsonElement?): Map<String, Any?>? {
        val obj: JsonObject = when {
            raw == null || raw is JsonNull -> JsonObject(emptyMap())
            raw is JsonObject -> raw
            raw is JsonPrimitive -> {
                val s = raw.content.trim()
                if (s.isEmpty()) JsonObject(emptyMap()) else parseObjectOrNull(s) ?: return null
            }
            else -> return null
        }
        return ToolArgs.toPlain(obj)
    }

    private fun contentText(content: JsonElement?): String = when (content) {
        null, is JsonNull -> ""
        is JsonPrimitive -> content.content
        is JsonArray -> content.mapNotNull { part ->
            ((part as? JsonObject)?.get("text") as? JsonPrimitive)?.content
        }.joinToString("\n")
        else -> ""
    }

    private fun emptyReply(choice: JsonObject): String = when ((choice["finish_reason"] as? JsonPrimitive)?.content) {
        "length" -> "The reply was too long and got cut off. Try asking for a shorter answer."
        "content_filter" -> "Grok withheld the reply because of its content filters."
        else -> "I don't have anything to add."
    }

    // ---- history helpers ---------------------------------------------------------------

    private fun JsonObject.role(): String? = (this["role"] as? JsonPrimitive)?.content

    private fun appendMerged(msg: JsonObject) {
        val last = history.lastOrNull()
        val lastContent = last?.get("content") as? JsonPrimitive
        val newContent = msg["content"] as? JsonPrimitive
        if (last != null && last.role() == msg.role() && last["tool_calls"] == null &&
            lastContent != null && lastContent.isString && newContent != null && newContent.isString
        ) {
            history[history.lastIndex] = textMessage(msg.role().orEmpty(), lastContent.content + "\n\n" + newContent.content)
        } else {
            history += msg
        }
    }

    /** Keeps only the most recent page snapshot in full; older ones are summarized. */
    private fun compactSnapshots() {
        val indices = history.indices.filter { i -> isSnapshotToolMessage(history[i]) }
        if (indices.size <= 1) return
        for (i in indices.dropLast(1)) {
            val msg = history[i]
            val raw = (msg["content"] as? JsonPrimitive)?.content ?: continue
            val parsed = parseObjectOrNull(raw) ?: continue
            history[i] = buildJsonObject {
                msg["role"]?.let { put("role", it) }
                msg["tool_call_id"]?.let { put("tool_call_id", it) }
                put("content", runner.compactedSnapshot(parsed).toString())
            }
        }
    }

    private fun parseObjectOrNull(raw: String): JsonObject? = try {
        json.parseToJsonElement(raw) as? JsonObject
    } catch (e: Exception) {
        null
    }

    private fun isSnapshotToolMessage(msg: JsonObject): Boolean =
        msg.role() == "tool" && ((msg["content"] as? JsonPrimitive)?.content?.contains(BrowserToolExecutor.UNTRUSTED_KEY) == true)

    /** Drops attachments from older turns and trims very long histories. */
    private fun compactOldTurns() {
        compactSnapshots()
        val withAttachments = history.indices.filter { i -> history[i].role() == "user" && history[i]["content"] is JsonArray }
        for (i in withAttachments.dropLast(AgentLimits.KEEP_ATTACHMENT_TURNS)) {
            val parts = history[i]["content"] as JsonArray
            val kept = parts.mapNotNull { part ->
                val p = part as? JsonObject ?: return@mapNotNull null
                val type = (p["type"] as? JsonPrimitive)?.content
                val partText = (p["text"] as? JsonPrimitive)?.content.orEmpty()
                if (type == "image_url" || partText.startsWith(AgentLimits.ATTACHED_TEXT_MARKER)) null else p
            }
            history[i] = buildJsonObject {
                put("role", "user")
                put("content", JsonArray(kept + textPart("[Attachments from earlier in the conversation are no longer included.]")))
            }
        }
        if (history.size > MAX_HISTORY_MESSAGES) {
            val start = (history.size - MAX_HISTORY_MESSAGES until history.size).firstOrNull { i -> history[i].role() == "user" }
            if (start != null) repeat(start) { history.removeAt(0) }
        }
    }

    private companion object {
        const val MAX_HISTORY_MESSAGES = 120
    }
}
