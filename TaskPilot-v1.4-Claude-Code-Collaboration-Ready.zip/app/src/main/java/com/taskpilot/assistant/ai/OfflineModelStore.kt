package com.taskpilot.assistant.ai

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Stores a user-selected LiteRT-LM model privately. A large model is NOT bundled in the APK. */
class OfflineModelStore(private val context: Context) {
    private val modelsDir: File get() = File(context.filesDir, "offline-models")
    val activeModel: File get() = File(modelsDir, "active.litertlm")
    val isInstalled: Boolean get() = activeModel.isFile && activeModel.length() > 1_000_000L
    val modelSizeBytes: Long get() = if (isInstalled) activeModel.length() else 0L

    /** Copy by streaming, never buffering hundreds of megabytes in RAM. */
    suspend fun import(uri: Uri): Long = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: (uri.lastPathSegment ?: "")
        require(name.endsWith(".litertlm", ignoreCase = true)) {
            "Please select a .litertlm model, not a .gguf or .tflite file."
        }
        modelsDir.mkdirs()
        val tmp = File(modelsDir, "incoming.litertlm")
        try {
            resolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().buffered().use { output -> input.copyTo(output, bufferSize = 128 * 1024) }
            } ?: throw IOException("The model file could not be opened.")
            if (tmp.length() < 1_000_000) throw IOException("The model is empty or incomplete.")
            // Preserve existing model on copy failures. A failed rename is reported rather than ignored.
            if (activeModel.exists() && !activeModel.delete()) throw IOException("Could not replace the old model.")
            if (!tmp.renameTo(activeModel)) throw IOException("Could not save the model.")
            activeModel.length()
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }
}
