package com.taskpilot.assistant.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Renders the first pages of a PDF to JPEG images on the device, for AI providers
 * that accept images but not PDF files (Grok). Uses Android's built-in PdfRenderer.
 */
object PdfPages {
    const val MAX_PAGES = 5
    private const val TARGET_WIDTH = 1240 // ~150 dpi for A4: readable text, modest size

    data class Result(val jpegPages: List<ByteArray>, val totalPages: Int)

    suspend fun render(file: File, maxPages: Int = MAX_PAGES): Result = withContext(Dispatchers.IO) {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
            PdfRenderer(fd).use { renderer ->
                val count = renderer.pageCount
                val pages = ArrayList<ByteArray>()
                for (i in 0 until minOf(count, maxPages)) {
                    renderer.openPage(i).use { page ->
                        val scale = TARGET_WIDTH.toFloat() / page.width.coerceAtLeast(1)
                        val width = TARGET_WIDTH
                        val height = (page.height * scale).roundToInt().coerceIn(1, 4000)
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE) // PDF pages may be transparent
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val bytes = ByteArrayOutputStream().use { out ->
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
                            out.toByteArray()
                        }
                        bitmap.recycle()
                        pages += bytes
                    }
                }
                Result(pages, count)
            }
        }
    }
}
