package com.taskpilot.assistant.data

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Imports files picked with the system pickers into app-private storage, after
 * validating type and size. Images are downscaled and re-encoded as JPEG to keep
 * requests small (and to strip EXIF metadata such as GPS location).
 */
class AttachmentRepository(context: Context, private val store: ConversationStore) {

    private val appContext = context.applicationContext
    private val resolver: ContentResolver get() = appContext.contentResolver

    sealed interface ImportResult {
        data class Success(val attachment: Attachment) : ImportResult
        data class Failure(val message: String) : ImportResult
    }

    suspend fun import(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            importInternal(uri)
        } catch (e: SecurityException) {
            ImportResult.Failure("The app was not allowed to read that file.")
        } catch (e: IOException) {
            ImportResult.Failure("Couldn't read that file: ${e.message ?: "I/O error"}")
        } catch (e: OutOfMemoryError) {
            ImportResult.Failure("That image is too large to process on this device.")
        }
    }

    private fun importInternal(uri: Uri): ImportResult {
        var displayName: String? = null
        var declaredSize = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIdx >= 0 && !c.isNull(nameIdx)) displayName = c.getString(nameIdx)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIdx >= 0 && !c.isNull(sizeIdx)) declaredSize = c.getLong(sizeIdx)
            }
        }
        val name = displayName?.takeIf { it.isNotBlank() } ?: (uri.lastPathSegment ?: "file")
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val mime = resolver.getType(uri)
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)

        val kind = AttachmentTypes.classify(mime, name)
            ?: return ImportResult.Failure(
                "“$name” isn't supported. Supported: ${AttachmentTypes.SUPPORTED_SUMMARY}"
            )
        val limit = AttachmentTypes.maxSourceBytes(kind)
        if (declaredSize > limit) {
            return ImportResult.Failure(
                "“$name” is ${AttachmentTypes.formatSize(declaredSize)}; the limit for this type is ${AttachmentTypes.formatSize(limit)}."
            )
        }

        val id = UUID.randomUUID().toString()
        return when (kind) {
            AttachmentKind.IMAGE -> importImage(uri, id, name)
            AttachmentKind.PDF -> importPdf(uri, id, name, limit)
            AttachmentKind.TEXT -> importText(uri, id, name, limit)
        }
    }

    private fun importImage(uri: Uri, id: String, name: String): ImportResult {
        val bitmap = decodeScaledBitmap(uri, AttachmentTypes.MAX_IMAGE_DIMENSION)
            ?: return ImportResult.Failure("“$name” couldn't be decoded as an image.")
        val bytes = ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            out.toByteArray()
        }
        bitmap.recycle()
        val fileName = "$id.jpg"
        File(store.attachmentsDir, fileName).writeBytes(bytes)
        return ImportResult.Success(
            Attachment(id, name, AttachmentKind.IMAGE, AttachmentTypes.storedMimeType(AttachmentKind.IMAGE), bytes.size.toLong(), fileName)
        )
    }

    private fun importPdf(uri: Uri, id: String, name: String, limit: Long): ImportResult {
        val bytes = readLimited(uri, limit)
            ?: return ImportResult.Failure("“$name” is larger than ${AttachmentTypes.formatSize(limit)}.")
        if (bytes.size < 5 || String(bytes, 0, 5, Charsets.US_ASCII) != "%PDF-") {
            return ImportResult.Failure("“$name” doesn't look like a valid PDF.")
        }
        val fileName = "$id.pdf"
        File(store.attachmentsDir, fileName).writeBytes(bytes)
        return ImportResult.Success(
            Attachment(id, name, AttachmentKind.PDF, AttachmentTypes.storedMimeType(AttachmentKind.PDF), bytes.size.toLong(), fileName)
        )
    }

    private fun importText(uri: Uri, id: String, name: String, limit: Long): ImportResult {
        val bytes = readLimited(uri, limit)
            ?: return ImportResult.Failure("“$name” is larger than ${AttachmentTypes.formatSize(limit)}.")
        val text = String(bytes, Charsets.UTF_8).removePrefix("﻿")
        val suspicious = text.count { it == '\u0000' || it == '�' }
        if (text.isNotEmpty() && suspicious > text.length / 50 + 2) {
            return ImportResult.Failure("“$name” doesn't look like a UTF-8 text file.")
        }
        val fileName = "$id.txt"
        File(store.attachmentsDir, fileName).writeText(text, Charsets.UTF_8)
        return ImportResult.Success(
            Attachment(id, name, AttachmentKind.TEXT, AttachmentTypes.storedMimeType(AttachmentKind.TEXT), bytes.size.toLong(), fileName)
        )
    }

    suspend fun readBytes(attachment: Attachment): ByteArray = withContext(Dispatchers.IO) {
        store.attachmentFile(attachment).readBytes()
    }

    suspend fun readText(attachment: Attachment): String = withContext(Dispatchers.IO) {
        store.attachmentFile(attachment).readText(Charsets.UTF_8)
    }

    fun exists(attachment: Attachment): Boolean = store.attachmentFile(attachment).exists()

    /** The app-private file holding this attachment's bytes. */
    fun fileOf(attachment: Attachment): File = store.attachmentFile(attachment)

    suspend fun delete(attachment: Attachment) = withContext(Dispatchers.IO) {
        store.attachmentFile(attachment).delete()
    }

    /** Small preview bitmap for an image attachment, or null. */
    suspend fun loadThumbnail(attachment: Attachment, maxPx: Int): Bitmap? = withContext(Dispatchers.IO) {
        if (attachment.kind != AttachmentKind.IMAGE) return@withContext null
        val file = store.attachmentFile(attachment)
        if (!file.exists()) return@withContext null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxPx) sample *= 2
        BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    // ---- helpers ------------------------------------------------------------

    /** Reads at most [limit] bytes; returns null if the stream is longer. */
    private fun readLimited(uri: Uri, limit: Long): ByteArray? {
        val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open file")
        return input.use { readUpTo(it, limit) }
    }

    private fun readUpTo(input: InputStream, limit: Long): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            total += n
            if (total > limit) return null
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun decodeScaledBitmap(uri: Uri, maxDim: Int): Bitmap? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(resolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val scale = minOf(1f, maxDim.toFloat() / max(w, h).coerceAtLeast(1))
                if (scale < 1f) {
                    decoder.setTargetSize((w * scale).roundToInt().coerceAtLeast(1), (h * scale).roundToInt().coerceAtLeast(1))
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            decodeScaledLegacy(uri, maxDim)
        }
    }

    private fun decodeScaledLegacy(uri: Uri, maxDim: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null

        val rotation = resolver.openInputStream(uri)?.use { stream ->
            when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f

        val longest = max(decoded.width, decoded.height)
        val scale = if (longest > maxDim) maxDim.toFloat() / longest else 1f
        if (scale == 1f && rotation == 0f) return decoded
        val matrix = Matrix().apply {
            postScale(scale, scale)
            postRotate(rotation)
        }
        val result = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (result !== decoded) decoded.recycle()
        return result
    }
}
