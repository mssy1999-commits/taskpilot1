package com.taskpilot.assistant.data

import android.content.Context
import android.util.Log
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/**
 * Stores the conversation as JSON plus attachment copies in app-private storage
 * (`/data/data/<package>/files`). Nothing here is backed up (see manifest).
 */
class ConversationStore(context: Context) {

    private val appContext = context.applicationContext
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
    }
    private val mutex = Mutex()

    private val conversationFile: File get() = File(appContext.filesDir, FILE_NAME)

    val attachmentsDir: File
        get() = File(appContext.filesDir, ATTACHMENTS_DIR).apply { mkdirs() }

    fun attachmentFile(attachment: Attachment): File = File(attachmentsDir, attachment.fileName)

    suspend fun load(): List<ChatMessage> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val file = conversationFile
            if (!file.exists()) return@withLock emptyList()
            try {
                json.decodeFromString(StoredConversation.serializer(), file.readText()).messages
            } catch (e: Exception) {
                Log.w(TAG, "Could not read saved conversation; starting fresh", e)
                emptyList()
            }
        }
    }

    suspend fun save(messages: List<ChatMessage>) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val target = conversationFile
            val tmp = File(target.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(json.encodeToString(StoredConversation.serializer(), StoredConversation(messages = messages)))
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
        }
    }

    /** Deletes the saved transcript (attachments are handled separately). */
    suspend fun deleteTranscript() = withContext(Dispatchers.IO) {
        mutex.withLock {
            conversationFile.delete()
            File(appContext.filesDir, "$FILE_NAME.tmp").delete()
        }
    }

    /** Deletes attachment files that are not in [keep]. */
    suspend fun deleteAttachmentsExcept(keep: Set<String>) = withContext(Dispatchers.IO) {
        attachmentsDir.listFiles()?.forEach { file ->
            if (file.name !in keep) file.delete()
        }
    }

    /** Bytes used by the transcript and attachments. */
    suspend fun storageBytes(): Long = withContext(Dispatchers.IO) {
        val transcript = conversationFile.takeIf { it.exists() }?.length() ?: 0L
        val attachments = attachmentsDir.listFiles()?.sumOf { it.length() } ?: 0L
        transcript + attachments
    }

    private companion object {
        const val TAG = "ConversationStore"
        const val FILE_NAME = "conversation.json"
        const val ATTACHMENTS_DIR = "attachments"
    }
}
