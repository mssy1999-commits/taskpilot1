package com.taskpilot.assistant.ai

import com.google.firebase.appcheck.FirebaseAppCheck
import com.taskpilot.assistant.policy.UrlPolicy
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject

class GrokNotConfiguredException : Exception("The Grok proxy URL is not configured")

class GrokHttpException(val statusCode: Int, val errorCode: String?, message: String) : Exception(message)

/**
 * Minimal OpenAI-compatible client for Grok. It talks only to YOUR proxy (a
 * Cloudflare Worker that holds the xAI key). Each request carries a Firebase App
 * Check token, which the proxy verifies, so only your genuine app can use the key.
 * The APK contains no xAI key.
 */
class GrokClient {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun chatCompletion(proxyUrl: String, body: JsonObject): JsonObject {
        val endpoint = endpointFor(proxyUrl)
        val token = appCheckToken()
        return withContext(Dispatchers.IO) {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 150_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-Firebase-AppCheck", token)
            }
            try {
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw errorFrom(code, text)
                try {
                    json.parseToJsonElement(text).jsonObject
                } catch (e: Exception) {
                    throw GrokHttpException(code, "bad_response", "The Grok proxy returned an unexpected response.")
                }
            } finally {
                conn.disconnect()
            }
        }
    }

    private suspend fun appCheckToken(): String {
        if (!FirebaseSetup.isConfigured) throw FirebaseNotConfiguredException()
        return FirebaseAppCheck.getInstance().getAppCheckToken(false).awaitResult().token
    }

    /** Reads `{"error":{"message","code"}}`, `{"error":"..."}` or `{"code","error"}` bodies. */
    private fun errorFrom(code: Int, body: String): GrokHttpException {
        var message: String? = null
        var errorCode: String? = null
        try {
            val obj = json.parseToJsonElement(body).jsonObject
            when (val err = obj["error"]) {
                is JsonObject -> {
                    message = (err["message"] as? JsonPrimitive)?.content
                    errorCode = (err["code"] as? JsonPrimitive)?.content ?: (err["type"] as? JsonPrimitive)?.content
                }
                is JsonPrimitive -> message = err.content
                else -> Unit
            }
            if (errorCode == null) errorCode = (obj["code"] as? JsonPrimitive)?.content
        } catch (e: Exception) {
            message = body.take(200).ifBlank { null }
        }
        return GrokHttpException(code, errorCode, message ?: "HTTP $code")
    }

    companion object {
        private const val PATH = "/v1/chat/completions"

        /** Validates the proxy URL (https, public host) and returns the chat endpoint. */
        fun endpointFor(proxyUrl: String): String {
            val base = when (val r = UrlPolicy.validateNavigation(proxyUrl.trim())) {
                is UrlPolicy.Result.Allowed -> r.url
                is UrlPolicy.Result.Rejected -> throw GrokNotConfiguredException()
            }
            val trimmed = base.trimEnd('/')
            return if (trimmed.endsWith(PATH)) trimmed else trimmed + PATH
        }
    }
}
