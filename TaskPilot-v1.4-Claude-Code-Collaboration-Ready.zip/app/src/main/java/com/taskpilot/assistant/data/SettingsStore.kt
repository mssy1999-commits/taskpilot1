package com.taskpilot.assistant.data

import android.content.Context
import androidx.core.content.edit
import com.taskpilot.assistant.ai.AiProvider
import com.taskpilot.assistant.policy.UrlPolicy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    /** Read assistant replies aloud with the device's text-to-speech engine. */
    val speakReplies: Boolean = false,
    /** Send the message automatically when voice input finishes. */
    val autoSendVoice: Boolean = true,
    /** Ask before every active browser action, not just consequential ones. */
    val confirmEveryAction: Boolean = false,
    /** Keep the conversation on the device between app launches. */
    val saveHistory: Boolean = true,
    val searchEngine: UrlPolicy.SearchEngine = UrlPolicy.SearchEngine.DUCKDUCKGO,
    /** BCP-47 tag for speech recognition, or "" for the device language. */
    val voiceLanguage: String = "",
    /** Don't download images in the in-app browser: much faster pages on slow connections. */
    val fastBrowsing: Boolean = true,
    /** Gemini (quota-limited), Grok (paid), or local no-quota AI. */
    val aiProvider: AiProvider = AiProvider.LOCAL,
)

/** App preferences in a private SharedPreferences file. */
class SettingsStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    val current: AppSettings get() = _settings.value

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        prefs.edit {
            putBoolean(KEY_SPEAK, next.speakReplies)
            putBoolean(KEY_AUTO_SEND, next.autoSendVoice)
            putBoolean(KEY_CONFIRM_ALL, next.confirmEveryAction)
            putBoolean(KEY_SAVE_HISTORY, next.saveHistory)
            putString(KEY_SEARCH, next.searchEngine.name)
            putString(KEY_VOICE_LANG, next.voiceLanguage)
            putBoolean(KEY_FAST_BROWSING, next.fastBrowsing)
            putString(KEY_PROVIDER, next.aiProvider.name)
        }
    }

    fun clear() {
        prefs.edit { clear() }
        _settings.value = AppSettings()
    }

    private fun read(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            speakReplies = prefs.getBoolean(KEY_SPEAK, defaults.speakReplies),
            autoSendVoice = prefs.getBoolean(KEY_AUTO_SEND, defaults.autoSendVoice),
            confirmEveryAction = prefs.getBoolean(KEY_CONFIRM_ALL, defaults.confirmEveryAction),
            saveHistory = prefs.getBoolean(KEY_SAVE_HISTORY, defaults.saveHistory),
            searchEngine = prefs.getString(KEY_SEARCH, null)
                ?.let { name -> UrlPolicy.SearchEngine.entries.firstOrNull { it.name == name } }
                ?: defaults.searchEngine,
            voiceLanguage = prefs.getString(KEY_VOICE_LANG, defaults.voiceLanguage).orEmpty(),
            fastBrowsing = prefs.getBoolean(KEY_FAST_BROWSING, defaults.fastBrowsing),
            aiProvider = prefs.getString(KEY_PROVIDER, null)
                ?.let { name -> AiProvider.entries.firstOrNull { it.name == name } }
                ?: defaults.aiProvider,
        )
    }

    private companion object {
        const val KEY_SPEAK = "speak_replies"
        const val KEY_AUTO_SEND = "auto_send_voice"
        const val KEY_CONFIRM_ALL = "confirm_every_action"
        const val KEY_SAVE_HISTORY = "save_history"
        const val KEY_SEARCH = "search_engine"
        const val KEY_VOICE_LANG = "voice_language"
        const val KEY_FAST_BROWSING = "fast_browsing"
        const val KEY_PROVIDER = "ai_provider"
    }
}
