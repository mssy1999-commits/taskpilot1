package com.taskpilot.assistant.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Spoken replies with the device's [TextToSpeech] engine (no extra permissions). */
class SpeechOutputController(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var pending: String? = null
    private val counter = AtomicInteger()
    @Volatile private var lastUtteranceId: String? = null

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    /** Id of the chat message being read, so the UI can show a stop button on it. */
    private val _speakingMessageId = MutableStateFlow<String?>(null)
    val speakingMessageId: StateFlow<String?> = _speakingMessageId.asStateFlow()

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) {
            Log.w(TAG, "Text-to-speech unavailable (status $status)")
            return
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _speaking.value = true
            }

            override fun onDone(utteranceId: String?) {
                if (utteranceId == lastUtteranceId) finished()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finished()
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                finished()
            }
        })
        pending?.let { text ->
            pending = null
            speak(text, _speakingMessageId.value)
        }
    }

    val isReady: Boolean get() = ready

    fun speak(markdown: String, messageId: String? = null) {
        val text = SpeechText.clean(markdown)
        if (text.isBlank()) return
        _speakingMessageId.value = messageId
        if (!ready) {
            pending = text
            return
        }
        val locale = if (SpeechText.isMostlyArabic(text)) Locale.forLanguageTag("ar") else Locale.getDefault()
        if (tts.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) tts.setLanguage(locale)

        val chunks = SpeechText.chunk(text, minOf(TextToSpeech.getMaxSpeechInputLength() - 1, 3_500))
        chunks.forEachIndexed { index, chunk ->
            val id = "tp-${counter.incrementAndGet()}"
            if (index == chunks.lastIndex) lastUtteranceId = id
            tts.speak(chunk, if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
        _speaking.value = true
    }

    fun stop() {
        pending = null
        if (ready) tts.stop()
        finished()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
        finished()
    }

    private fun finished() {
        _speaking.value = false
        _speakingMessageId.value = null
    }

    private companion object {
        const val TAG = "SpeechOutput"
    }
}
