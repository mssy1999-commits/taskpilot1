package com.taskpilot.assistant.policy

import java.net.IDN
import java.net.URI
import java.net.URLEncoder
import java.util.Locale

/**
 * Validation rules for every URL the assistant (or a web page) tries to open.
 *
 * Pure Kotlin (no Android types) so it is covered by JVM unit tests.
 */
object UrlPolicy {

    const val MAX_URL_LENGTH = 2048

    sealed interface Result {
        /** [url] is normalized (https, ASCII host). [host] is lower-case. */
        data class Allowed(val url: String, val host: String) : Result
        data class Rejected(val reason: String) : Result
    }

    enum class SearchEngine(val label: String, private val base: String) {
        DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/html/?q="),
        GOOGLE("Google", "https://www.google.com/search?q="),
        BING("Bing", "https://www.bing.com/search?q=");

        fun searchUrl(query: String): String = base + URLEncoder.encode(query.trim(), "UTF-8")
    }

    private val EXPLICIT_SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.\\-]*://")
    private val OPAQUE_SCHEME = Regex("^([a-zA-Z][a-zA-Z0-9+.\\-]*):(?![0-9])")

    /** Validates and normalizes a URL that the assistant wants to open. */
    fun validateNavigation(raw: String): Result {
        val input = raw.trim()
        if (input.isEmpty()) return Result.Rejected("The URL is empty.")
        if (input.length > MAX_URL_LENGTH) {
            return Result.Rejected("The URL is longer than $MAX_URL_LENGTH characters.")
        }
        if (input.any { it.isWhitespace() || it.code < 0x20 || it.code == 0x7F }) {
            return Result.Rejected("The URL must not contain spaces or control characters.")
        }

        val candidate = when {
            EXPLICIT_SCHEME.containsMatchIn(input) -> input
            OPAQUE_SCHEME.containsMatchIn(input) -> input // e.g. javascript:, mailto: -> rejected below
            input.startsWith("//") -> "https:$input"
            else -> "https://$input"
        }

        val schemeEnd = candidate.indexOf(':')
        val scheme = candidate.substring(0, schemeEnd).lowercase(Locale.ROOT)
        if (scheme != "http" && scheme != "https") {
            return Result.Rejected("Only http and https pages can be opened (blocked \"$scheme:\").")
        }

        val asciiCandidate = toAsciiHost(candidate)?.let(::encodeIllegalAscii)
            ?: return Result.Rejected("The URL has an invalid host name.")

        val uri = try {
            URI(asciiCandidate)
        } catch (e: Exception) {
            return Result.Rejected("The URL is malformed.")
        }
        if (uri.rawUserInfo != null) {
            return Result.Rejected("URLs with an embedded username or password are not allowed.")
        }
        val host = uri.host?.lowercase(Locale.ROOT)?.trimEnd('.')
        if (host.isNullOrEmpty()) return Result.Rejected("The URL has no valid host name.")
        if (isLocalNetworkHost(host)) {
            return Result.Rejected("Addresses on this device or the local network are blocked.")
        }

        // Always https: plain http is upgraded because the app blocks cleartext traffic.
        val normalized = "https" + asciiCandidate.substring(asciiCandidate.indexOf(':'))
        return Result.Allowed(normalized, host)
    }

    /** Percent-encodes ASCII characters that java.net.URI rejects but browsers tolerate. */
    private fun encodeIllegalAscii(url: String): String {
        if (url.none { it in ILLEGAL_ASCII }) return url
        val sb = StringBuilder(url.length + 8)
        for (c in url) {
            if (c in ILLEGAL_ASCII) {
                sb.append('%').append(c.code.toString(16).uppercase(Locale.ROOT).padStart(2, '0'))
            } else {
                sb.append(c)
            }
        }
        return sb.toString()
    }

    private const val ILLEGAL_ASCII = "\"<>\\^`{|}"

    /** Lower-case host of [url], or null if it cannot be parsed. */
    fun hostOf(url: String?): String? {
        if (url.isNullOrBlank()) return null
        return try {
            URI(url.trim()).host?.lowercase(Locale.ROOT)?.trimEnd('.')
        } catch (e: Exception) {
            null
        }
    }

    /** True if [url] has a query string or fragment that could carry data. */
    fun carriesData(url: String): Boolean = try {
        val uri = URI(url)
        !uri.rawQuery.isNullOrEmpty() || !uri.rawFragment.isNullOrEmpty()
    } catch (e: Exception) {
        true
    }

    /**
     * Heuristic "same site" check (same registrable domain). Treats common
     * second-level suffixes such as co.uk / com.lb as part of the suffix.
     */
    fun isSameSite(hostA: String?, hostB: String?): Boolean {
        if (hostA.isNullOrEmpty() || hostB.isNullOrEmpty()) return false
        return registrableDomain(hostA) == registrableDomain(hostB)
    }

    fun registrableDomain(host: String): String {
        val labels = host.lowercase(Locale.ROOT).trimEnd('.').split('.').filter { it.isNotEmpty() }
        if (labels.size <= 2) return labels.joinToString(".")
        val tld = labels.last()
        val second = labels[labels.size - 2]
        val keep = if (tld.length == 2 && second in COMMON_SECOND_LEVEL) 3 else 2
        return labels.takeLast(keep).joinToString(".")
    }

    private val COMMON_SECOND_LEVEL = setOf("co", "com", "net", "org", "gov", "edu", "ac", "or", "ne", "go")

    /**
     * True for hosts that point at this device or a private network, including
     * obfuscated numeric forms (e.g. 2130706433 or 0x7f.1) that browsers accept.
     */
    fun isLocalNetworkHost(rawHost: String): Boolean {
        val host = rawHost.lowercase(Locale.ROOT).trim().removePrefix("[").removeSuffix("]").trimEnd('.')
        if (host.isEmpty()) return true
        if (host == "localhost" || host.endsWith(".localhost")) return true
        if (LOCAL_SUFFIXES.any { host.endsWith(it) }) return true
        if (host.contains(':')) return isPrivateIpv6(host)

        val ipv4 = parseStrictIpv4(host)
        if (ipv4 != null) return isPrivateIpv4(ipv4)

        // A host whose last label is purely numeric/hex is an alternative IP
        // notation (no real TLD is numeric). Block it rather than parse it.
        val last = host.substringAfterLast('.')
        if (last.isNotEmpty() && (last.all { it.isDigit() } || HEX_LABEL.matches(last))) return true
        return false
    }

    private val LOCAL_SUFFIXES = listOf(".local", ".internal", ".lan", ".home.arpa", ".intranet")
    private val HEX_LABEL = Regex("^0x[0-9a-f]+$")

    private fun parseStrictIpv4(host: String): IntArray? {
        val parts = host.split('.')
        if (parts.size != 4) return null
        val out = IntArray(4)
        for ((i, p) in parts.withIndex()) {
            if (p.isEmpty() || p.length > 3 || !p.all { it.isDigit() }) return null
            if (p.length > 1 && p[0] == '0') return null // octal-looking forms are not "strict"
            val v = p.toInt()
            if (v > 255) return null
            out[i] = v
        }
        return out
    }

    private fun isPrivateIpv4(ip: IntArray): Boolean {
        val (a, b) = ip[0] to ip[1]
        return a == 0 || a == 10 || a == 127 ||
            (a == 100 && b in 64..127) ||
            (a == 169 && b == 254) ||
            (a == 172 && b in 16..31) ||
            (a == 192 && b == 168) ||
            (a == 192 && b == 0 && ip[2] == 0) ||
            (a == 198 && (b == 18 || b == 19)) ||
            a >= 224
    }

    private fun isPrivateIpv6(host: String): Boolean {
        val h = host.substringBefore('%')
        if (h == "::1" || h == "::" || h == "0:0:0:0:0:0:0:1" || h == "0:0:0:0:0:0:0:0") return true
        if (h.startsWith("fe8") || h.startsWith("fe9") || h.startsWith("fea") || h.startsWith("feb")) return true
        if (h.startsWith("fc") || h.startsWith("fd")) return true
        if (h.startsWith("::ffff:")) return true // IPv4-mapped; block conservatively
        return false
    }

    /** Converts an internationalized host name in [url] to punycode; null if invalid. */
    private fun toAsciiHost(url: String): String? {
        val authorityStart = url.indexOf("://").takeIf { it >= 0 }?.plus(3) ?: return url
        var authorityEnd = url.length
        for (i in authorityStart until url.length) {
            val c = url[i]
            if (c == '/' || c == '?' || c == '#') {
                authorityEnd = i
                break
            }
        }
        val authority = url.substring(authorityStart, authorityEnd)
        if (authority.all { it.code < 0x80 }) return url
        val userInfoEnd = authority.lastIndexOf('@')
        val hostPort = if (userInfoEnd >= 0) authority.substring(userInfoEnd + 1) else authority
        val colon = hostPort.lastIndexOf(':')
        val hostPart = if (colon > 0 && hostPort.substring(colon + 1).all { it.isDigit() }) {
            hostPort.substring(0, colon)
        } else {
            hostPort
        }
        val ascii = try {
            IDN.toASCII(hostPart, IDN.ALLOW_UNASSIGNED)
        } catch (e: Exception) {
            return null
        }
        val newAuthority = authority.replace(hostPart, ascii)
        return url.substring(0, authorityStart) + newAuthority + url.substring(authorityEnd)
    }
}
