package com.taskpilot.assistant

import android.app.Application
import com.taskpilot.assistant.ai.FirebaseSetup

class TaskPilotApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        FirebaseSetup.initialize(this)
        container = AppContainer(this)
    }
}
