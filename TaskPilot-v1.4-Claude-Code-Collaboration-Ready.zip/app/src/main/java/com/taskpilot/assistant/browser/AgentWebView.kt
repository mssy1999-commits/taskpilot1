package com.taskpilot.assistant.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import com.taskpilot.assistant.policy.UrlPolicy
import java.io.ByteArrayInputStream

/**
 * The automation WebView. [userInputEnabled] lets the UI keep the view laid out at
 * full size (so pages render with a real viewport) while it is hidden behind the
 * chat, without letting touches reach the hidden page.
 */
@SuppressLint("ViewConstructor")
class AgentWebView(context: Context) : WebView(context) {
    var userInputEnabled: Boolean = true
        set(value) {
            field = value
            importantForAccessibility = if (value) {
                View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
            } else {
                View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            }
        }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean =
        if (userInputEnabled) super.dispatchTouchEvent(event) else false
}

/** Creates WebViews with locked-down settings wired to a [BrowserController]. */
object BrowserWebViewFactory {

    @SuppressLint("SetJavaScriptEnabled")
    fun create(context: Context, controller: BrowserController): AgentWebView {
        val view = AgentWebView(context)
        view.settings.apply {
            javaScriptEnabled = true // needed by most sites; the app never exposes a JS bridge
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false) // target=_blank opens in the same view
            mediaPlaybackRequiresUserGesture = true
            safeBrowsingEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, false)
        view.webViewClient = AgentWebViewClient(controller)
        view.webChromeClient = AgentWebChromeClient(controller)
        view.setDownloadListener { _, _, _, _, _ ->
            controller.notice("Downloads aren't supported in the in-app browser.")
        }
        return view
    }
}

private class AgentWebViewClient(private val controller: BrowserController) : WebViewClient() {

    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val uri = request.url
        return when (uri.scheme?.lowercase()) {
            "https" -> {
                val host = uri.host.orEmpty()
                if (UrlPolicy.isLocalNetworkHost(host)) {
                    controller.notice("Blocked a link to the local network ($host).")
                    true
                } else {
                    false
                }
            }
            "http" -> {
                if (!request.isForMainFrame) return false
                val upgraded = uri.buildUpon().scheme("https").build().toString()
                if (controller.allowHttpsUpgrade(upgraded)) {
                    view.loadUrl(upgraded)
                } else {
                    controller.notice("This site only works over insecure HTTP, so it was blocked.")
                }
                true
            }
            "about", "blob" -> false
            else -> {
                controller.notice("Blocked a link that tries to open another app (${uri.scheme}:).")
                true
            }
        }
    }

    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val host = request.url.host ?: return null
        if (UrlPolicy.isLocalNetworkHost(host)) {
            // Web pages may not reach this device or the local network (routers, printers...).
            return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
        return null
    }

    override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
        controller.onPageStarted(url)
    }

    override fun onPageFinished(view: WebView, url: String?) {
        controller.onPageFinished(view, url)
    }

    override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
        controller.onHistoryChanged(view, url)
    }

    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
        if (request.isForMainFrame) controller.onMainFrameError(error.description?.toString() ?: "Load error ${error.errorCode}")
    }

    override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
        if (request.isForMainFrame) controller.onMainFrameHttpStatus(errorResponse.statusCode)
    }

    @SuppressLint("WebViewClientOnReceivedSslError")
    override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        handler.cancel() // never proceed past certificate errors
        controller.notice("Blocked a page with an invalid security certificate.")
    }

    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
        (view.parent as? ViewGroup)?.removeView(view)
        view.destroy()
        controller.onRendererGone()
        return true
    }
}

private class AgentWebChromeClient(private val controller: BrowserController) : WebChromeClient() {
    override fun onProgressChanged(view: WebView, newProgress: Int) = controller.onProgress(newProgress)

    override fun onReceivedTitle(view: WebView, title: String?) = controller.onTitle(title)

    /** Camera, microphone and other web permissions are always denied. */
    override fun onPermissionRequest(request: PermissionRequest) {
        request.deny()
    }

    override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
        callback?.invoke(origin, false, false)
    }

    /** Uploading device files to websites is not supported. */
    override fun onShowFileChooser(
        webView: WebView?,
        filePathCallback: ValueCallback<Array<Uri>>?,
        fileChooserParams: WebChromeClient.FileChooserParams?,
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        controller.notice("Uploading files to websites isn't supported in the in-app browser.")
        return true
    }
}

/** Clears everything the WebView stores on the device. */
object BrowserData {
    fun clearAll(view: WebView?) {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        view?.clearCache(true)
        view?.clearHistory()
        view?.clearFormData()
        view?.context?.let { WebViewDatabase.getInstance(it).clearHttpAuthUsernamePassword() }
    }
}
