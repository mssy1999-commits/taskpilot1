package com.taskpilot.assistant.ai

/**
 * Deterministic website-creation tool: works from a clean install, without a model,
 * Firebase project, API key, subscription, or network connection.
 *
 * This is a responsive HTML template generator, NOT an LLM or a website publisher.
 * It must never silently replace a creation request with a web search.
 */
object WebsiteBuilder {
    data class Site(val title: String, val fileName: String, val html: String)

    private val buildVerb = Regex(
        """\b(?:make|create|build|generate|design|develop)\s+(?:(?:me|us)\s+)?(?:(?:a|an|the|my|simple|professional|modern|new|free|responsive|basic|business)\s+){0,5}(?:website|web\s*site|landing\s*page|home\s*page|homepage|portfolio\s+site)\b""",
        RegexOption.IGNORE_CASE,
    )

    /** Returns null for search/explanation requests: create only on explicit build intent. */
    fun recognizes(prompt: String): Boolean {
        val text = prompt.trim().lowercase()
        if (text.isBlank()) return false
        if (Regex("""\b(?:don't|dont|do not|never|without)\s+(?:make|create|build|generate|design|develop)\b""").containsMatchIn(text)) return false
        if (text.startsWith("how ") || text.startsWith("why ") || text.startsWith("what ") || text.startsWith("explain ")) return false
        return buildVerb.containsMatchIn(text)
    }

    fun build(prompt: String): Site {
        require(recognizes(prompt)) { "Not a website-creation request" }
        val forMatch = Regex("""\b(?:website|web\s*site|landing\s*page|home\s*page|homepage|portfolio\s+site)\s+(?:for|about)\s+(.+)$""", RegexOption.IGNORE_CASE).find(prompt)
        val rawSubject = forMatch?.groupValues?.getOrNull(1)
            ?.split(Regex("[.!?\\n]"), limit = 2)?.firstOrNull()
            ?.replace(Regex("""(?i)\s+(?:with|including|that has|which has)\s+.+$"""), "")
            ?.trim(' ', ',', '.', '"', '\'', ':', ';')
            ?.take(72)
            .orEmpty()
        val title = rawSubject.ifBlank { "My Website" }
        val fileName = title.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(45).ifEmpty { "website" } + ".html"
        val safeTitle = escape(title)
        val content = if (title == "My Website") "A polished starting point for your next idea." else "A modern online home for $safeTitle."
        val html = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${safeTitle} — responsive website starter">
  <title>$safeTitle</title>
  <style>
    :root { color-scheme: dark; --bg: #0b1120; --panel: #141f34; --ink: #f4f7ff; --muted: #bdc6da; --accent: #4fe0b9; }
    * { box-sizing: border-box; } html { scroll-behavior: smooth; }
    body { margin: 0; background: var(--bg); color: var(--ink); font: 16px/1.6 system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; }
    a { color: inherit; text-decoration: none; } a:focus-visible { outline: 3px solid var(--accent); outline-offset: 4px; }
    .wrap { width: min(1120px, 92%); margin: auto; }
    header { position: sticky; z-index: 10; top: 0; background: #0b1120eb; backdrop-filter: blur(16px); border-bottom: 1px solid #ffffff1a; }
    .nav { display: flex; align-items: center; justify-content: space-between; gap: 20px; min-height: 74px; }
    .brand { font-weight: 800; font-size: 1.13rem; letter-spacing: -.02em; } .brand i { color: var(--accent); font-style: normal; }
    .links { display: flex; flex-wrap: wrap; gap: 24px; color: var(--muted); font-size: .94rem; }
    .links a:hover { color: var(--accent); }
    .hero { background: radial-gradient(ellipse at 80% 10%,#127a7455,transparent 55%), linear-gradient(130deg,#0b1120,#172540); padding: 130px 0 120px; }
    .badge { display: inline-block; border: 1px solid #4fe0b966; color: var(--accent); border-radius: 40px; padding: 6px 13px; font-size: .8rem; letter-spacing: .06em; text-transform: uppercase; }
    h1 { font-size: clamp(2.8rem,7vw,5.8rem); line-height: 1.07; letter-spacing: -.055em; margin: 22px 0; max-width: 900px; }
    h2 { font-size: clamp(1.9rem,4vw,3rem); line-height: 1.15; letter-spacing: -.035em; }
    p { color: var(--muted); } .lede { font-size: 1.2rem; max-width: 660px; }
    .buttons { display:flex; gap:14px; flex-wrap:wrap; margin-top:33px; }
    .button { display: inline-flex; align-items:center; min-height: 48px; padding: 12px 23px; border-radius: 12px; font-weight: 700; background: var(--accent); color: #081b1d; }
    .button.secondary { background: transparent; color: var(--ink); border: 1px solid #ffffff66; }
    section { padding: 92px 0; } .intro { max-width: 730px; }
    .cards { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 22px; margin-top: 38px; }
    .card { border: 1px solid #ffffff1c; border-radius: 19px; padding: 29px; background: linear-gradient(145deg,#192945,#111b2e); min-height: 220px; }
    .card strong { font-size: 1.08rem; } .card span { display: block; font-size: 1.75rem; margin-bottom: 15px; }
    .contact { border-radius: 26px; padding: 54px; background: linear-gradient(130deg,#17413f,#182840); border:1px solid #4fe0b944; }
    footer { padding: 38px 0; border-top: 1px solid #ffffff1a; color: var(--muted); font-size: .85rem; }
    @media (max-width:750px) { .nav { align-items:flex-start; flex-direction:column; padding:16px 0; gap:7px; } .links { gap:16px; } .hero { padding:88px 0; } .cards { grid-template-columns:1fr; } section {padding:66px 0;} .contact {padding:30px;} }
    @media (prefers-reduced-motion: reduce) { html {scroll-behavior:auto;} }
  </style>
</head>
<body>
<header><div class="wrap nav"><a class="brand" href="#top">$safeTitle<i>.</i></a><nav class="links" aria-label="Main menu"><a href="#about">About</a><a href="#highlights">Highlights</a><a href="#contact">Contact</a></nav></div></header>
<main id="top">
  <div class="hero"><div class="wrap"><span class="badge">Welcome</span><h1>$safeTitle</h1><p class="lede">$content</p><div class="buttons"><a class="button" href="#highlights">Explore website →</a><a class="button secondary" href="#contact">Get in touch</a></div></div></div>
  <section id="about"><div class="wrap intro"><span class="badge">About</span><h2>Make a memorable first impression.</h2><p>This website is ready to customize. Replace this paragraph with your genuine story, your products or services, and what makes your organization different.</p></div></section>
  <section id="highlights"><div class="wrap"><span class="badge">Highlights</span><h2>What visitors can discover</h2><div class="cards">
    <article class="card"><span aria-hidden="true">✦</span><strong>Your story</strong><p>Edit this card to explain your mission and who you serve.</p></article>
    <article class="card"><span aria-hidden="true">◇</span><strong>What you offer</strong><p>Replace this text with actual products, services or features.</p></article>
    <article class="card"><span aria-hidden="true">↗</span><strong>Next steps</strong><p>Add real contact information or links after reviewing the HTML.</p></article>
  </div></div></section>
  <section id="contact"><div class="wrap"><div class="contact"><span class="badge">Contact</span><h2>Let's connect.</h2><p>Replace this placeholder with your verified email address, phone number or preferred contact method.</p><a class="button" href="#top">Back to top ↑</a></div></div></section>
</main><footer><div class="wrap">© <span id="year">2026</span> $safeTitle · Website template created locally with TaskPilot. Review content before publishing.</div></footer>
<script>document.getElementById('year').textContent = new Date().getFullYear();</script>
</body></html>""".trimIndent()
        return Site(title, fileName, html)
    }

    private fun escape(raw: String): String = buildString {
        for (ch in raw) append(when (ch) {
            '&' -> "&amp;"
            '<' -> "&lt;"
            '>' -> "&gt;"
            '"' -> "&quot;"
            '\'' -> "&#39;"
            else -> ch.toString()
        })
    }
}
