@file:OptIn(ExperimentalMaterial3Api::class)

package com.taskpilot.assistant.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.taskpilot.assistant.R
import com.taskpilot.assistant.data.AttachmentTypes
import com.taskpilot.assistant.speech.SpeechInputController
import com.taskpilot.assistant.speech.VoiceState
import com.taskpilot.assistant.ui.components.BrowserPanel
import com.taskpilot.assistant.ui.components.ConfirmActionDialog
import com.taskpilot.assistant.ui.components.EmptyChat
import com.taskpilot.assistant.ui.components.InputBar
import com.taskpilot.assistant.ui.components.MessageBubble
import com.taskpilot.assistant.ui.components.WorkingBubble
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val voice by vm.voiceState.collectAsStateWithLifecycle()
    val speakingId by vm.speakingMessageId.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) { vm.events.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(voice) {
        val v = voice
        if (v is VoiceState.Error) {
            snackbar.showSnackbar(v.message)
            vm.clearVoiceError()
        }
    }

    // ---- pickers & permissions (requested only when used) ----------------------------
    val websiteSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri == null) vm.websiteExportCanceled() else vm.exportWebsite(uri)
    }
    LaunchedEffect(ui.websiteExportName) {
        ui.websiteExportName?.let { suggestedName ->
            vm.websiteExportPickerOpening() // consume before opening to avoid rotation relaunch
            websiteSaver.launch(suggestedName)
        }
    }
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(AttachmentTypes.MAX_ATTACHMENTS_PER_MESSAGE)
    ) { uris -> vm.addAttachments(uris) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addAttachments(uris)
    }
    val systemSpeech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) vm.onVoiceText(text)
    }
    fun launchSystemSpeech() {
        try {
            systemSpeech.launch(SpeechInputController.recognizerIntent(settings.voiceLanguage))
        } catch (e: ActivityNotFoundException) {
            scope.launch { snackbar.showSnackbar("No speech recognition service is installed on this device.") }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            vm.startVoice()
        } else {
            // Without the permission, the system speech dialog still works (it records, not this app).
            launchSystemSpeech()
        }
    }
    fun onMic() {
        when {
            voice is VoiceState.Listening -> vm.stopVoice()
            !vm.speechRecognitionAvailable -> launchSystemSpeech()
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> vm.startVoice()
            else -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    BackHandler(enabled = ui.browserMode != BrowserMode.HIDDEN) {
        vm.setBrowserMode(if (ui.browserMode == BrowserMode.FULL) BrowserMode.SPLIT else BrowserMode.HIDDEN)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TaskPilot", style = MaterialTheme.typography.titleLarge)
                        Text(
                            when {
                                ui.provider == com.taskpilot.assistant.ai.AiProvider.LOCAL -> "Offline · ${ui.modelName}"
                                !ui.firebaseConfigured -> "Setup needed"
                                ui.provider == com.taskpilot.assistant.ai.AiProvider.GROK -> "Grok · ${ui.modelName}"
                                else -> ui.modelName
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                },
                actions = {
                    IconToggleButton(
                        checked = ui.browserMode != BrowserMode.HIDDEN,
                        onCheckedChange = { on -> vm.setBrowserMode(if (on) BrowserMode.SPLIT else BrowserMode.HIDDEN) },
                    ) {
                        Icon(painterResource(R.drawable.ic_globe), contentDescription = "Show browser")
                    }
                    IconToggleButton(
                        checked = settings.speakReplies,
                        onCheckedChange = { on -> vm.updateSettings { it.copy(speakReplies = on) } },
                    ) {
                        Icon(
                            painterResource(if (settings.speakReplies) R.drawable.ic_volume_up else R.drawable.ic_volume_off),
                            contentDescription = if (settings.speakReplies) "Spoken replies on" else "Spoken replies off",
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings and privacy")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding(),
        ) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val full = maxHeight
                val browserHeight = if (ui.browserMode == BrowserMode.SPLIT) full * 0.48f else full
                // Layer 1: the browser. Always composed so automation has a real viewport.
                BrowserPanel(
                    controller = vm.browser,
                    mode = ui.browserMode,
                    onModeChange = vm::setBrowserMode,
                    onError = { msg -> scope.launch { snackbar.showSnackbar(msg) } },
                    modifier = Modifier.fillMaxWidth().height(browserHeight),
                    blockImages = settings.fastBrowsing,
                )
                // Layer 2: the conversation (opaque; covers the browser when hidden).
                if (ui.browserMode != BrowserMode.FULL) {
                    val chatHeight = if (ui.browserMode == BrowserMode.SPLIT) full - browserHeight else full
                    MessagesPane(
                        vm = vm,
                        ui = ui,
                        speakingId = speakingId,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(chatHeight)
                            .background(MaterialTheme.colorScheme.background),
                    )
                }
            }
            InputBar(
                draft = ui.draft,
                onDraftChange = vm::onDraftChange,
                pendingAttachments = ui.pendingAttachments,
                importingCount = ui.importingCount,
                repository = vm.attachmentRepository,
                voiceState = voice,
                isRunning = ui.isRunning,
                onSend = vm::send,
                onStop = vm::stop,
                onMic = ::onMic,
                onPickPhotos = {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onPickFiles = { filePicker.launch(AttachmentTypes.PICKER_MIME_TYPES) },
                onRemoveAttachment = vm::removePendingAttachment,
            )
        }
    }

    ui.confirmation?.let { request ->
        ConfirmActionDialog(request = request, onAnswer = vm::answerConfirmation)
    }
}

@Composable
private fun MessagesPane(vm: ChatViewModel, ui: ChatUiState, speakingId: String?, modifier: Modifier) {
    val listState = rememberLazyListState()
    val itemCount = ui.messages.size + (if (ui.isRunning) 1 else 0)
    LaunchedEffect(itemCount, ui.liveSteps.size) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }
    Box(modifier) {
        if (ui.loaded && ui.messages.isEmpty() && !ui.isRunning) {
            EmptyChat(
                firebaseConfigured = ui.firebaseConfigured,
                offline = ui.provider == com.taskpilot.assistant.ai.AiProvider.LOCAL,
                onPrompt = vm::usePrompt,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(ui.messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        repository = vm.attachmentRepository,
                        isSpeaking = speakingId == message.id,
                        onSpeak = { vm.speak(message) },
                        onStopSpeaking = vm::stopSpeaking,
                        onLinkClick = vm::openInBrowser,
                    )
                }
                if (ui.isRunning) {
                    item(key = "working") { WorkingBubble(ui.liveSteps, ui.status) }
                }
            }
        }
    }
}
