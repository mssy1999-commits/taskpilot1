package com.taskpilot.assistant.ai

import com.taskpilot.assistant.browser.BrowserController
import com.taskpilot.assistant.browser.BrowserToolExecutor
import com.taskpilot.assistant.data.AppSettings
import com.taskpilot.assistant.data.StepStatus
import com.taskpilot.assistant.data.ToolStep
import com.taskpilot.assistant.policy.ActionDescriber
import com.taskpilot.assistant.policy.ActionPolicy
import com.taskpilot.assistant.policy.Decision
import com.taskpilot.assistant.policy.ParseResult
import com.taskpilot.assistant.policy.PolicyContext
import com.taskpilot.assistant.policy.ToolCallParser
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Per-turn counters shared by the engines. */
class TurnBudget {
    var toolCalls = 0
    var rounds = 0
    val roundsExceeded: Boolean get() = rounds > AgentLimits.MAX_ROUNDS + 1
}

/**
 * A model-proposed tool call in provider-neutral form. [args] is null when the
 * model sent arguments that are not valid JSON.
 */
data class ProposedCall(val name: String, val args: Map<String, Any?>?)

/**
 * Runs model-proposed browser calls for any provider: allowlist validation, element
 * inspection, the confirmation policy, re-checking after approval, execution, and
 * the activity-log steps. This is the single path from model output to the browser.
 */
class BrowserToolRunner(
    private val browser: BrowserController,
    private val executor: BrowserToolExecutor,
) {

    /** Runs [calls] in order and returns one JSON result per call. */
    suspend fun runBatch(
        calls: List<ProposedCall>,
        budget: TurnBudget,
        settings: AppSettings,
        listener: AgentListener,
        steps: MutableList<ToolStep>,
    ): List<JsonObject> {
        // Page content in a result re-numbers element ids, so later calls in the same
        // batch that target elements would point at stale ids.
        var idsRefreshed = false
        val results = ArrayList<JsonObject>(calls.size)
        for (call in calls) {
            val payload = when {
                budget.toolCalls >= AgentLimits.MAX_TOOL_CALLS_PER_TURN || budget.rounds > AgentLimits.MAX_ROUNDS ->
                    limitReachedJson()
                idsRefreshed && call.args?.containsKey("element_id") == true -> errorJson(
                    "stale_element_id",
                    "Not run: an earlier action in this batch refreshed the page and its element ids. " +
                        "Use the ids from the latest page content.",
                )
                else -> {
                    budget.toolCalls++
                    runOne(call, settings, listener, steps)
                }
            }
            if (payload.containsKey(BrowserToolExecutor.UNTRUSTED_KEY)) idsRefreshed = true
            results += payload
        }
        return results
    }

    private suspend fun runOne(
        call: ProposedCall,
        settings: AppSettings,
        listener: AgentListener,
        steps: MutableList<ToolStep>,
    ): JsonObject {
        val args = call.args
        if (args == null) {
            addStep(steps, listener, "Blocked an invalid browser action", StepStatus.FAILED, "Arguments were not valid JSON")
            return errorJson("rejected", "The arguments were not valid JSON.")
        }
        val parsed = ToolCallParser.parse(call.name, args)
        if (parsed is ParseResult.Rejected) {
            addStep(steps, listener, "Blocked an invalid browser action", StepStatus.FAILED, parsed.reason)
            return errorJson("rejected", parsed.reason)
        }
        val action = (parsed as ParseResult.Ok).action
        listener.onBrowserActivity()
        if (!browser.isAttached) withTimeoutOrNull(3_000L) { while (!browser.isAttached) delay(100) }

        val elementId = action.targetElementId
        val element = if (elementId != null) {
            val found = try {
                browser.inspect(elementId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return errorJson("error", e.message ?: "Couldn't inspect the element.")
            }
            found ?: return errorJson(
                "not_found",
                "Element $elementId isn't on the page any more. Use ids from the latest page content.",
            )
        } else {
            null
        }

        val stepIndex = addStep(steps, listener, ActionDescriber.describe(action, element), StepStatus.RUNNING)
        val decision = ActionPolicy.evaluate(action, PolicyContext(browser.state.value.url, element, settings.confirmEveryAction))
        if (decision is Decision.Confirm) {
            updateStep(steps, listener, stepIndex, StepStatus.AWAITING_CONFIRMATION)
            val approved = listener.confirm(decision.request)
            if (!approved) {
                updateStep(steps, listener, stepIndex, StepStatus.DENIED, "You declined")
                return buildJsonObject {
                    put("status", "denied_by_user")
                    put("message", "The user declined this action. Do not retry it; ask the user how they want to proceed.")
                }
            }
            updateStep(steps, listener, stepIndex, StepStatus.RUNNING)
            // The page may have changed while the dialog was open; make sure the
            // approved element is still the same one.
            if (elementId != null && element != null) {
                val again = runCatching { browser.inspect(elementId) }.getOrNull()
                if (again == null || again.tag != element.tag || again.label != element.label) {
                    updateStep(steps, listener, stepIndex, StepStatus.FAILED, "The page changed before the action ran")
                    return errorJson("page_changed", "The page changed while waiting for approval. Call read_page and try again.")
                }
            }
        }

        return try {
            val result = executor.execute(action, settings.searchEngine)
            updateStep(steps, listener, stepIndex, StepStatus.DONE)
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            updateStep(steps, listener, stepIndex, StepStatus.FAILED, e.message)
            errorJson("error", e.message ?: "The action failed.")
        }
    }

    /** Older page snapshot replaced by a short note to keep requests small. */
    fun compactedSnapshot(r: JsonObject): JsonObject = buildJsonObject {
        r["status"]?.let { put("status", it) }
        r["page"]?.let { put("page", it) }
        put("note", "Earlier page content was removed to save space. Call read_page again if you need it.")
    }

    private fun addStep(steps: MutableList<ToolStep>, listener: AgentListener, label: String, status: StepStatus, detail: String? = null): Int {
        steps += ToolStep(id = steps.size, label = label, status = status, detail = detail)
        listener.onStepsChanged(steps.toList())
        return steps.lastIndex
    }

    private fun updateStep(steps: MutableList<ToolStep>, listener: AgentListener, index: Int, status: StepStatus, detail: String? = null) {
        steps[index] = steps[index].copy(status = status, detail = detail ?: steps[index].detail)
        listener.onStepsChanged(steps.toList())
    }

    private fun errorJson(status: String, message: String): JsonObject = buildJsonObject {
        put("status", status)
        put("error", message)
    }

    private fun limitReachedJson(): JsonObject = buildJsonObject {
        put("status", "limit_reached")
        put("error", "Step limit for this turn reached. Stop using tools and summarize progress for the user.")
    }
}
