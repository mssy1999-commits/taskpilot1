package com.taskpilot.assistant.browser

import android.os.SystemClock
import android.webkit.WebView
import androidx.annotation.MainThread
import com.taskpilot.assistant.policy.ElementInfo
import com.taskpilot.assistant.policy.ScrollDirection
import com.taskpilot.assistant.policy.UrlPolicy
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject

class BrowserUnavailableException : Exception("The in-app browser isn't open right now.")
class BrowserScriptException(message: String) : Exception(message)

/**
 * Owns the app's single automation WebView (attached by the UI) and exposes
 * suspend functions for the allowlisted browser actions. Holds no Context, so it
 * can live in the ViewModel; the WebView is attached/detached with the UI.
 *
 * All WebView access happens on the main thread.
 */
class BrowserController {

    data class State(
        val url: String = "",
        val title: String = "",
        val progress: Int = 0,
        val isLoading: Boolean = false,
        val canGoBack: Boolean = false,
        val canGoForward: Boolean = false,
        /** Error of the last main-frame load (e.g. net::ERR_NAME_NOT_RESOLVED), if any. */
        val lastError: String? = null,
        val httpStatus: Int? = null,
    )

    private val json = Json { ignoreUnknownKeys = true }
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private val _notices = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** Short messages for the user (blocked links, SSL errors, ...). */
    val notices: SharedFlow<String> = _notices.asSharedFlow()

    private val _rendererGeneration = MutableStateFlow(0)
    /** Incremented when the WebView renderer crashed and the view must be recreated. */
    val rendererGeneration: StateFlow<Int> = _rendererGeneration.asStateFlow()

    private val navigationStarts = MutableStateFlow(0L)
    private var webView: WebView? = null
    private var lastUpgradeUrl: String? = null
    private var lastUpgradeAt = 0L

    val isAttached: Boolean get() = webView != null

    // ---- lifecycle (called by the UI) ----------------------------------------

    @MainThread
    fun attach(view: WebView) {
        webView = view
        val restore = _state.value.url
        if (view.url.isNullOrEmpty() && restore.startsWith("https://")) view.loadUrl(restore)
    }

    @MainThread
    fun detach(view: WebView) {
        if (webView === view) webView = null
    }

    // ---- callbacks from the WebView clients -----------------------------------

    internal fun onPageStarted(url: String?) {
        _state.update {
            // Reset progress so "mostly loaded" checks refer to the new page, not the previous one.
            it.copy(url = url ?: it.url, isLoading = true, progress = 5, lastError = null, httpStatus = null)
        }
        navigationStarts.value = navigationStarts.value + 1
    }

    internal fun onPageFinished(view: WebView, url: String?) {
        _state.update {
            it.copy(
                url = url ?: it.url,
                title = view.title ?: it.title,
                isLoading = false,
                progress = 100,
                canGoBack = view.canGoBack(),
                canGoForward = view.canGoForward(),
            )
        }
    }

    internal fun onProgress(progress: Int) = _state.update { it.copy(progress = progress) }

    internal fun onTitle(title: String?) = _state.update { it.copy(title = title ?: it.title) }

    internal fun onHistoryChanged(view: WebView, url: String?) = _state.update {
        it.copy(url = url ?: it.url, canGoBack = view.canGoBack(), canGoForward = view.canGoForward())
    }

    internal fun onMainFrameError(description: String) = _state.update { it.copy(lastError = description) }

    internal fun onMainFrameHttpStatus(code: Int) = _state.update { it.copy(httpStatus = code) }

    internal fun notice(message: String) {
        _notices.tryEmit(message)
    }

    internal fun onRendererGone() {
        webView = null
        _state.update { it.copy(isLoading = false) }
        _rendererGeneration.value = _rendererGeneration.value + 1
        notice("The browser stopped unexpectedly and was restarted.")
    }

    /**
     * Guards the http->https upgrade against redirect loops (a site that redirects
     * https back to http). Returns false if the same URL was just upgraded.
     */
    internal fun allowHttpsUpgrade(url: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        val loop = url == lastUpgradeUrl && now - lastUpgradeAt < 3_000
        lastUpgradeUrl = url
        lastUpgradeAt = now
        return !loop
    }

    // ---- user controls (toolbar) -----------------------------------------------

    @MainThread
    fun userNavigate(input: String): String? {
        val view = webView ?: return "The browser isn't ready yet."
        return when (val r = UrlPolicy.validateNavigation(input)) {
            is UrlPolicy.Result.Allowed -> {
                view.loadUrl(r.url)
                null
            }
            is UrlPolicy.Result.Rejected -> r.reason
        }
    }

    /** Preview trusted, app-generated HTML without networking or enabling local file access. */
    @MainThread
    fun previewGeneratedHtml(html: String): Boolean {
        val view = webView ?: return false
        view.loadDataWithBaseURL("https://taskpilot.invalid/", html, "text/html", "UTF-8", null)
        return true
    }

    @MainThread fun userBack() { webView?.takeIf { it.canGoBack() }?.goBack() }
    @MainThread fun userForward() { webView?.takeIf { it.canGoForward() }?.goForward() }
    @MainThread fun userReload() { webView?.reload() }
    @MainThread fun userStop() { webView?.stopLoading() }

    /** Clears cookies, cache, web storage, history and form data. */
    @MainThread
    fun clearBrowsingData() {
        BrowserData.clearAll(webView)
        webView?.loadUrl("about:blank")
        _state.value = State()
    }

    // ---- automation actions (validated by the policy layer before reaching here) --

    data class PageResult(val url: String, val title: String, val error: String?, val httpStatus: Int?, val navigated: Boolean)

    suspend fun open(url: String): PageResult = onMain {
        val view = requireView()
        val navigated = runAndSettle(expectNavigation = true) { view.loadUrl(url) }
        pageResult(navigated)
    }

    suspend fun goBack(): PageResult = onMain {
        val view = requireView()
        if (!view.canGoBack()) throw BrowserScriptException("There is no previous page.")
        val navigated = runAndSettle(expectNavigation = true) { view.goBack() }
        pageResult(navigated)
    }

    suspend fun snapshot(maxChars: Int): JsonObject = onMain {
        val result = evaluate(BrowserScripts.snapshot(maxChars))
        if (result["ok"].asBool() != true) throw BrowserScriptException(result["error"].asString() ?: "Could not read the page.")
        result
    }

    /** Returns facts about an element from the latest snapshot, or null if it no longer exists. */
    suspend fun inspect(elementId: String): ElementInfo? = onMain {
        val r = evaluate(BrowserScripts.inspect(elementId))
        if (r["found"].asBool() != true) return@onMain null
        ElementInfo(
            id = elementId,
            tag = r["tag"].asString().orEmpty(),
            type = r["type"].asString().orEmpty(),
            role = r["role"].asString().orEmpty(),
            label = r["label"].asString().orEmpty(),
            href = r["href"].asString()?.takeIf { it.isNotEmpty() },
            name = r["name"].asString().orEmpty(),
            autocomplete = r["autocomplete"].asString().orEmpty(),
            isSubmitControl = r["isSubmit"].asBool() == true,
            inForm = r["inForm"].asBool() == true,
            formMethod = r["formMethod"].asString().orEmpty(),
            formAction = r["formAction"].asString().orEmpty(),
            isSearchContext = r["isSearch"].asBool() == true,
            isContentEditable = r["editable"].asBool() == true,
            disabled = r["disabled"].asBool() == true,
        )
    }

    suspend fun click(elementId: String): PageResult = onMain {
        var outcome: JsonObject? = null
        val navigated = runAndSettle { outcome = evaluate(BrowserScripts.click(elementId)) }
        outcome?.let { throwIfFailed(it) }
        pageResult(navigated)
    }

    data class TypeResult(val page: PageResult, val submitted: Boolean, val value: String)

    suspend fun type(elementId: String, text: String, submit: Boolean): TypeResult = onMain {
        var outcome: JsonObject? = null
        val navigated = runAndSettle(expectNavigation = submit) {
            outcome = evaluate(BrowserScripts.type(elementId, text, submit))
        }
        val r = outcome ?: throw BrowserScriptException("Typing failed.")
        throwIfFailed(r)
        TypeResult(pageResult(navigated), r["submitted"].asBool() == true, r["value"].asString().orEmpty())
    }

    suspend fun select(elementId: String, option: String): JsonObject = onMain {
        val r = evaluate(BrowserScripts.select(elementId, option))
        delay(300)
        r
    }

    suspend fun scroll(direction: ScrollDirection): Int = onMain {
        val r = evaluate(BrowserScripts.scroll(direction))
        throwIfFailed(r)
        delay(250)
        r["scrollPercent"]?.let { (it as? JsonPrimitive)?.contentOrNull?.toDoubleOrNull()?.toInt() } ?: 0
    }

    // ---- internals --------------------------------------------------------------

    private suspend fun <T> onMain(block: suspend () -> T): T = withContext(Dispatchers.Main.immediate) { block() }

    private fun requireView(): WebView = webView ?: throw BrowserUnavailableException()

    private fun pageResult(navigated: Boolean): PageResult {
        val s = _state.value
        return PageResult(url = s.url, title = s.title, error = s.lastError, httpStatus = s.httpStatus, navigated = navigated)
    }

    private fun throwIfFailed(result: JsonObject) {
        if (result["ok"].asBool() == true) return
        val message = when (val code = result["error"].asString()) {
            "not_found" -> "That element is no longer on the page. Call read_page to get fresh element ids."
            "not_editable" -> "That element can't be typed into."
            null -> "The action failed."
            else -> code
        }
        throw BrowserScriptException(message)
    }

    /**
     * Runs [action], then waits for a navigation it may trigger to finish (or a short
     * settle time for in-page updates). Returns true if a navigation happened.
     */
    private suspend fun runAndSettle(expectNavigation: Boolean = false, action: suspend () -> Unit): Boolean {
        val before = navigationStarts.value
        action()
        // Clicks usually start navigating within a few hundred ms; don't wait long for one.
        val waitForStart = if (expectNavigation) 3_000L else 800L
        val started = withTimeoutOrNull(waitForStart) { navigationStarts.first { it > before } } != null
        if (started) {
            // Continue once the page is mostly loaded; don't wait for slow ads/trackers.
            withTimeoutOrNull(15_000L) { _state.first { !it.isLoading || it.progress >= 85 } }
            delay(250)
        } else {
            delay(350)
        }
        return started
    }

    private suspend fun evaluate(script: String, timeoutMs: Long = 10_000L): JsonObject {
        val view = requireView()
        val raw = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<String?> { cont ->
                view.evaluateJavascript(script) { value -> if (cont.isActive) cont.resume(value) }
            }
        } ?: throw BrowserScriptException(
            "The page didn't respond. It may still be loading or showing a dialog; ask the user to check the browser."
        )
        return decode(raw)
    }

    /** evaluateJavascript returns the JSON encoding of the script's return value (a string). */
    private fun decode(raw: String?): JsonObject {
        if (raw == null || raw == "null") throw BrowserScriptException("The page returned no result.")
        return try {
            val inner = (json.parseToJsonElement(raw) as? JsonPrimitive)?.takeIf { it.isString }?.content
                ?: throw BrowserScriptException("Unexpected script result.")
            json.parseToJsonElement(inner).jsonObject
        } catch (e: BrowserScriptException) {
            throw e
        } catch (e: Exception) {
            throw BrowserScriptException("Couldn't parse the page result.")
        }
    }

    private fun kotlinx.serialization.json.JsonElement?.asString(): String? =
        (this as? JsonPrimitive)?.takeIf { it.isString }?.content

    private fun kotlinx.serialization.json.JsonElement?.asBool(): Boolean? = (this as? JsonPrimitive)?.booleanOrNull
}
