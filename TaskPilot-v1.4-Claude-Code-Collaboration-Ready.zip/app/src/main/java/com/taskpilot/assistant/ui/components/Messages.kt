package com.taskpilot.assistant.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.taskpilot.assistant.R
import com.taskpilot.assistant.data.Attachment
import com.taskpilot.assistant.data.AttachmentKind
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.data.AttachmentTypes
import com.taskpilot.assistant.data.ChatMessage
import com.taskpilot.assistant.data.Role
import com.taskpilot.assistant.data.StepStatus
import com.taskpilot.assistant.data.ToolStep

@Composable
fun MessageBubble(
    message: ChatMessage,
    repository: AttachmentRepository,
    isSpeaking: Boolean,
    onSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onLinkClick: (String) -> Unit,
) {
    when (message.role) {
        Role.USER -> UserBubble(message, repository)
        Role.ASSISTANT -> AssistantBubble(message, isSpeaking, onSpeak, onStopSpeaking, onLinkClick)
        Role.NOTE -> NoteRow(message)
    }
}

@Composable
private fun UserBubble(message: ChatMessage, repository: AttachmentRepository) {
    Column(Modifier.fillMaxWidth().padding(start = 48.dp), horizontalAlignment = Alignment.End) {
        if (message.attachments.isNotEmpty()) {
            AttachmentStrip(message.attachments, repository, onRemove = null)
            Spacer(Modifier.size(4.dp))
        }
        if (message.text.isNotBlank()) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
            ) {
                Text(message.text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
            }
        }
    }
}

@Composable
private fun AssistantBubble(
    message: ChatMessage,
    isSpeaking: Boolean,
    onSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onLinkClick: (String) -> Unit,
) {
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme
    val annotated = remember(message.text, colors.primary) {
        renderMarkdown(message.text, colors.primary, colors.surfaceVariant, onLinkClick)
    }
    Column(Modifier.fillMaxWidth().padding(end = 32.dp)) {
        if (message.steps.isNotEmpty()) {
            StepsSummary(message.steps)
            Spacer(Modifier.size(6.dp))
        }
        Surface(
            color = colors.surfaceContainerLowest,
            contentColor = colors.onSurface,
            shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp),
            tonalElevation = 1.dp,
        ) {
            Text(annotated, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = if (isSpeaking) onStopSpeaking else onSpeak, modifier = Modifier.size(36.dp)) {
                Icon(
                    painterResource(if (isSpeaking) R.drawable.ic_stop else R.drawable.ic_volume_up),
                    contentDescription = if (isSpeaking) "Stop reading" else "Read aloud",
                    modifier = Modifier.size(18.dp),
                    tint = colors.onSurfaceVariant,
                )
            }
            IconButton(onClick = { copyToClipboard(context, message.text) }, modifier = Modifier.size(36.dp)) {
                Icon(painterResource(R.drawable.ic_copy), contentDescription = "Copy", modifier = Modifier.size(16.dp), tint = colors.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun NoteRow(message: ChatMessage) {
    val colors = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (message.steps.isNotEmpty()) StepsSummary(message.steps)
        Surface(
            color = if (message.isError) colors.errorContainer else colors.surfaceContainer,
            contentColor = if (message.isError) colors.onErrorContainer else colors.onSurfaceVariant,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
        ) {
            Text(message.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
        }
    }
}

/** Collapsible "Used the browser · N steps" summary under a reply. */
@Composable
private fun StepsSummary(steps: List<ToolStep>) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(colors.surfaceContainer)
            .clickable { expanded = !expanded }
            .animateContentSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(R.drawable.ic_globe), contentDescription = null, modifier = Modifier.size(16.dp), tint = colors.primary)
            Spacer(Modifier.width(8.dp))
            Text(
                "Used the browser · ${steps.size} step${if (steps.size == 1) "" else "s"}",
                style = MaterialTheme.typography.labelLarge,
                color = colors.onSurfaceVariant,
            )
            Spacer(Modifier.width(4.dp))
            Icon(
                if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = if (expanded) "Hide steps" else "Show steps",
                modifier = Modifier.size(18.dp),
                tint = colors.onSurfaceVariant,
            )
        }
        if (expanded) {
            Spacer(Modifier.size(6.dp))
            steps.forEach { StepRow(it) }
        }
    }
}

@Composable
fun StepRow(step: ToolStep) {
    val colors = MaterialTheme.colorScheme
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) {
            when (step.status) {
                StepStatus.RUNNING -> CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(14.dp))
                StepStatus.AWAITING_CONFIRMATION -> Icon(Icons.Default.Warning, null, tint = colors.secondary, modifier = Modifier.size(16.dp))
                StepStatus.DONE -> Icon(Icons.Default.Check, null, tint = colors.tertiary, modifier = Modifier.size(16.dp))
                StepStatus.FAILED -> Icon(Icons.Default.Clear, null, tint = colors.error, modifier = Modifier.size(16.dp))
                StepStatus.DENIED -> Icon(Icons.Default.Close, null, tint = colors.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(step.label, style = MaterialTheme.typography.bodyMedium)
            val detail = when (step.status) {
                StepStatus.AWAITING_CONFIRMATION -> "Waiting for your approval"
                else -> step.detail
            }
            if (!detail.isNullOrBlank()) {
                Text(detail, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Shown while the assistant works: live browser steps plus a thinking indicator. */
@Composable
fun WorkingBubble(steps: List<ToolStep>, status: String? = null) {
    val colors = MaterialTheme.colorScheme
    Column(
        Modifier
            .padding(end = 32.dp)
            .clip(RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp))
            .background(colors.surfaceContainerLowest)
            .animateContentSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        steps.takeLast(6).forEach { StepRow(it) }
        if (steps.size > 6) {
            Text("…and ${steps.size - 6} earlier steps", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
        }
        if (!status.isNullOrBlank()) {
            Text(status, style = MaterialTheme.typography.bodySmall, color = colors.secondary, modifier = Modifier.padding(top = 4.dp))
        }
        ThinkingDots()
    }
}

@Composable
private fun ThinkingDots() {
    val transition = rememberInfiniteTransition(label = "thinking")
    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(3) { i ->
            val alpha by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 180), RepeatMode.Reverse),
                label = "dot$i",
            )
            Box(Modifier.size(7.dp).alpha(alpha).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AttachmentStrip(attachments: List<Attachment>, repository: AttachmentRepository, onRemove: ((Attachment) -> Unit)?) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        attachments.forEach { AttachmentChip(it, repository, onRemove) }
    }
}

@Composable
private fun AttachmentChip(attachment: Attachment, repository: AttachmentRepository, onRemove: ((Attachment) -> Unit)?) {
    val colors = MaterialTheme.colorScheme
    val thumb by produceState<ImageBitmap?>(initialValue = null, attachment.id) {
        value = repository.loadThumbnail(attachment, 192)?.asImageBitmap()
    }
    Row(
        Modifier
            .widthIn(max = 240.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(colors.surfaceContainerHigh)
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val image = thumb
        if (image != null) {
            Image(image, contentDescription = attachment.displayName, contentScale = ContentScale.Crop, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(9.dp)))
        } else {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(9.dp)).background(colors.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(
                    painterResource(if (attachment.kind == AttachmentKind.IMAGE) R.drawable.ic_image else R.drawable.ic_file),
                    contentDescription = null,
                    tint = colors.onSurfaceVariant,
                )
            }
        }
        Column(Modifier.padding(horizontal = 8.dp).weight(1f, fill = false)) {
            Text(attachment.displayName, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${attachment.kind.name.lowercase().replaceFirstChar { it.uppercase() }} · ${AttachmentTypes.formatSize(attachment.sizeBytes)}",
                style = MaterialTheme.typography.labelSmall,
                color = colors.onSurfaceVariant,
            )
        }
        if (onRemove != null) {
            IconButton(onClick = { onRemove(attachment) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Remove ${attachment.displayName}", modifier = Modifier.size(16.dp))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmptyChat(firebaseConfigured: Boolean, offline: Boolean, onPrompt: (String) -> Unit, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Column(modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(colors.primary), contentAlignment = Alignment.Center) {
            Icon(painterResource(R.drawable.ic_globe), contentDescription = null, tint = colors.onPrimary)
        }
        Spacer(Modifier.size(16.dp))
        Text("What should we get done?", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.size(6.dp))
        Text(
            "Chat, talk, attach photos or documents, or ask me to look things up and fill in pages in the built-in browser. " +
                "I'll ask before anything that buys, deletes, sends or submits.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.onSurfaceVariant,
        )
        if (offline) {
            Spacer(Modifier.size(16.dp))
            Surface(color = colors.secondaryContainer, contentColor = colors.onSecondaryContainer, shape = RoundedCornerShape(12.dp)) {
                Text(
                    "Free mode can build and export responsive website templates without an AI model. " +
                        "Try make website for my business, /search Android tutorials, or /open https://example.com. " +
                        "For offline conversational AI, import a compatible .litertlm model in Settings. " +
                        "For cloud AI and automated browser planning, choose Gemini (free tier with limits) and configure Firebase.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp),
                )
            }
        } else if (!firebaseConfigured) {
            Spacer(Modifier.size(16.dp))
            Surface(color = colors.errorContainer, contentColor = colors.onErrorContainer, shape = RoundedCornerShape(12.dp)) {
                Text(
                    "Setup needed: this build has no Firebase configuration, so the assistant can't reply yet. " +
                        "Add google-services.json and rebuild (README → Firebase setup).",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp),
                )
            }
        }
        Spacer(Modifier.size(20.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
            (if (offline) OFFLINE_EXAMPLES else EXAMPLES).forEach { example ->
                SuggestionChip(onClick = { onPrompt(example) }, label = { Text(example) })
            }
        }
    }
}

private val OFFLINE_EXAMPLES = listOf(
    "make website for my business",
    "/search free Android tutorials",
    "/open https://example.com",
    "/read",
    "/help",
)

private val EXAMPLES = listOf(
    "What's the weather in Beirut tomorrow?",
    "Find the opening hours of the nearest pharmacy",
    "Summarize the attached PDF in 5 bullet points",
    "Compare prices for a 1TB SSD on two shops",
)

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(ClipboardManager::class.java) ?: return
    clipboard.setPrimaryClip(ClipData.newPlainText("TaskPilot reply", text))
}
