package com.taskpilot.assistant.policy

import java.util.Locale

/**
 * Facts about the element an action targets, collected by the app's own
 * inspection script right before the action runs. All strings come from the
 * web page and are therefore untrusted; they are only used for classification
 * and for display in the confirmation dialog.
 */
data class ElementInfo(
    val id: String,
    val tag: String,
    val type: String = "",
    val role: String = "",
    val label: String = "",
    val href: String? = null,
    val name: String = "",
    val autocomplete: String = "",
    val isSubmitControl: Boolean = false,
    val inForm: Boolean = false,
    val formMethod: String = "",
    val formAction: String = "",
    val isSearchContext: Boolean = false,
    val isContentEditable: Boolean = false,
    val disabled: Boolean = false,
) {
    val isLink: Boolean get() = tag == "a" && !href.isNullOrBlank() && !href.startsWith("javascript:", ignoreCase = true)
    val isButtonLike: Boolean
        get() = tag == "button" || role == "button" ||
            (tag == "input" && type in setOf("submit", "button", "image", "reset"))
}

/** Why an action needs the user's approval, ordered from most to least serious. */
enum class RiskKind(val title: String) {
    PURCHASE("Confirm a purchase or payment"),
    DELETE("Confirm deleting or cancelling"),
    SENSITIVE_INPUT("Confirm entering sensitive data"),
    SEND("Confirm sending information"),
    SUBMIT_FORM("Confirm submitting a form"),
    NAVIGATION_WITH_DATA("Confirm opening a link that carries data"),
    STRICT_MODE("Confirm browser action"),
}

data class ConfirmationRequest(
    val risk: RiskKind,
    val title: String,
    val summary: String,
    val site: String?,
    /** Label/value rows shown in the dialog. Values may come from the page. */
    val details: List<Pair<String, String>>,
)

sealed interface Decision {
    data object Allow : Decision
    data class Confirm(val request: ConfirmationRequest) : Decision
}

data class PolicyContext(
    val currentUrl: String?,
    val element: ElementInfo?,
    val confirmEveryAction: Boolean = false,
)

/**
 * Decides whether a validated [BrowserAction] may run immediately or must be
 * confirmed by the user. Conservative by design: when a click or entry looks like
 * it could buy, delete, send or submit something, the user decides.
 */
object ActionPolicy {

    fun evaluate(action: BrowserAction, ctx: PolicyContext): Decision {
        val site = UrlPolicy.hostOf(ctx.currentUrl)
        val risks = mutableListOf<RiskKind>()

        when (action) {
            is BrowserAction.ReadPage, is BrowserAction.Scroll -> return Decision.Allow
            is BrowserAction.OpenUrl -> {
                if (UrlPolicy.carriesData(action.url) && !UrlPolicy.isSameSite(site, action.host)) {
                    risks += RiskKind.NAVIGATION_WITH_DATA
                }
            }
            is BrowserAction.WebSearch, is BrowserAction.GoBack, is BrowserAction.SelectOption -> Unit
            is BrowserAction.Click -> risks += clickRisks(ctx.element, ctx.currentUrl)
            is BrowserAction.TypeText -> risks += typeRisks(action, ctx.element)
        }
        if (ctx.confirmEveryAction) risks += RiskKind.STRICT_MODE
        if (risks.isEmpty()) return Decision.Allow

        val risk = risks.minByOrNull { it.ordinal }!!
        return Decision.Confirm(buildRequest(risk, action, ctx.element, site))
    }

    // ---- classification ---------------------------------------------------

    internal fun clickRisks(element: ElementInfo?, currentUrl: String?): List<RiskKind> {
        if (element == null) return emptyList()
        val text = listOf(element.label, element.name).joinToString(" ")
        val risks = mutableListOf<RiskKind>()

        val keywordRisk = classifyLabel(text, includeSend = !element.isLink)
        if (keywordRisk != null) risks += keywordRisk

        // Links: also check where they go (e.g. ".../delete?id=1").
        if (element.isLink) {
            val hrefRisk = classifyLabel(element.href.orEmpty().replace(Regex("[/_\\-?=&.]"), " "), includeSend = false)
            if (hrefRisk == RiskKind.DELETE || hrefRisk == RiskKind.PURCHASE) risks += hrefRisk
        }

        // Any button on a checkout/payment page is treated as a payment step.
        if ((element.isButtonLike || element.isSubmitControl) && isPaymentPage(currentUrl)) {
            risks += RiskKind.PURCHASE
        }

        if (element.isSubmitControl && !element.isSearchContext) risks += RiskKind.SUBMIT_FORM
        return risks
    }

    internal fun typeRisks(action: BrowserAction.TypeText, element: ElementInfo?): List<RiskKind> {
        val risks = mutableListOf<RiskKind>()
        if (element != null) {
            if (isSensitiveField(element)) risks += RiskKind.SENSITIVE_INPUT
            else if (isPersonalField(element)) risks += RiskKind.SEND
        }
        if (action.submit) {
            val search = element?.isSearchContext == true
            when {
                search -> Unit
                element?.isContentEditable == true -> risks += RiskKind.SEND // Enter often sends a chat message
                else -> risks += RiskKind.SUBMIT_FORM
            }
        }
        return risks
    }

    /** Keyword classification of visible labels in English, French and Arabic. */
    fun classifyLabel(rawText: String, includeSend: Boolean = true): RiskKind? {
        val text = rawText.lowercase(Locale.ROOT).replace('’', '\'')
        if (text.isBlank()) return null
        if (PURCHASE_WORDS.containsMatchIn(text) || PURCHASE_AR.any { it in text }) return RiskKind.PURCHASE
        if (DELETE_WORDS.containsMatchIn(text) || DELETE_AR.any { it in text }) return RiskKind.DELETE
        if (includeSend && (SEND_WORDS.containsMatchIn(text) || SEND_AR.any { it in text })) return RiskKind.SEND
        return null
    }

    fun isSensitiveField(e: ElementInfo): Boolean {
        if (e.type.equals("password", ignoreCase = true)) return true
        val ac = e.autocomplete.lowercase(Locale.ROOT)
        if (ac.startsWith("cc-") || ac.contains(" cc-") || "password" in ac || "one-time-code" in ac) return true
        val text = (e.name + " " + e.label).lowercase(Locale.ROOT)
        return SENSITIVE_WORDS.containsMatchIn(text) || SENSITIVE_AR.any { it in text }
    }

    fun isPersonalField(e: ElementInfo): Boolean {
        if (e.type.lowercase(Locale.ROOT) in setOf("email", "tel")) return true
        val ac = e.autocomplete.lowercase(Locale.ROOT)
        return PERSONAL_AUTOCOMPLETE.any { ac == it || ac.endsWith(" $it") }
    }

    private fun isPaymentPage(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val path = url.lowercase(Locale.ROOT).substringAfter("://").substringAfter('/', "")
        return PAYMENT_PATH.containsMatchIn("/$path")
    }

    private val PURCHASE_WORDS = Regex(
        "\\b(buy|purchase|pay|payment|checkout|check out|place (your |my )?order|order now|" +
            "complete (your |my )?(order|purchase|payment)|confirm (and pay|order|purchase|payment)|" +
            "donate|book now|reserve|add (a )?(card|payment method)|" +
            "acheter|payer|paiement|commander|passer (la |ma )?commande|valider (la |ma )?commande|r[ée]server)\\b"
    )
    private val DELETE_WORDS = Regex(
        "\\b(delete|remove|erase|discard|trash|unsubscribe|deactivate|" +
            "close (my |your )?account|cancel (my |your |the )?(order|subscription|membership|account|booking|reservation|plan)|" +
            "empty (the )?(trash|bin)|clear (all|history|data)|" +
            "supprimer|effacer|r[ée]silier|se d[ée]sabonner|d[ée]sinscri\\w*)\\b"
    )
    private val SEND_WORDS = Regex(
        "\\b(send|submit|post|publish|reply|comment|share|tweet|retweet|repost|upload|" +
            "apply now|submit application|transfer|sign ?up|register|log ?in|sign ?in|subscribe|follow|invite|" +
            "confirm|continue with|envoyer|soumettre|publier|r[ée]pondre|partager|s'inscrire|" +
            "se connecter|connexion|confirmer|valider)\\b"
    )
    private val SENSITIVE_WORDS = Regex(
        "(password|passcode|passwd|\\bpin\\b|cvv|cvc|card ?number|cardnumber|cc-?num|iban|\\bssn\\b|" +
            "security code|mot de passe|code secret)"
    )
    private val PAYMENT_PATH = Regex("/(checkout|payment|payments|billing|pay)(/|\\?|$|-|_)")
    private val PERSONAL_AUTOCOMPLETE = listOf(
        "email", "tel", "name", "given-name", "family-name", "street-address",
        "address-line1", "address-line2", "postal-code", "bday",
    )

    // Arabic labels are matched as substrings (no reliable word boundaries).
    private val PURCHASE_AR = listOf("شراء", "اشتر", "ادفع", "الدفع", "دفع", "اطلب الآن", "إتمام الطلب", "اتمام الطلب", "احجز")
    private val DELETE_AR = listOf("حذف", "إزالة", "ازالة", "امسح", "إلغاء الاشتراك", "الغاء الاشتراك")
    private val SEND_AR = listOf("إرسال", "ارسال", "أرسل", "ارسل", "انشر", "نشر", "تأكيد", "تاكيد", "اشترك", "تسجيل الدخول", "سجل الدخول", "مشاركة")
    private val SENSITIVE_AR = listOf("كلمة السر", "كلمة المرور", "رمز التحقق")

    // ---- presentation -----------------------------------------------------

    private fun buildRequest(
        risk: RiskKind,
        action: BrowserAction,
        element: ElementInfo?,
        site: String?,
    ): ConfirmationRequest {
        val details = mutableListOf<Pair<String, String>>()
        site?.let { details += "Website" to it }
        val label = element?.label?.let(::shorten)?.takeIf { it.isNotBlank() }

        val summary = when (action) {
            is BrowserAction.OpenUrl -> {
                details += "Opens" to action.host
                details += "Full address" to shorten(action.url, 160)
                "The assistant wants to open a page on ${action.host}. The address contains data that will be sent to that site."
            }
            is BrowserAction.WebSearch -> {
                details += "Search" to shorten(action.query)
                "The assistant wants to run a web search."
            }
            is BrowserAction.Click -> {
                label?.let { details += "Button or link" to "“$it”" }
                element?.href?.takeIf { element.isLink }?.let { details += "Goes to" to shorten(it, 120) }
                when (risk) {
                    RiskKind.PURCHASE -> "This click may complete a purchase or payment."
                    RiskKind.DELETE -> "This click may delete, remove or cancel something."
                    RiskKind.SEND -> "This click may send or publish information."
                    RiskKind.SUBMIT_FORM -> "This click submits a form on the page."
                    else -> "The assistant wants to click an element on the page."
                }
            }
            is BrowserAction.TypeText -> {
                label?.let { details += "Field" to "“$it”" }
                val masked = element?.let(::isSensitiveField) == true
                details += "Text" to if (masked) maskText(action.text) else shorten(action.text, 200)
                if (action.submit) details += "Then" to "Press Enter / submit"
                when (risk) {
                    RiskKind.SENSITIVE_INPUT -> "The assistant wants to enter sensitive data (such as a password or card details)."
                    RiskKind.SEND -> "The assistant wants to enter personal information or send a message."
                    RiskKind.SUBMIT_FORM -> "The assistant wants to type into a form and submit it."
                    else -> "The assistant wants to type into the page."
                }
            }
            is BrowserAction.SelectOption -> {
                label?.let { details += "List" to "“$it”" }
                details += "Option" to shorten(action.option)
                "The assistant wants to choose an option on the page."
            }
            is BrowserAction.GoBack -> "The assistant wants to go back to the previous page."
            is BrowserAction.ReadPage, is BrowserAction.Scroll -> "The assistant wants to read the page."
        }
        return ConfirmationRequest(risk = risk, title = risk.title, summary = summary, site = site, details = details)
    }

    fun maskText(text: String): String = "•".repeat(minOf(text.length, 8)) + " (${text.length} characters)"

    private fun shorten(value: String, max: Int = 80): String {
        val oneLine = value.replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1) + "…"
    }
}
