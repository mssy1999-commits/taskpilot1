package com.taskpilot.assistant.ai

import android.content.Context
import android.net.Uri
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/** Local, verifiable artifact storage and Android Storage Access Framework export. */
class WebsiteFiles(private val context: Context) {
    private val directory: File get() = File(context.filesDir, "websites")
    private val prefs get() = context.getSharedPreferences("website_export", Context.MODE_PRIVATE)

    fun create(site: WebsiteBuilder.Site): File {
        check(directory.exists() || directory.mkdirs()) { "Could not create website folder" }
        val file = File(directory, site.fileName)
        // Do not overwrite an existing file before the new artifact is completely written.
        val temp = File.createTempFile("site-", ".tmp", directory)
        try {
            temp.writeText(site.html, Charsets.UTF_8)
            check(temp.readText(Charsets.UTF_8) == site.html) { "Website write verification failed" }
            check(temp.renameTo(file) || run { temp.copyTo(file, overwrite = true); temp.delete(); true }) { "Website save failed" }
            check(file.isFile && file.readText(Charsets.UTF_8) == site.html) { "Website file verification failed" }
            prefs.edit().putString("latest", file.name).apply()
            return file
        } finally { temp.delete() }
    }

    fun latest(): File? {
        val name = prefs.getString("latest", null) ?: return null
        if (!Regex("[a-z0-9-]{1,45}\\.html").matches(name)) return null
        return File(directory, name).takeIf { it.isFile && it.length() > 100L }
    }

    /** Called only after user selects a destination in the system Save As dialog. */
    fun export(uri: Uri): Long {
        val source = latest() ?: error("No local website to export")
        val bytes = source.readBytes()
        check(bytes.size > 100 && bytes.toString(StandardCharsets.UTF_8).contains("<!DOCTYPE html>")) { "Invalid website file" }
        context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes); it.flush() }
            ?: error("Android couldn't open the chosen export location")
        val verify = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Android couldn't verify the exported document")
        check(MessageDigest.isEqual(MessageDigest.getInstance("SHA-256").digest(bytes), MessageDigest.getInstance("SHA-256").digest(verify))) {
            "Exported website doesn't match the saved original"
        }
        return verify.size.toLong()
    }
}
