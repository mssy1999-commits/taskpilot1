package com.taskpilot.assistant.ai

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull

/** Converts model-supplied JSON arguments into plain values for ToolCallParser. */
object ToolArgs {
    fun toPlain(args: Map<String, JsonElement>): Map<String, Any?> = args.mapValues { (_, value) ->
        when (value) {
            is JsonNull -> null
            is JsonPrimitive -> when {
                value.isString -> value.content
                value.booleanOrNull != null -> value.booleanOrNull
                value.longOrNull != null -> value.longOrNull
                value.doubleOrNull != null -> value.doubleOrNull
                else -> value.content
            }
            // Objects/arrays are never valid for our tools; pass a marker the parser rejects.
            else -> InvalidStructuredValue
        }
    }

    /** Placeholder for structured JSON values (not a String, Number or Boolean). */
    object InvalidStructuredValue {
        override fun toString(): String = "<structured value>"
    }
}
