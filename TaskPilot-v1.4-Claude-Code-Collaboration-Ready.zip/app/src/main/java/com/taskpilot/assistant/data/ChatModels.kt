package com.taskpilot.assistant.data

import kotlinx.serialization.Serializable

@Serializable
enum class Role { USER, ASSISTANT, NOTE }

/** A file the user attached. The bytes live in app-private storage ([fileName]). */
@Serializable
data class Attachment(
    val id: String,
    val displayName: String,
    val kind: AttachmentKind,
    /** MIME type sent to the model (images are re-encoded as JPEG). */
    val mimeType: String,
    val sizeBytes: Long,
    /** File name inside the app's private attachments directory. */
    val fileName: String,
)

@Serializable
enum class StepStatus { RUNNING, AWAITING_CONFIRMATION, DONE, FAILED, DENIED }

/** One browser step shown in the chat's activity log. */
@Serializable
data class ToolStep(
    val id: Int,
    val label: String,
    val status: StepStatus,
    val detail: String? = null,
)

@Serializable
data class ChatMessage(
    val id: String,
    val role: Role,
    val text: String,
    val attachments: List<Attachment> = emptyList(),
    val steps: List<ToolStep> = emptyList(),
    val isError: Boolean = false,
    val createdAt: Long,
)

@Serializable
data class StoredConversation(
    val version: Int = 1,
    val messages: List<ChatMessage> = emptyList(),
)
