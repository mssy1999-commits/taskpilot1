package com.taskpilot.assistant.ai

import com.google.firebase.ai.type.APINotConfiguredException
import com.google.firebase.ai.type.ContentBlockedException
import com.google.firebase.ai.type.InvalidAPIKeyException
import com.google.firebase.ai.type.PromptBlockedException
import com.google.firebase.ai.type.QuotaExceededException
import com.google.firebase.ai.type.RequestTimeoutException
import com.google.firebase.ai.type.ResponseStoppedException
import com.google.firebase.ai.type.ServerException
import com.google.firebase.ai.type.ServiceDisabledException
import com.google.firebase.ai.type.UnsupportedUserLocationException
import java.io.IOException

/** Turns SDK/network failures into short, actionable messages for the chat. */
object AgentErrors {

    fun userMessage(e: Throwable, modelName: String): String = when (e) {
        is FirebaseNotConfiguredException ->
            "Firebase isn't set up in this build, so the assistant can't reply yet. Add app/google-services.json " +
                "(or the GOOGLE_SERVICES_JSON secret for cloud builds) and rebuild. See README → Firebase setup."
        is ServiceDisabledException, is APINotConfiguredException ->
            "Firebase AI Logic isn't enabled for this Firebase project. In the Firebase console open AI Logic → " +
                "Get started and choose the Gemini Developer API."
        is QuotaExceededException ->
            "Gemini's usage limit for this project was reached, even after waiting and retrying. Try again in a few " +
                "minutes; if it keeps happening, check quotas in the Firebase console (AI Logic → Usage)."
        is InvalidAPIKeyException ->
            "Firebase rejected the app's API key. Download a fresh google-services.json for this app and rebuild."
        is PromptBlockedException -> "Gemini's safety filters blocked that request."
        is ContentBlockedException -> "Gemini's safety filters blocked the reply."
        is ResponseStoppedException -> "The reply stopped early. Please try again."
        is UnsupportedUserLocationException -> "Gemini isn't available in your region."
        is RequestTimeoutException -> "The request timed out, even after retrying. Your connection may be slow; try again."
        is ServerException -> serverMessage(e.message.orEmpty(), modelName)
        is AgentException -> e.message ?: "The assistant couldn't finish."
        is GrokNotConfiguredException ->
            "Grok isn't set up yet: the app needs the address of your Grok proxy (Cloudflare Worker). Set the " +
                "Remote Config parameter \"${ModelConfig.REMOTE_GROK_URL}\" (see README → Grok), or switch back to " +
                "Gemini in Settings."
        is GrokHttpException -> grokMessage(e, modelName)
        else -> if (e.hasCause<IOException>()) {
            "Couldn't reach Gemini, even after retrying. Your connection may be weak or offline. " +
                "Send \"continue\" to pick up where I stopped."
        } else {
            "Something went wrong: ${e.message?.take(200) ?: e.javaClass.simpleName}"
        }
    }

    /**
     * True for failures worth retrying automatically: model overload (503 "high demand"),
     * short-term rate limits, timeouts and dropped connections. Model calls are safe to
     * repeat; browser actions are never retried.
     */
    fun isTransient(e: Throwable): Boolean = when (e) {
        is FirebaseNotConfiguredException, is AgentException, is PromptBlockedException,
        is ContentBlockedException, is InvalidAPIKeyException, is ServiceDisabledException,
        is APINotConfiguredException, is UnsupportedUserLocationException -> false
        is RequestTimeoutException, is QuotaExceededException -> true
        is GrokNotConfiguredException -> false
        is GrokHttpException -> e.statusCode in TRANSIENT_HTTP
        is ServerException -> TRANSIENT_SERVER.containsMatchIn(e.message.orEmpty().lowercase())
        else -> e.hasCause<IOException>()
    }

    private val TRANSIENT_SERVER = Regex(
        "high demand|overloaded|unavailable|try again later|resource_exhausted|deadline|internal error|\\b(429|500|502|503|504)\\b"
    )

    private val TRANSIENT_HTTP = setOf(408, 429, 500, 502, 503, 504)

    private fun grokMessage(e: GrokHttpException, modelName: String): String {
        val detail = e.message.orEmpty().take(200)
        val m = (detail + " " + e.errorCode.orEmpty()).lowercase()
        return when {
            e.errorCode == "app_check" ->
                "Your Grok proxy rejected the app (App Check). Register the debug token from Settings → App Check " +
                    "in the Firebase console (App Check → Manage debug tokens), then try again."
            e.errorCode == "proxy_not_configured" ->
                "Your Grok proxy is missing a setting (${detail}). Check the Worker's variables and secrets (README → Grok)."
            "credit" in m || "balance" in m || "billing" in m || "spending limit" in m || e.statusCode == 402 ->
                "Your xAI account has no API credits left (or hit its spending limit). Add credits at console.x.ai, " +
                    "or switch to Gemini (free) in Settings."
            e.statusCode == 401 || e.statusCode == 403 ->
                "xAI rejected the API key stored in your proxy. Create a new key at console.x.ai and update the " +
                    "Worker secret XAI_API_KEY."
            e.statusCode == 404 || "model" in m && ("not found" in m || "does not exist" in m) ->
                "The Grok model \"$modelName\" isn't available. Set Remote Config \"${ModelConfig.REMOTE_GROK_MODEL}\" " +
                    "to a current model from docs.x.ai."
            e.statusCode in TRANSIENT_HTTP ->
                "Grok is busy or unreachable right now, even after several retries. Try again in a minute, or send \"continue\"."
            else -> "Grok error ${e.statusCode}: $detail"
        }
    }

    private fun serverMessage(raw: String, modelName: String): String {
        val m = raw.lowercase()
        return when {
            "high demand" in m || "overloaded" in m || "unavailable" in m || "503" in m ->
                "Gemini is overloaded right now (high demand) and still was after several retries. Please try again " +
                    "in a minute, or send \"continue\". If this happens often, set the Remote Config parameter " +
                    "\"${ModelConfig.REMOTE_KEY}\" to gemini-3.5-flash-lite."
            "app check" in m || "appcheck" in m || "permission_denied" in m || "403" in m || "401" in m ->
                "Firebase refused the request (App Check). On a debug build, open Settings → App Check, copy the " +
                    "debug token and add it in Firebase console → App Check → Apps → Manage debug tokens."
            "not found" in m || "404" in m || "is not supported" in m ->
                "The model \"$modelName\" isn't available. Set the Remote Config parameter \"${ModelConfig.REMOTE_KEY}\" " +
                    "to a supported Gemini Flash model (see README)."
            else -> "Gemini server error: ${raw.take(200)}"
        }
    }

    private inline fun <reified T : Throwable> Throwable.hasCause(): Boolean {
        var current: Throwable? = this
        var depth = 0
        while (current != null && depth < 8) {
            if (current is T) return true
            current = current.cause
            depth++
        }
        return false
    }
}
