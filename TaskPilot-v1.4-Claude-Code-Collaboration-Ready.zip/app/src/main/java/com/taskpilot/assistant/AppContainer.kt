package com.taskpilot.assistant

import android.content.Context
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.data.ConversationStore
import com.taskpilot.assistant.data.SettingsStore

/** Minimal manual dependency container (app-scoped singletons). */
class AppContainer(context: Context) {
    val settingsStore = SettingsStore(context)
    val conversationStore = ConversationStore(context)
    val attachmentRepository = AttachmentRepository(context, conversationStore)
}
