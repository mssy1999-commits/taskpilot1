package com.taskpilot.assistant.ai

import android.content.Context
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Initializes Firebase and App Check. The app never contains a Gemini API key:
 * requests go through Firebase AI Logic, which holds the key server-side and
 * (once enforcement is on) only accepts requests carrying a valid App Check token.
 */
object FirebaseSetup {
    private const val TAG = "FirebaseSetup"

    /** True when google-services.json was present at build time and Firebase started. */
    @Volatile
    var isConfigured: Boolean = false
        private set

    fun initialize(context: Context) {
        val app = try {
            if (FirebaseApp.getApps(context).isEmpty()) FirebaseApp.initializeApp(context) else FirebaseApp.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase is not configured", e)
            null
        }
        if (app == null) {
            isConfigured = false
            return
        }
        isConfigured = true
        try {
            val appCheck = FirebaseAppCheck.getInstance()
            // Debug builds: debug provider (register its token in the console).
            // Release builds: Play Integrity. See src/debug and src/release.
            appCheck.installAppCheckProviderFactory(AppCheckProviders.factory())
            // Fetch once at startup so the debug provider creates its debug token now.
            appCheck.getAppCheckToken(false).addOnFailureListener { e ->
                Log.w(TAG, "App Check token request failed: ${e.message}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "App Check setup failed", e)
        }
    }
}

/** Awaits a Play Services [Task] without the extra coroutines-play-services dependency. */
suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnCompleteListener { task ->
        if (!cont.isActive) return@addOnCompleteListener
        val error = task.exception
        if (task.isSuccessful) {
            @Suppress("UNCHECKED_CAST")
            cont.resume(task.result as T)
        } else {
            cont.resumeWithException(error ?: IllegalStateException("Task failed"))
        }
    }
}
