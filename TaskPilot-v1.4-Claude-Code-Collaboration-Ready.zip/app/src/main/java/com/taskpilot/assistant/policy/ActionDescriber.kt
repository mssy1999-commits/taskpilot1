package com.taskpilot.assistant.policy

/** Short, user-facing descriptions of browser steps for the chat's activity log. */
object ActionDescriber {

    fun describe(action: BrowserAction, element: ElementInfo? = null): String {
        val label = element?.label?.let { shorten(it, 40) }?.takeIf { it.isNotBlank() }
        return when (action) {
            is BrowserAction.OpenUrl -> "Opening ${action.host}"
            is BrowserAction.WebSearch -> "Searching for “${shorten(action.query, 50)}”"
            is BrowserAction.ReadPage -> "Reading the page"
            is BrowserAction.Click -> if (label != null) "Clicking “$label”" else "Clicking an element"
            is BrowserAction.TypeText -> {
                val target = if (label != null) "“$label”" else "a field"
                if (action.submit) "Typing into $target and submitting" else "Typing into $target"
            }
            is BrowserAction.SelectOption -> "Choosing “${shorten(action.option, 40)}”"
            is BrowserAction.Scroll -> "Scrolling ${action.direction.wire}"
            is BrowserAction.GoBack -> "Going back"
        }
    }

    private fun shorten(value: String, max: Int): String {
        val oneLine = value.replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1) + "…"
    }
}
