package com.taskpilot.assistant.ai

/** Validation for model IDs that arrive from Remote Config or build settings. */
object ModelNames {
    private val GEMINI_MODEL = Regex("^gemini-[a-z0-9][a-z0-9.\\-]{0,62}$")

    fun isValid(name: String?): Boolean = name != null && GEMINI_MODEL.matches(name)

    /** Gemini 2.x models use a thinking *budget*; Gemini 3+ use thinking *levels*. */
    fun usesThinkingBudget(name: String): Boolean = name.startsWith("gemini-2.")
}
