package com.taskpilot.assistant.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.taskpilot.assistant.R
import com.taskpilot.assistant.data.Attachment
import com.taskpilot.assistant.data.AttachmentRepository
import com.taskpilot.assistant.speech.VoiceState

@Composable
fun InputBar(
    draft: String,
    onDraftChange: (String) -> Unit,
    pendingAttachments: List<Attachment>,
    importingCount: Int,
    repository: AttachmentRepository,
    voiceState: VoiceState,
    isRunning: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onMic: () -> Unit,
    onPickPhotos: () -> Unit,
    onPickFiles: () -> Unit,
    onRemoveAttachment: (Attachment) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    val listening = voiceState as? VoiceState.Listening
    Surface(color = colors.surface, tonalElevation = 3.dp, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            if (pendingAttachments.isNotEmpty() || importingCount > 0) {
                Row(Modifier.padding(start = 4.dp, end = 4.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AttachmentStrip(pendingAttachments, repository, onRemove = onRemoveAttachment)
                    if (importingCount > 0) {
                        Spacer(Modifier.width(8.dp))
                        CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                AttachMenuButton(enabled = !isRunning, onPickPhotos = onPickPhotos, onPickFiles = onPickFiles)

                Box(Modifier.weight(1f)) {
                    if (listening != null) {
                        ListeningField(listening)
                    } else {
                        TextField(
                            value = draft,
                            onValueChange = onDraftChange,
                            placeholder = { Text("Message TaskPilot") },
                            maxLines = 6,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                            shape = RoundedCornerShape(24.dp),
                            colors = TextFieldDefaults.colors(
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent,
                                focusedContainerColor = colors.surfaceContainerHigh,
                                unfocusedContainerColor = colors.surfaceContainerHigh,
                            ),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        )
                    }
                }

                Spacer(Modifier.width(6.dp))
                val canSend = draft.isNotBlank() || pendingAttachments.isNotEmpty()
                when {
                    isRunning -> FilledIconButton(
                        onClick = onStop,
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = colors.error, contentColor = colors.onError),
                        modifier = Modifier.size(48.dp),
                    ) { Icon(painterResource(R.drawable.ic_stop), contentDescription = "Stop") }
                    canSend && listening == null -> FilledIconButton(onClick = onSend, modifier = Modifier.size(48.dp)) {
                        Icon(painterResource(R.drawable.ic_send), contentDescription = "Send")
                    }
                    else -> MicButton(listening = listening, onClick = onMic)
                }
            }
        }
    }
}

@Composable
private fun MicButton(listening: VoiceState.Listening?, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val pulse by animateFloatAsState(targetValue = 1f + (listening?.level ?: 0f) * 0.25f, label = "mic-level")
    FilledIconButton(
        onClick = onClick,
        colors = if (listening != null) {
            IconButtonDefaults.filledIconButtonColors(containerColor = colors.secondary, contentColor = colors.onSecondary)
        } else {
            IconButtonDefaults.filledIconButtonColors()
        },
        modifier = Modifier.size(48.dp).scale(if (listening != null) pulse else 1f),
    ) {
        Icon(
            painterResource(if (listening != null) R.drawable.ic_stop else R.drawable.ic_mic),
            contentDescription = if (listening != null) "Stop listening" else "Speak",
        )
    }
}

@Composable
private fun ListeningField(state: VoiceState.Listening) {
    val colors = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(colors.secondaryContainer)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(colors.secondary))
        Spacer(Modifier.width(10.dp))
        Text(
            state.partial.ifBlank { "Listening…" },
            style = MaterialTheme.typography.bodyLarge,
            color = colors.onSecondaryContainer,
        )
    }
}

@Composable
private fun AttachMenuButton(enabled: Boolean, onPickPhotos: () -> Unit, onPickFiles: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }, enabled = enabled, modifier = Modifier.size(48.dp)) {
            Icon(painterResource(R.drawable.ic_attach), contentDescription = "Attach")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Photos") },
                leadingIcon = { Icon(painterResource(R.drawable.ic_image), contentDescription = null) },
                onClick = {
                    open = false
                    onPickPhotos()
                },
            )
            DropdownMenuItem(
                text = { Text("Files (PDF, text…)") },
                leadingIcon = { Icon(painterResource(R.drawable.ic_file), contentDescription = null) },
                onClick = {
                    open = false
                    onPickFiles()
                },
            )
        }
    }
}
