package com.taskpilot.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.taskpilot.assistant.ui.ChatScreen
import com.taskpilot.assistant.ui.ChatViewModel
import com.taskpilot.assistant.ui.SettingsScreen
import com.taskpilot.assistant.ui.theme.TaskPilotTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TaskPilotTheme {
                val vm: ChatViewModel = viewModel()
                var showSettings by rememberSaveable { mutableStateOf(false) }
                Box(Modifier.fillMaxSize()) {
                    // The chat (and its WebView) stays composed under Settings so the
                    // browser session is never torn down by navigation.
                    ChatScreen(vm = vm, onOpenSettings = { showSettings = true })
                    if (showSettings) {
                        BackHandler { showSettings = false }
                        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                            SettingsScreen(vm = vm, onClose = { showSettings = false })
                        }
                    }
                }
            }
        }
    }
}
