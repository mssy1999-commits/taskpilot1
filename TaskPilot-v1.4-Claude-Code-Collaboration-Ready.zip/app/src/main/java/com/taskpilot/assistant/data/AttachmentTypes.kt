package com.taskpilot.assistant.data

import java.util.Locale

/** Enums are serializable by kotlinx.serialization without an annotation. */
enum class AttachmentKind { IMAGE, PDF, TEXT }

/**
 * Supported attachment types and limits. Kept free of Android types for unit tests.
 *
 * - Images (JPEG, PNG, WebP, HEIC/HEIF, GIF first frame, BMP) are decoded on the
 *   device, downscaled to at most [MAX_IMAGE_DIMENSION] px and re-encoded as JPEG.
 * - PDF documents up to [MAX_PDF_BYTES] are sent as-is.
 * - Plain-text formats (TXT, Markdown, CSV/TSV, JSON, XML, HTML, logs and other
 *   text/... types) up to [MAX_TEXT_BYTES] are sent as text.
 */
object AttachmentTypes {
    const val MAX_ATTACHMENTS_PER_MESSAGE = 5
    const val MAX_IMAGE_SOURCE_BYTES = 40L * 1024 * 1024
    const val MAX_IMAGE_DIMENSION = 1536
    const val MAX_PDF_BYTES = 15L * 1024 * 1024
    const val MAX_TEXT_BYTES = 512L * 1024
    /** Firebase AI Logic limits a request with inline data to 20 MB. */
    const val MAX_INLINE_BYTES_PER_MESSAGE = 18L * 1024 * 1024

    private val IMAGE_MIME = setOf(
        "image/jpeg", "image/jpg", "image/pjpeg", "image/png", "image/webp",
        "image/heic", "image/heif", "image/gif", "image/bmp", "image/x-ms-bmp",
    )
    private val TEXT_MIME = setOf(
        "application/json", "application/xml", "application/x-yaml", "application/yaml",
        "application/csv", "application/x-csv",
    )
    private val UNSUPPORTED_TEXT_MIME = setOf("text/rtf", "text/vcard", "text/x-vcard", "text/calendar")
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "bmp")
    private val TEXT_EXT = setOf("txt", "md", "markdown", "csv", "tsv", "json", "xml", "html", "htm", "log", "yaml", "yml")
    private val GENERIC_MIME = setOf("application/octet-stream", "binary/octet-stream", "*/*", "")

    /** MIME filter for the system document picker (validated again after picking). */
    val PICKER_MIME_TYPES: Array<String> = arrayOf(
        "application/pdf", "text/*", "application/json", "application/xml", "image/*",
        "application/octet-stream",
    )

    /** Human-readable list for the UI and error messages. */
    const val SUPPORTED_SUMMARY =
        "Images (JPEG, PNG, WebP, HEIC, GIF, BMP), PDF (up to 15 MB) and text files " +
            "(TXT, MD, CSV, TSV, JSON, XML, HTML, LOG, YAML; up to 512 KB)."

    fun classify(mimeType: String?, fileName: String?): AttachmentKind? {
        val mime = mimeType?.lowercase(Locale.ROOT)?.substringBefore(';')?.trim().orEmpty()
        val ext = fileName?.substringAfterLast('.', "")?.lowercase(Locale.ROOT).orEmpty()

        if (mime.isNotEmpty() && mime !in GENERIC_MIME) {
            return when {
                mime in IMAGE_MIME -> AttachmentKind.IMAGE
                mime == "application/pdf" -> AttachmentKind.PDF
                mime in UNSUPPORTED_TEXT_MIME -> null
                mime.startsWith("text/") || mime in TEXT_MIME -> AttachmentKind.TEXT
                else -> null
            }
        }
        return when (ext) {
            in IMAGE_EXT -> AttachmentKind.IMAGE
            "pdf" -> AttachmentKind.PDF
            in TEXT_EXT -> AttachmentKind.TEXT
            else -> null
        }
    }

    fun maxSourceBytes(kind: AttachmentKind): Long = when (kind) {
        AttachmentKind.IMAGE -> MAX_IMAGE_SOURCE_BYTES
        AttachmentKind.PDF -> MAX_PDF_BYTES
        AttachmentKind.TEXT -> MAX_TEXT_BYTES
    }

    /** MIME type actually sent to Gemini for each kind. */
    fun storedMimeType(kind: AttachmentKind): String = when (kind) {
        AttachmentKind.IMAGE -> "image/jpeg"
        AttachmentKind.PDF -> "application/pdf"
        AttachmentKind.TEXT -> "text/plain"
    }

    fun formatSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024 -> String.format(Locale.ROOT, "%d KB", bytes / 1024)
        else -> "$bytes B"
    }
}
