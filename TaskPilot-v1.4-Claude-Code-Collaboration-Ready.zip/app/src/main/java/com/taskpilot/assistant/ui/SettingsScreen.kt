@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.taskpilot.assistant.ui

import android.content.ClipData
import android.content.ClipboardManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.taskpilot.assistant.BuildConfig
import com.taskpilot.assistant.ai.AiProvider
import com.taskpilot.assistant.ai.AppCheckProviders
import com.taskpilot.assistant.ai.FirebaseSetup
import com.taskpilot.assistant.ai.ModelConfig
import com.taskpilot.assistant.data.AttachmentTypes
import com.taskpilot.assistant.policy.UrlPolicy

private enum class PendingClear { CONVERSATION, BROWSER, ALL }

private val VOICE_LANGUAGES = listOf(
    "" to "Device default",
    "en-US" to "English",
    "ar-LB" to "Arabic (Lebanon)",
    "fr-FR" to "French",
)

@Composable
fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val localModelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importOfflineModel(uri)
    }
    var pendingClear by remember { mutableStateOf<PendingClear?>(null) }
    var storageBytes by remember { mutableLongStateOf(0L) }
    var debugToken by remember { mutableStateOf<String?>(null) }
    var refreshKey by remember { mutableStateOf(0) }

    LaunchedEffect(ui.messages.size, refreshKey) {
        storageBytes = vm.storageBytes()
        debugToken = vm.appCheckDebugToken()
    }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.events.collect { snackbar.showSnackbar(it) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Settings & privacy") },
                navigationIcon = {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp),
        ) {
            Section("AI provider")
            ChoiceRow(
                "Who answers",
                listOf(
                    AiProvider.LOCAL.name to "Offline (no quota)",
                    AiProvider.GEMINI.name to "Gemini (free tier, limited)",
                    AiProvider.GROK.name to "Grok (xAI, paid)",
                ),
                settings.aiProvider.name,
            ) { name -> vm.updateSettings { s -> s.copy(aiProvider = AiProvider.valueOf(name)) } }
            Body(
                if (settings.aiProvider == AiProvider.LOCAL) {
                    "Free mode: browser commands (/open, /search, /read, /scroll, /click, /type, /back) work " +
                        "without a backend, API key or AI model, using the same confirmation policy. " +
                        "Open-ended text chat requires an imported .litertlm model. " +
                        "Offline AI cannot analyze images/PDFs or plan complex browser tasks automatically."
                } else if (settings.aiProvider == AiProvider.GROK) {
                    "Grok runs through your own proxy (a free Cloudflare Worker that keeps your xAI key secret) and is " +
                        "billed by xAI per use. PDFs are sent as images of their first ${com.taskpilot.assistant.data.PdfPages.MAX_PAGES} pages. " +
                        "Set it up with README → Grok. The conversation continues; earlier attachments aren't re-sent."
                } else {
                    "Gemini 3.5 Flash-Lite runs through Firebase AI Logic without an API key in the APK. Free tier is limited; access depends on region and quota."
                }
            )

            Section("Offline AI (unlimited local requests)")
            Body(
                "Uses Google's open-source LiteRT-LM runtime; model runs entirely on the device. " +
                    "Download a CPU-compatible .litertlm model (e.g., a small Qwen3 0.6B model from the LiteRT Community), " +
                    "then import it below. A model can use hundreds of MB of storage and several GB of RAM. " +
                    "There are no vendor API quotas, but phone speed, battery and memory are limited."
            )
            InfoRow("Offline model", vm.offlineModelStatus())
            OutlinedButton(
                onClick = { localModelPicker.launch(arrayOf("*/*")) },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            ) { Text("Import .litertlm model") }

            Section("Voice")
            SwitchRow("Speak replies", "Read every reply aloud. Replies to voice messages are always spoken.", settings.speakReplies) { on ->
                vm.updateSettings { it.copy(speakReplies = on) }
            }
            SwitchRow("Send after voice input", "Send automatically when you stop speaking.", settings.autoSendVoice) { on ->
                vm.updateSettings { it.copy(autoSendVoice = on) }
            }
            ChoiceRow("Voice input language", VOICE_LANGUAGES, settings.voiceLanguage) { tag ->
                vm.updateSettings { it.copy(voiceLanguage = tag) }
            }

            Section("Browser & safety")
            Body(
                "The assistant can only open http(s) pages and use these actions inside the app's own browser: open, search, " +
                    "read, click, type, choose an option, scroll and go back. It never runs its own JavaScript and cannot " +
                    "control other apps. It always asks before purchases, deleting, sending messages, signing in, " +
                    "submitting forms, entering passwords or personal details, and before opening links that carry data to another site."
            )
            SwitchRow(
                "Fast browsing",
                "Don't load images in the in-app browser. Pages open much faster on mobile data.",
                settings.fastBrowsing,
            ) { on -> vm.updateSettings { it.copy(fastBrowsing = on) } }
            SwitchRow("Ask before every browser action", "Also confirm ordinary clicks, typing and navigation.", settings.confirmEveryAction) { on ->
                vm.updateSettings { it.copy(confirmEveryAction = on) }
            }
            ChoiceRow(
                "Search engine",
                UrlPolicy.SearchEngine.entries.map { it.name to it.label },
                settings.searchEngine.name,
            ) { name ->
                vm.updateSettings { s -> s.copy(searchEngine = UrlPolicy.SearchEngine.valueOf(name)) }
            }

            Section("Privacy & data")
            Body(
                "Stored only on this phone (never backed up): your conversation and copies of attached files " +
                    "(${AttachmentTypes.formatSize(storageBytes)} now), the browser's cookies, cache and history, and these settings.\n\n" +
                    "When Offline AI is selected, your text stays on this phone. With Gemini or Grok, messages and supported " +
                    "attachments/page text are sent to the chosen cloud provider. Voice input may use your device's " +
                    "speech service and may require the internet. The app has no Gemini API key inside it and no analytics."
            )
            SwitchRow("Keep conversation history", "Off: the chat is forgotten when the app closes.", settings.saveHistory) { on ->
                vm.updateSettings { it.copy(saveHistory = on) }
            }
            FlowRow(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(onClick = { pendingClear = PendingClear.CONVERSATION }) { Text("Clear conversation") }
                OutlinedButton(onClick = { pendingClear = PendingClear.BROWSER }) { Text("Clear browser data") }
                Button(
                    onClick = { pendingClear = PendingClear.ALL },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError),
                ) { Text("Clear all data") }
            }

            Section("Attachments")
            Body("Supported: ${AttachmentTypes.SUPPORTED_SUMMARY} Up to ${AttachmentTypes.MAX_ATTACHMENTS_PER_MESSAGE} per message. Photos are resized and their location data removed before sending.")

            Section("Assistant")
            InfoRow(
                "Model",
                if (!FirebaseSetup.isConfigured && settings.aiProvider != AiProvider.LOCAL) "Not configured"
                else listOf("${ui.provider.label}: ${ui.modelName}", ui.modelDetail).filter { it.isNotBlank() }.joinToString(" · "),
            )
            InfoRow("Default models", "Gemini: ${ModelConfig.defaultModel} · Grok: ${ModelConfig.defaultGrokModel}")
            InfoRow(
                "Change remotely (Firebase Remote Config)",
                "Gemini: \"${ModelConfig.REMOTE_MODEL}\", \"${ModelConfig.REMOTE_THINKING}\" · " +
                    "Grok: \"${ModelConfig.REMOTE_GROK_URL}\", \"${ModelConfig.REMOTE_GROK_MODEL}\"",
            )
            InfoRow("Firebase", if (FirebaseSetup.isConfigured) "Configured" else "Missing google-services.json")
            InfoRow("App Check", AppCheckProviders.PROVIDER_NAME)
            if (AppCheckProviders.SHOWS_DEBUG_TOKEN && FirebaseSetup.isConfigured) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("App Check debug token", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.size(4.dp))
                        Text(
                            "Add this in Firebase console → App Check → Apps → (your Android app) → Manage debug tokens. " +
                                "Keep it private: it lets this build call your Firebase project.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.size(8.dp))
                        Text(
                            debugToken ?: "Not created yet. Send a message or tap Refresh.",
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Row {
                            TextButton(onClick = { refreshKey++ }) { Text("Refresh") }
                            val token = debugToken
                            if (token != null) {
                                TextButton(onClick = {
                                    context.getSystemService(ClipboardManager::class.java)
                                        ?.setPrimaryClip(ClipData.newPlainText("App Check debug token", token))
                                }) { Text("Copy") }
                            }
                        }
                    }
                }
            }
            InfoRow("Version", "${BuildConfig.VERSION_NAME} (${if (BuildConfig.DEBUG) "debug" else "release"})")
        }
    }

    pendingClear?.let { which ->
        val (title, body) = when (which) {
            PendingClear.CONVERSATION -> "Clear conversation?" to "Deletes all messages and attached files from this phone."
            PendingClear.BROWSER -> "Clear browser data?" to "Signs you out of websites and deletes the browser's cookies, cache, history and site data."
            PendingClear.ALL -> "Clear all data?" to "Deletes the conversation, attachments, browser data and settings from this phone."
        }
        AlertDialog(
            onDismissRequest = { pendingClear = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                TextButton(onClick = {
                    when (which) {
                        PendingClear.CONVERSATION -> vm.clearConversation()
                        PendingClear.BROWSER -> vm.clearBrowserData()
                        PendingClear.ALL -> vm.clearAllData()
                    }
                    pendingClear = null
                    refreshKey++
                }) { Text("Clear", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { pendingClear = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.size(12.dp))
    HorizontalDivider()
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun Body(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
    )
}

@Composable
private fun ChoiceRow(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    ListItem(
        headlineContent = { Text(value) },
        overlineContent = { Text(label) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
    )
}
