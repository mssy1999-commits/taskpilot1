package com.taskpilot.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Deep navy ("pilot") with a warm amber signal colour, on a paper-like neutral.
private val Navy = Color(0xFF1F3A5F)
private val Amber = Color(0xFFF2B544)

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E4F4),
    onPrimaryContainer = Color(0xFF0B1D33),
    secondary = Color(0xFF7A5200),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE2A6),
    onSecondaryContainer = Color(0xFF2A1A00),
    tertiary = Color(0xFF2F6B5A),
    onTertiary = Color.White,
    background = Color(0xFFF7F6F2),
    onBackground = Color(0xFF1B1C1E),
    surface = Color(0xFFF7F6F2),
    onSurface = Color(0xFF1B1C1E),
    surfaceVariant = Color(0xFFE6E3DA),
    onSurfaceVariant = Color(0xFF4A4740),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1EFEA),
    surfaceContainer = Color(0xFFECEAE4),
    surfaceContainerHigh = Color(0xFFE6E4DE),
    surfaceContainerHighest = Color(0xFFE0DED8),
    outline = Color(0xFF7A766D),
    outlineVariant = Color(0xFFCBC7BD),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA9C7EE),
    onPrimary = Color(0xFF0E2A47),
    primaryContainer = Color(0xFF2A4A70),
    onPrimaryContainer = Color(0xFFD8E4F4),
    secondary = Amber,
    onSecondary = Color(0xFF3F2C00),
    secondaryContainer = Color(0xFF5C4200),
    onSecondaryContainer = Color(0xFFFFE2A6),
    tertiary = Color(0xFF8FD3BD),
    background = Color(0xFF121417),
    onBackground = Color(0xFFE3E2DF),
    surface = Color(0xFF121417),
    onSurface = Color(0xFFE3E2DF),
    surfaceVariant = Color(0xFF2A2C30),
    onSurfaceVariant = Color(0xFFC8C5BD),
    surfaceContainerLowest = Color(0xFF0C0E10),
    surfaceContainerLow = Color(0xFF1A1C1F),
    surfaceContainer = Color(0xFF1E2023),
    surfaceContainerHigh = Color(0xFF282A2E),
    surfaceContainerHighest = Color(0xFF333539),
    outline = Color(0xFF928F87),
    outlineVariant = Color(0xFF45474B),
    error = Color(0xFFF2B8B5),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.sp),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(fontSize = 16.sp, lineHeight = 23.sp),
        labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp),
    )
}

@Composable
fun TaskPilotTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
