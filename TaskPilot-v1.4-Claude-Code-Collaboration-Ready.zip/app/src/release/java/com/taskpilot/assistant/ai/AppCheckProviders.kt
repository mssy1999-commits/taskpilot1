package com.taskpilot.assistant.ai

import android.content.Context
import com.google.firebase.appcheck.AppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

/**
 * RELEASE BUILDS. Play Integrity attests that requests come from your genuine app
 * installed from Google Play. Register the app's SHA-256 signing fingerprint in
 * Firebase (Project settings) and link Play Integrity in App Check. See README.
 */
object AppCheckProviders {
    const val PROVIDER_NAME = "Play Integrity"
    const val SHOWS_DEBUG_TOKEN = false

    fun factory(): AppCheckProviderFactory = PlayIntegrityAppCheckProviderFactory.getInstance()

    @Suppress("UNUSED_PARAMETER")
    fun readDebugToken(context: Context): String? = null
}
