import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

// The Google Services plugin fails the build when google-services.json is missing.
// Apply it only when the file exists, so the project still builds (with the assistant
// disabled and a setup banner shown) before Firebase has been configured.
val hasFirebaseConfig = file("google-services.json").exists()
if (hasFirebaseConfig) {
    apply(plugin = "com.google.gms.google-services")
} else {
    logger.warn(
        "TaskPilot: app/google-services.json not found. Building without Firebase; " +
            "the assistant will show setup instructions at runtime. See README.md."
    )
}

val geminiModel = providers.gradleProperty("taskpilot.geminiModel").getOrElse("gemini-3.5-flash-lite")
val appId = providers.gradleProperty("taskpilot.applicationId").getOrElse("com.taskpilot.assistant")
// Grok (optional): your proxy URL (not a secret) and model. Can also be set in Remote Config.
val grokProxyUrl = providers.gradleProperty("taskpilot.grokProxyUrl").getOrElse("").replace("\"", "").replace("\\", "")
val grokModel = providers.gradleProperty("taskpilot.grokModel").getOrElse("grok-4.7")

android {
    namespace = "com.taskpilot.assistant"
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        minSdk = 26
        targetSdk = 36
        versionCode = 7
        versionName = "1.4.0-free"

        buildConfigField("String", "DEFAULT_GEMINI_MODEL", "\"$geminiModel\"")
        buildConfigField("boolean", "HAS_FIREBASE_CONFIG", hasFirebaseConfig.toString())
        buildConfigField("String", "GROK_PROXY_URL", "\"$grokProxyUrl\"")
        buildConfigField("String", "DEFAULT_GROK_MODEL", "\"$grokModel\"")
    }

    signingConfigs {
        // A fixed, repo-shared DEBUG key (not for release) so every cloud build has the
        // same signature and installs as an update instead of requiring an uninstall.
        getByName("debug") {
            val shared = file("debug.keystore")
            if (shared.exists()) {
                storeFile = shared
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        debug {
            // Debug builds use the App Check *debug* provider (see src/debug).
        }
        release {
            // Release builds use Play Integrity (see src/release). Configure signing
            // before distributing; see README "Release builds".
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/INDEX.LIST",
                "/META-INF/io.netty.versions.properties",
            )
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // Offline, quota-free inference. Models are user-provided and never bundled in the APK.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.ai)
    implementation(libs.firebase.config)
    implementation(libs.firebase.appcheck.playintegrity)
    debugImplementation(libs.firebase.appcheck.debug)

    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)

    testImplementation(libs.junit)
}
