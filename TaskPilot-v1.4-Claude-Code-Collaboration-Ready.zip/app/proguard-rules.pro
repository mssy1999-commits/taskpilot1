# Release (minified) build rules. Firebase, Compose and kotlinx.serialization ship
# their own consumer rules; these cover the app's persisted @Serializable models.

-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
-keep,includedescriptorclasses class com.taskpilot.assistant.data.**$$serializer { *; }
-keepclassmembers class com.taskpilot.assistant.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.taskpilot.assistant.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
