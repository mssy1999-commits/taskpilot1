# TaskPilot — Claude Code project rules

## Purpose
Build a privacy-conscious Android AI assistant called TaskPilot with a ChatGPT-like chat UI,
voice input/output, image and file attachments, and a constrained WebView-based browser tool.

## Project baseline
- Android/Kotlin/Jetpack Compose; Gradle wrapper provided in this repository.
- Keep the existing v1.4 functionality stable: chat, local history, voice, attachments,
  website-template generation and export, optional local LiteRT-LM, optional Firebase AI Logic.
- Offline deterministic commands must remain usable without an API or paid backend.
- Existing Google/Firebase setup is optional; do not invent API keys or embed secrets.

## Quality and safety
1. Before editing, inspect the relevant files and explain intended changes.
2. Prefer small pull requests with an explicit summary, tests, and known limitations.
3. Run `./gradlew --no-daemon testDebugUnitTest` and `./gradlew --no-daemon assembleDebug` when the SDK is available.
4. Never claim an APK has been built unless the build job actually passes and produces an APK.
5. Preserve WebView origin restrictions, tool allowlists, and explicit user confirmation
   before messages, purchases, submissions, or other consequential actions.
6. Do not auto-send WhatsApp messages, post content, spend money or submit forms without user approval.
7. Do not commit tokens, `local.properties`, personal data, release signing keys,
   proprietary model weights or secrets. Use GitHub Actions secrets if required.
8. Do not remove or silently replace existing providers or features without approval.
9. Prefer free and offline options; clearly identify any Claude/API subscription costs.
10. Never auto-merge pull requests. Wait for owner review.

## First suggested tasks
- Review build blockers and resolve dependency or compilation errors with tests.
- Validate UI behavior on narrow Android phone screens.
- Preserve compatibility with ARM devices and Android minSdk from build.gradle.kts.
- Confirm debug APK upload from GitHub Actions and document installation steps.
