// Local test for worker.js (run: node test.mjs). Signs real RS256 App Check-style
// tokens and mocks the JWKS endpoint and api.x.ai, so no network or keys are needed.
import assert from "node:assert/strict";

const PROJECT = "150252300373";
const enc = new TextEncoder();
const b64url = (bytes) => Buffer.from(bytes).toString("base64url");

const { privateKey, publicKey } = await crypto.subtle.generateKey(
  { name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
  true,
  ["sign", "verify"],
);
const jwk = await crypto.subtle.exportKey("jwk", publicKey);
const JWKS = { keys: [{ kty: "RSA", n: jwk.n, e: jwk.e, kid: "kid-1", alg: "RS256", use: "sig" }] };

async function token(overrides = {}, header = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = { alg: "RS256", typ: "JWT", kid: "kid-1", ...header };
  const p = {
    iss: `https://firebaseappcheck.googleapis.com/${PROJECT}`,
    aud: [`projects/${PROJECT}`, "projects/taskpilot-208ba"],
    sub: "1:150252300373:android:0f0c8c19cee4ddd4d70cdc",
    iat: now,
    exp: now + 3600,
    ...overrides,
  };
  const input = b64url(enc.encode(JSON.stringify(h))) + "." + b64url(enc.encode(JSON.stringify(p)));
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", privateKey, enc.encode(input));
  return input + "." + b64url(new Uint8Array(sig));
}

let upstreamCalls = [];
let jwksFetches = 0;
globalThis.fetch = async (url, init = {}) => {
  if (String(url) === "https://firebaseappcheck.googleapis.com/v1/jwks") {
    jwksFetches++;
    return new Response(JSON.stringify(JWKS), { headers: { "Content-Type": "application/json" } });
  }
  if (String(url) === "https://api.x.ai/v1/chat/completions") {
    upstreamCalls.push({ headers: init.headers, body: init.body });
    return new Response(JSON.stringify({ choices: [{ message: { role: "assistant", content: "hi" } }] }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }
  throw new Error("unexpected fetch " + url);
};

const worker = (await import("./worker.js")).default;
const env = { XAI_API_KEY: "xai-test-secret", FIREBASE_PROJECT_NUMBER: PROJECT, ALLOWED_MODELS: "grok-4.7" };
const body = JSON.stringify({ model: "grok-4.7", messages: [{ role: "user", content: "hello" }] });

function req(tokenValue, b = body, method = "POST", path = "/v1/chat/completions") {
  const headers = { "Content-Type": "application/json" };
  if (tokenValue !== undefined) headers["X-Firebase-AppCheck"] = tokenValue;
  return new Request("https://proxy.example.workers.dev" + path, { method, headers, body: method === "POST" ? b : undefined });
}

let passed = 0;
async function test(name, fn) {
  upstreamCalls = [];
  await fn();
  passed++;
  console.log("PASS", name);
}

async function expectError(res, status, code) {
  assert.equal(res.status, status);
  const data = await res.json();
  assert.equal(data.error.code, code);
  return data;
}

await test("valid token is forwarded with the secret key", async () => {
  const res = await worker.fetch(req(await token()), env);
  assert.equal(res.status, 200);
  assert.equal((await res.json()).choices[0].message.content, "hi");
  assert.equal(upstreamCalls.length, 1);
  assert.equal(upstreamCalls[0].headers.Authorization, "Bearer xai-test-secret");
  assert.equal(upstreamCalls[0].body, body);
});

await test("JWKS is cached between requests", async () => {
  const before = jwksFetches;
  await worker.fetch(req(await token()), env);
  assert.equal(jwksFetches, before);
});

await test("missing token is rejected", async () => {
  await expectError(await worker.fetch(req(undefined), env), 401, "app_check");
  assert.equal(upstreamCalls.length, 0);
});

await test("other project is rejected", async () => {
  const data = await expectError(await worker.fetch(req(await token({ iss: "https://firebaseappcheck.googleapis.com/999" })), env), 401, "app_check");
  assert.match(data.error.message, /issuer/);
});

await test("wrong audience is rejected", async () => {
  await expectError(await worker.fetch(req(await token({ aud: ["projects/999"] })), env), 401, "app_check");
});

await test("expired token is rejected", async () => {
  const past = Math.floor(Date.now() / 1000) - 7200;
  const data = await expectError(await worker.fetch(req(await token({ iat: past - 3600, exp: past })), env), 401, "app_check");
  assert.match(data.error.message, /expired/);
});

await test("tampered payload is rejected", async () => {
  const t = (await token()).split(".");
  const forged = b64url(enc.encode(JSON.stringify({ iss: `https://firebaseappcheck.googleapis.com/${PROJECT}`, aud: [`projects/${PROJECT}`], exp: 9999999999 })));
  const data = await expectError(await worker.fetch(req([t[0], forged, t[2]].join(".")), env), 401, "app_check");
  assert.match(data.error.message, /signature/);
});

await test("alg none / unknown kid are rejected", async () => {
  await expectError(await worker.fetch(req(await token({}, { alg: "none" })), env), 401, "app_check");
  await expectError(await worker.fetch(req(await token({}, { kid: "other" })), env), 401, "app_check");
});

await test("disallowed model is blocked", async () => {
  const pricey = JSON.stringify({ model: "grok-ultra", messages: [] });
  await expectError(await worker.fetch(req(await token(), pricey), env), 400, "model_not_allowed");
  assert.equal(upstreamCalls.length, 0);
});

await test("app id allowlist", async () => {
  const strict = { ...env, FIREBASE_APP_IDS: "1:150252300373:android:0f0c8c19cee4ddd4d70cdc" };
  assert.equal((await worker.fetch(req(await token()), strict)).status, 200);
  await expectError(await worker.fetch(req(await token({ sub: "1:150252300373:ios:abc" })), strict), 401, "app_check");
});

await test("missing configuration and unknown paths", async () => {
  await expectError(await worker.fetch(req(await token()), { FIREBASE_PROJECT_NUMBER: PROJECT }), 500, "proxy_not_configured");
  await expectError(await worker.fetch(req(await token(), body, "POST", "/v1/other"), env), 404, "not_found");
  const health = await worker.fetch(req(undefined, undefined, "GET", "/"), env);
  assert.equal(health.status, 200);
});

console.log(`\n${passed} passed`);
