// TaskPilot Grok proxy: a Cloudflare Worker (works on the free plan).
//
// It keeps your xAI API key secret and forwards chat requests from the TaskPilot
// app to api.x.ai, but ONLY when the request carries a valid Firebase App Check
// token for your Firebase project. The app itself never contains the xAI key.
//
// Worker settings (Cloudflare dashboard → your Worker → Settings → Variables and Secrets):
//   XAI_API_KEY              Secret  Your xAI API key (starts with "xai-"). Required.
//   FIREBASE_PROJECT_NUMBER  Text    Your Firebase project number, e.g. 150252300373. Required.
//   ALLOWED_MODELS           Text    Optional comma list, e.g. "grok-4.7". Blocks other (pricier) models.
//   FIREBASE_APP_IDS         Text    Optional comma list of allowed Firebase app ids, e.g.
//                                    "1:150252300373:android:0f0c8c19cee4ddd4d70cdc".

const XAI_URL = "https://api.x.ai/v1/chat/completions";
const JWKS_URL = "https://firebaseappcheck.googleapis.com/v1/jwks";
const MAX_BODY_BYTES = 20 * 1024 * 1024;
const JWKS_MAX_AGE_MS = 6 * 60 * 60 * 1000; // Firebase recommends caching keys for at most 6 hours
const JWKS_MIN_REFRESH_MS = 60 * 1000;

let jwksCache = null; // { keys: Map<kid, CryptoKey>, fetchedAt: number }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") {
      return json(200, { ok: true, service: "taskpilot-grok-proxy" });
    }
    if (request.method !== "POST" || url.pathname !== "/v1/chat/completions") {
      return error(404, "not_found", "Not found");
    }
    if (!env.XAI_API_KEY || !env.FIREBASE_PROJECT_NUMBER) {
      return error(500, "proxy_not_configured", "XAI_API_KEY or FIREBASE_PROJECT_NUMBER is missing");
    }

    const token = request.headers.get("X-Firebase-AppCheck") || "";
    const check = await verifyAppCheck(token, String(env.FIREBASE_PROJECT_NUMBER).trim(), env.FIREBASE_APP_IDS);
    if (!check.ok) return error(401, "app_check", "App Check verification failed: " + check.reason);

    const declared = Number(request.headers.get("Content-Length") || "0");
    if (declared > MAX_BODY_BYTES) return error(413, "too_large", "Request too large");
    const body = await request.text();
    if (body.length > MAX_BODY_BYTES) return error(413, "too_large", "Request too large");

    const allowed = list(env.ALLOWED_MODELS);
    if (allowed.length) {
      // The app always sends "model" as the first key; checking it here avoids
      // parsing large bodies (images) within the free plan's CPU limit.
      const m = /^\s*\{\s*"model"\s*:\s*"([^"\\]{1,80})"/.exec(body);
      if (!m || !allowed.includes(m[1])) return error(400, "model_not_allowed", "Model not allowed by this proxy");
    }

    const upstream = await fetch(XAI_URL, {
      method: "POST",
      headers: { Authorization: "Bearer " + env.XAI_API_KEY, "Content-Type": "application/json" },
      body,
    });
    return new Response(upstream.body, {
      status: upstream.status,
      headers: {
        "Content-Type": upstream.headers.get("Content-Type") || "application/json",
        "Cache-Control": "no-store",
      },
    });
  },
};

async function verifyAppCheck(token, projectNumber, appIds) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return { ok: false, reason: "missing or malformed token" };
  let header, payload;
  try {
    header = JSON.parse(b64urlToString(parts[0]));
    payload = JSON.parse(b64urlToString(parts[1]));
  } catch (e) {
    return { ok: false, reason: "malformed token" };
  }
  if (header.alg !== "RS256" || header.typ !== "JWT" || !header.kid) return { ok: false, reason: "unexpected header" };

  const key = await signingKey(header.kid);
  if (!key) return { ok: false, reason: "unknown signing key" };
  let valid = false;
  try {
    valid = await crypto.subtle.verify(
      "RSASSA-PKCS1-v1_5",
      key,
      b64urlToBytes(parts[2]),
      new TextEncoder().encode(parts[0] + "." + parts[1]),
    );
  } catch (e) {
    valid = false;
  }
  if (!valid) return { ok: false, reason: "bad signature" };

  const now = Math.floor(Date.now() / 1000);
  if (payload.iss !== "https://firebaseappcheck.googleapis.com/" + projectNumber) return { ok: false, reason: "wrong issuer" };
  const aud = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!aud.includes("projects/" + projectNumber)) return { ok: false, reason: "wrong audience" };
  if (typeof payload.exp !== "number" || payload.exp < now - 30) return { ok: false, reason: "expired" };
  if (typeof payload.iat === "number" && payload.iat > now + 300) return { ok: false, reason: "issued in the future" };
  const apps = list(appIds);
  if (apps.length && !apps.includes(payload.sub)) return { ok: false, reason: "app not allowed" };
  return { ok: true };
}

async function signingKey(kid) {
  const now = Date.now();
  const stale = !jwksCache || now - jwksCache.fetchedAt > JWKS_MAX_AGE_MS;
  const unknown = jwksCache && !jwksCache.keys.has(kid) && now - jwksCache.fetchedAt > JWKS_MIN_REFRESH_MS;
  if (stale || unknown) {
    try {
      await refreshJwks();
    } catch (e) {
      // Keep using the cached keys if the refresh fails.
    }
  }
  return (jwksCache && jwksCache.keys.get(kid)) || null;
}

async function refreshJwks() {
  const res = await fetch(JWKS_URL);
  if (!res.ok) throw new Error("JWKS fetch failed: " + res.status);
  const data = await res.json();
  const keys = new Map();
  for (const jwk of data.keys || []) {
    if (jwk.kty !== "RSA" || !jwk.kid) continue;
    const key = await crypto.subtle.importKey(
      "jwk",
      { kty: "RSA", n: jwk.n, e: jwk.e, alg: "RS256", ext: true },
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["verify"],
    );
    keys.set(jwk.kid, key);
  }
  jwksCache = { keys, fetchedAt: Date.now() };
}

function b64urlToBytes(s) {
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4);
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function b64urlToString(s) {
  return new TextDecoder().decode(b64urlToBytes(s));
}

function list(value) {
  return String(value || "").split(",").map((s) => s.trim()).filter(Boolean);
}

function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

function error(status, code, message) {
  return json(status, { error: { code, message } });
}
