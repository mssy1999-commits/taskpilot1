# TaskPilot Free v1.3.0

Upload the **contents** of this directory to a GitHub repository root, not just the ZIP file.
Actions → Build APK → Run workflow.

No GitHub needed: open the separately supplied Google Colab notebook and click Runtime → Run all.

Offline browser commands work without a backend. See README.md.
